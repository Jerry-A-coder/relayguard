from datetime import datetime, timezone
from typing import Optional
from sqlalchemy.orm import Session
from fastapi import HTTPException, status

from app.models.entities import Approval, User, AuditEvent
from app.core.permissions import UserRole, check_role_permission

class ApprovalService:
    VALID_TRANSITIONS = {
        "PROPOSED": ["AWAITING_APPROVAL", "REJECTED"],
        "AWAITING_APPROVAL": ["APPROVED", "REJECTED", "CHANGES_REQUESTED"],
        "CHANGES_REQUESTED": ["AWAITING_APPROVAL", "REJECTED"],
        "APPROVED": ["EXECUTING", "REJECTED"],
        "EXECUTING": ["SUCCEEDED", "FAILED"],
        "REJECTED": [],
        "SUCCEEDED": [],
        "FAILED": ["AWAITING_APPROVAL"],
    }

    @classmethod
    def decide_approval(
        cls,
        db: Session,
        approval_id: str,
        user: User,
        decision: str,
        rejection_reason: Optional[str] = None
    ) -> Approval:
        approval = db.query(Approval).filter(Approval.id == approval_id).first()
        if not approval:
            raise HTTPException(status_code=404, detail="Approval request not found")

        if not check_role_permission(user.role, [UserRole.ADMIN, UserRole.OWNER]):
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Only workspace ADMIN or OWNER roles are authorized to grant or reject approvals."
            )

        valid_targets = cls.VALID_TRANSITIONS.get(approval.status, [])
        if decision not in valid_targets:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=f"Cannot transition approval from '{approval.status}' to '{decision}'."
            )

        approval.status = decision
        approval.decided_by_id = user.id
        approval.decided_at = datetime.now(timezone.utc)
        if rejection_reason:
            approval.rejection_reason = rejection_reason

        audit_event = AuditEvent(
            organization_id=user.organization_id,
            incident_id=approval.incident_id,
            actor_id=user.id,
            actor_name=user.full_name,
            event_type=f"APPROVAL_{decision}",
            summary=f"Approval '{approval.title}' set to {decision} by {user.full_name}",
            details=f"Reason: {rejection_reason or 'No specific reason provided'}"
        )
        db.add(audit_event)
        db.commit()
        db.refresh(approval)
        return approval
