from typing import Dict, Any, List
from sqlalchemy.orm import Session

from app.models.entities import Incident, Task, TaskDependency, AuditEvent, User
from app.services.dependency_engine import DependencyEngine
from app.services.prioritization_engine import PrioritizationEngine

class ReplanningService:
    @classmethod
    def recalculate_incident_graph(
        cls,
        db: Session,
        incident_id: str,
        actor: User
    ) -> Dict[str, Any]:
        incident = db.query(Incident).filter(Incident.id == incident_id).first()
        if not incident:
            return {}

        tasks = db.query(Task).filter(Task.incident_id == incident_id).all()
        deps = db.query(TaskDependency).filter(TaskDependency.incident_id == incident_id).all()

        task_ids = [t.id for t in tasks]
        edges = [(d.source_task_id, d.target_task_id) for d in deps]
        durations = {t.id: t.estimated_minutes for t in tasks}
        statuses = {t.id: t.status for t in tasks}

        has_cycle, cycle_nodes = DependencyEngine.detect_cycle(task_ids, edges)
        blocked_ids = set(DependencyEngine.determine_blocked_tasks(task_ids, statuses, edges))
        crit_path, crit_duration = DependencyEngine.calculate_critical_path(task_ids, durations, edges)
        crit_set = set(crit_path)

        priorities = PrioritizationEngine.calculate_task_priorities(
            task_ids=task_ids,
            task_durations=durations,
            task_statuses=statuses,
            edges=edges,
            incident_severity=incident.severity,
            incident_priority=incident.priority,
        )

        for t in tasks:
            was_blocked = (t.status == "BLOCKED")
            is_now_blocked = (t.id in blocked_ids and t.status != "COMPLETED")

            if is_now_blocked and t.status not in ["COMPLETED", "CANCELLED"]:
                t.status = "BLOCKED"
            elif was_blocked and not is_now_blocked and t.status == "BLOCKED":
                t.status = "NOT_STARTED"

            p_info = priorities.get(t.id, {})
            t.priority_score = p_info.get("priority_score", t.priority_score)
            t.risk_level = p_info.get("risk_level", t.risk_level)
            t.is_critical_path = t.id in crit_set

        db.commit()

        return {
            "has_cycle": has_cycle,
            "cycle_nodes": cycle_nodes,
            "blocked_task_ids": list(blocked_ids),
            "critical_path": crit_path,
            "critical_path_duration": crit_duration,
            "total_tasks": len(tasks),
        }
