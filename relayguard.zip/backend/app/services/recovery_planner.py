from typing import List, Dict, Any
from app.models.entities import Incident, Task, TaskDependency
from app.services.dependency_engine import DependencyEngine

class RecoveryPlanner:
    @classmethod
    def generate_plans(
        cls,
        incident: Incident,
        tasks: List[Task],
        dependencies: List[TaskDependency]
    ) -> List[Dict[str, Any]]:
        edges = [(d.source_task_id, d.target_task_id) for d in dependencies]
        task_ids = [t.id for t in tasks]
        task_map = {t.id: t for t in tasks}
        durations = {t.id: t.estimated_minutes for t in tasks}

        critical_path, crit_duration = DependencyEngine.calculate_critical_path(task_ids, durations, edges)
        crit_task_titles = [task_map[tid].title for tid in critical_path if tid in task_map]
        crit_summary = ", ".join(crit_task_titles[:3]) if crit_task_titles else "Core delivery sequence"

        # Plan 1: Minimum Disruption
        plan_a_duration = max(30, int(crit_duration * 0.75))
        plan_a = {
            "title": "Plan A: Accelerated Parallel Path (Scope Preservation)",
            "strategy": "MIN_DISRUPTION",
            "score": 92,
            "estimated_duration_mins": plan_a_duration,
            "risks": "Higher coordination overhead across concurrent threads; requires fast turnaround on manual approvals.",
            "tradeoffs": "Delivers 100% of agreed deliverables with zero scope compromise at the cost of elevated operational tempo.",
            "actions": [
                {
                    "order": 1,
                    "title": "Broadcast Incident Advisory to Incident Response Team",
                    "description": f"Notify assigned owners that incident '{incident.title}' is activating emergency parallel recovery tracks.",
                    "responsible_role": "Incident Commander",
                    "estimated_minutes": 10,
                    "requires_approval": False,
                    "action_type": "BROADCAST_ALERT",
                    "target_recipient": "All Assigned Task Owners",
                    "payload": {
                        "channel": "Incident Operations #ops-war-room",
                        "incident_title": incident.title,
                        "priority": incident.priority
                    }
                },
                {
                    "order": 2,
                    "title": "Authorize Emergency Overtime / Resource Reallocation",
                    "description": f"Allocate reserve capacity to unblock the bottleneck along critical path: {crit_summary}.",
                    "responsible_role": "Operations Lead",
                    "estimated_minutes": 25,
                    "requires_approval": True,
                    "action_type": "EXCEPTION_REQUEST",
                    "target_recipient": "Budget & Resource Authorization Committee",
                    "payload": {
                        "allocated_hours": 12,
                        "priority_level": incident.priority,
                        "justification": f"Prevent cascading failure on {incident.title}"
                    }
                },
                {
                    "order": 3,
                    "title": "Establish Parallel Review Track for Critical Path Modules",
                    "description": "Split verification into two concurrent sub-tasks so downstream synthesis can start without waiting for full batch sign-off.",
                    "responsible_role": "Technical Reviewer",
                    "estimated_minutes": 45,
                    "requires_approval": True,
                    "action_type": "CALENDAR_RESCHEDULE",
                    "target_recipient": "Technical Lead & Review Board",
                    "payload": {
                        "event_title": "Emergency Concurrent Verification Checkpoint",
                        "duration_minutes": 45
                    }
                }
            ]
        }

        # Plan 2: Fastest Feasible
        plan_b_duration = max(20, int(crit_duration * 0.50))
        plan_b = {
            "title": "Plan B: Fast-Track Bypass & Supplier Redirection",
            "strategy": "FASTEST_FEASIBLE",
            "score": 85,
            "estimated_duration_mins": plan_b_duration,
            "risks": "Requires emergency procurement surcharge; temporary reliance on fallback supplier specs.",
            "tradeoffs": "Achieves the fastest possible time-to-recovery by substituting slower internal dependencies with rapid external components.",
            "actions": [
                {
                    "order": 1,
                    "title": "Issue Expedited Courier & Supplier Priority Dispatch Ticket",
                    "description": "Trigger emergency vendor dispatch protocol with courier tracking and SLA tier-1 escalation.",
                    "responsible_role": "Procurement / Logistics Coordinator",
                    "estimated_minutes": 15,
                    "requires_approval": True,
                    "action_type": "SUPPLIER_EXPEDITE",
                    "target_recipient": "Tier-1 Priority Logistics Gateway",
                    "payload": {
                        "carrier_tier": "Same-Day Direct Delivery",
                        "urgency": "Maximum",
                        "incident_reference": incident.id
                    }
                },
                {
                    "order": 2,
                    "title": "Bypass Optional Staging Verification Gate",
                    "description": "Temporarily fast-forward directly to integration test using pre-cached test fixtures.",
                    "responsible_role": "QA / Release Manager",
                    "estimated_minutes": 20,
                    "requires_approval": True,
                    "action_type": "EXCEPTION_REQUEST",
                    "target_recipient": "Governance & Quality Director",
                    "payload": {
                        "waiver_type": "Staging Bypass Waiver",
                        "duration_hours": 24
                    }
                },
                {
                    "order": 3,
                    "title": "Automated Progress Dispatch to Stakeholders",
                    "description": "Transmit electronic confirmation to customer/client with updated delivery ETA.",
                    "responsible_role": "Client Liaison",
                    "estimated_minutes": 10,
                    "requires_approval": False,
                    "action_type": "EMAIL_DISPATCH",
                    "target_recipient": "Executive Stakeholder Distribution List",
                    "payload": {
                        "subject": f"RelayGuard Advisory: Fast-Track Recovery Engaged for {incident.title}",
                        "urgency": "High"
                    }
                }
            ]
        }

        # Plan 3: Lowest Risk
        plan_c_duration = max(45, int(crit_duration * 1.2))
        plan_c = {
            "title": "Plan C: Grace Window & Controlled Scope Deferral",
            "strategy": "LOWEST_RISK",
            "score": 78,
            "estimated_duration_mins": plan_c_duration,
            "risks": "Modifies original commitment timeline; requires customer/regulatory concurrence.",
            "tradeoffs": "Lowest execution risk with zero overtime fatigue; protects baseline quality at the expense of extending delivery window.",
            "actions": [
                {
                    "order": 1,
                    "title": "File Formal Extension / Grace Window Request",
                    "description": "Submit structured extension request under standard operational variance terms.",
                    "responsible_role": "Compliance & Account Manager",
                    "estimated_minutes": 20,
                    "requires_approval": True,
                    "action_type": "EXCEPTION_REQUEST",
                    "target_recipient": "Client Governance Board",
                    "payload": {
                        "requested_extension_hours": 48,
                        "reason": f"Disruption mitigation for {incident.title}"
                    }
                },
                {
                    "order": 2,
                    "title": "Realign Milestones in Calendar & Dispatch Updated Schedule",
                    "description": "Synchronize updated deadlines across team calendars with buffer buffers applied.",
                    "responsible_role": "Project Manager",
                    "estimated_minutes": 15,
                    "requires_approval": False,
                    "action_type": "CALENDAR_RESCHEDULE",
                    "target_recipient": "All Project Participants",
                    "payload": {
                        "reschedule_mode": "Grace-Window-Shift",
                        "shift_hours": 48
                    }
                },
                {
                    "order": 3,
                    "title": "Publish Scope Deferral Notice to Registry",
                    "description": "Record deferred secondary tasks in compliance log for subsequent sprint execution.",
                    "responsible_role": "Release Coordinator",
                    "estimated_minutes": 15,
                    "requires_approval": True,
                    "action_type": "MANUAL_TASK",
                    "target_recipient": "Internal Audit Log",
                    "payload": {
                        "deferred_scope": "Non-blocking optional modules"
                    }
                }
            ]
        }

        return [plan_a, plan_b, plan_c]
