from datetime import datetime, timezone
import random
from typing import Dict, Any, Optional
from sqlalchemy.orm import Session
from fastapi import HTTPException, status

from app.models.entities import Approval, RecoveryAction, AuditEvent, User

class ExecutionService:
    @classmethod
    def execute_action(
        cls,
        db: Session,
        approval_id: str,
        idempotency_key: str,
        user: User
    ) -> Dict[str, Any]:
        approval = db.query(Approval).filter(Approval.id == approval_id).first()
        if not approval:
            raise HTTPException(status_code=404, detail="Approval request not found")

        # 1. Idempotent replay: return cached success if already executed with this key
        if approval.idempotency_key == idempotency_key and approval.status == "SUCCEEDED":
            return {
                "success": True,
                "is_simulated": True,
                "status": "SUCCEEDED",
                "execution_result": approval.execution_result,
                "approval_id": approval.id,
                "idempotency_key": idempotency_key,
                "message": "Action previously executed successfully (idempotent response)."
            }

        # 2. State check: Must be APPROVED to execute
        if approval.status != "APPROVED":
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=f"Cannot execute action. Current status is '{approval.status}', but must be 'APPROVED'."
            )

        # 3. Idempotency Conflict Check: reject if key already used by another approval
        existing = db.query(Approval).filter(
            Approval.idempotency_key == idempotency_key,
            Approval.id != approval_id
        ).first()

        if existing:
            raise HTTPException(
                status_code=status.HTTP_409_CONFLICT,
                detail=f"Duplicate execution rejected: idempotency key '{idempotency_key}' already used for approval '{existing.id}'."
            )

        # 4. Transition to EXECUTING
        approval.status = "EXECUTING"
        approval.idempotency_key = idempotency_key
        db.commit()

        # 5. Dispatch through adapter
        result_summary = cls._dispatch_adapter(
            action_type=approval.action_type,
            target_recipient=approval.target_recipient,
            payload=approval.payload or {}
        )

        # 6. Transition to SUCCEEDED and mark associated RecoveryAction as completed
        approval.status = "SUCCEEDED"
        approval.execution_result = result_summary
        if approval.action_id:
            action = db.query(RecoveryAction).filter(RecoveryAction.id == approval.action_id).first()
            if action:
                action.is_completed = True

        audit_event = AuditEvent(
            organization_id=user.organization_id,
            incident_id=approval.incident_id,
            actor_id=user.id,
            actor_name=user.full_name,
            event_type="ACTION_EXECUTED",
            summary=f"Executed action '{approval.title}' via adapter [{approval.action_type}]",
            details=result_summary
        )
        db.add(audit_event)
        db.commit()
        db.refresh(approval)

        return {
            "success": True,
            "is_simulated": True,
            "status": "SUCCEEDED",
            "execution_result": result_summary,
            "approval_id": approval.id,
            "idempotency_key": idempotency_key,
        }

    @staticmethod
    def _dispatch_adapter(action_type: str, target_recipient: Optional[str], payload: Dict[str, Any]) -> str:
        recipient = target_recipient or "Default Target"
        ts = datetime.now(timezone.utc).isoformat()

        if action_type == "EMAIL_DISPATCH":
            subj = payload.get("subject", "RelayGuard Automated Recovery Advisory")
            return f"[{ts}] Simulated SMTP Dispatch to <{recipient}>. Subject: '{subj}'. Status: Queued in Relay Buffer."

        elif action_type == "CALENDAR_RESCHEDULE":
            event = payload.get("event_title", "Emergency Review Milestone")
            shift = payload.get("shift_hours", 24)
            return f"[{ts}] CalDAV Dispatch: Rescheduled '{event}' by +{shift}h for {recipient}. 0 scheduling conflicts detected."

        elif action_type == "SUPPLIER_EXPEDITE":
            ticket = f"EXP-{random.randint(100000, 999999)}"
            carrier = payload.get("carrier_tier", "Tier-1 Priority Courier")
            return f"[{ts}] Logistics Gateway Ticket #{ticket} dispatched to {recipient}. Carrier: {carrier}. SLA: Expedited."

        elif action_type == "EXCEPTION_REQUEST":
            hours = payload.get("requested_extension_hours") or payload.get("allocated_hours", 24)
            ref = f"EX-REG-{random.randint(10000, 99999)}"
            return f"[{ts}] Formal Variance Exception #{ref} registered with {recipient}. Duration/Allowance: {hours} hours."

        elif action_type == "BROADCAST_ALERT":
            ch = payload.get("channel", "All Operational Channels")
            return f"[{ts}] Broadcast Alert propagated to channel '{ch}'. Target: {recipient}. Broadcast acknowledged."

        else:
            return f"[{ts}] Manual Action '{action_type}' recorded and verified by operator for target '{recipient}'."
