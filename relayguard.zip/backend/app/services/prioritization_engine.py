from typing import List, Dict, Tuple
from app.services.dependency_engine import DependencyEngine

class PrioritizationEngine:
    SEVERITY_WEIGHTS = {
        "CRITICAL": 30.0,
        "HIGH": 20.0,
        "MEDIUM": 10.0,
        "LOW": 5.0,
    }

    PRIORITY_WEIGHTS = {
        "Critical": 25.0,
        "High": 18.0,
        "Medium": 10.0,
        "Low": 5.0,
    }

    @classmethod
    def calculate_task_priorities(
        cls,
        task_ids: List[str],
        task_durations: Dict[str, int],
        task_statuses: Dict[str, str],
        edges: List[Tuple[str, str]],
        incident_severity: str = "MEDIUM",
        incident_priority: str = "Medium",
    ) -> Dict[str, Dict[str, any]]:
        critical_path, _ = DependencyEngine.calculate_critical_path(task_ids, task_durations, edges)
        crit_set = set(critical_path)

        downstream_counts = {}
        for tid in task_ids:
            impacted = DependencyEngine.calculate_downstream_impact(tid, edges)
            downstream_counts[tid] = len(impacted)

        max_dependents = max(downstream_counts.values()) if downstream_counts and max(downstream_counts.values()) > 0 else 1

        results = {}
        sev_base = cls.SEVERITY_WEIGHTS.get(incident_severity.upper(), 10.0)
        prio_base = cls.PRIORITY_WEIGHTS.get(incident_priority.capitalize(), 10.0)

        for tid in task_ids:
            score = 20.0
            score += (sev_base * 0.7) + (prio_base * 0.6)

            dep_ratio = downstream_counts.get(tid, 0) / max_dependents
            score += dep_ratio * 30.0

            is_crit = tid in crit_set
            if is_crit:
                score += 20.0

            status = task_statuses.get(tid, "NOT_STARTED")
            if status == "BLOCKED":
                score += 10.0
            elif status == "IN_PROGRESS":
                score += 5.0
            elif status == "COMPLETED":
                score = max(5.0, score * 0.15)

            final_score = round(min(99.0, max(5.0, score)), 1)

            if final_score >= 80.0:
                risk = "CRITICAL"
            elif final_score >= 60.0:
                risk = "HIGH"
            elif final_score >= 35.0:
                risk = "MODERATE"
            else:
                risk = "NONE"

            results[tid] = {
                "priority_score": final_score,
                "risk_level": risk,
                "is_critical_path": is_crit,
            }

        return results
