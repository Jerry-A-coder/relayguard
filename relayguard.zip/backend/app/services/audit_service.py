from typing import Optional
from sqlalchemy.orm import Session
from app.models.entities import AuditEvent, User

class AuditService:
    @staticmethod
    def log_event(
        db: Session,
        organization_id: str,
        event_type: str,
        summary: str,
        actor: Optional[User] = None,
        incident_id: Optional[str] = None,
        details: Optional[str] = None
    ) -> AuditEvent:
        event = AuditEvent(
            organization_id=organization_id,
            incident_id=incident_id,
            actor_id=actor.id if actor else None,
            actor_name=actor.full_name if actor else "System",
            event_type=event_type,
            summary=summary,
            details=details
        )
        db.add(event)
        db.commit()
        db.refresh(event)
        return event
