from typing import List, Dict, Set, Tuple, Optional
from collections import defaultdict, deque

class DependencyEngine:
    @staticmethod
    def detect_cycle(task_ids: List[str], edges: List[Tuple[str, str]]) -> Tuple[bool, List[str]]:
        adj = defaultdict(list)
        for src, dst in edges:
            adj[src].append(dst)

        visited = {} # 0: unvisited, 1: visiting, 2: visited
        for tid in task_ids:
            visited[tid] = 0

        cycle_path: List[str] = []

        def dfs(node: str, path: List[str]) -> bool:
            visited[node] = 1
            path.append(node)

            for neighbor in adj[node]:
                if neighbor not in visited:
                    continue
                if visited[neighbor] == 1:
                    idx = path.index(neighbor)
                    cycle_path.extend(path[idx:] + [neighbor])
                    return True
                elif visited[neighbor] == 0:
                    if dfs(neighbor, path):
                        return True

            path.pop()
            visited[node] = 2
            return False

        for tid in task_ids:
            if visited.get(tid, 0) == 0:
                if dfs(tid, []):
                    return True, cycle_path

        return False, []

    @staticmethod
    def will_create_cycle(task_ids: List[str], existing_edges: List[Tuple[str, str]], new_edge: Tuple[str, str]) -> bool:
        src, target = new_edge
        if src == target:
            return True
        edges = list(existing_edges) + [new_edge]
        has_cycle, _ = DependencyEngine.detect_cycle(task_ids, edges)
        return has_cycle

    @staticmethod
    def topological_sort(task_ids: List[str], edges: List[Tuple[str, str]]) -> Tuple[bool, List[str]]:
        in_degree = {tid: 0 for tid in task_ids}
        adj = defaultdict(list)

        for src, dst in edges:
            if src in in_degree and dst in in_degree:
                adj[src].append(dst)
                in_degree[dst] += 1

        queue = deque([tid for tid in task_ids if in_degree[tid] == 0])
        order = []

        while queue:
            curr = queue.popleft()
            order.append(curr)
            for nxt in adj[curr]:
                in_degree[nxt] -= 1
                if in_degree[nxt] == 0:
                    queue.append(nxt)

        if len(order) != len(task_ids):
            return False, []

        return True, order

    @staticmethod
    def calculate_downstream_impact(disrupted_task_id: str, edges: List[Tuple[str, str]]) -> List[str]:
        adj = defaultdict(list)
        for src, dst in edges:
            adj[src].append(dst)

        impacted = set()
        queue = deque([disrupted_task_id])

        while queue:
            curr = queue.popleft()
            for nxt in adj[curr]:
                if nxt not in impacted:
                    impacted.add(nxt)
                    queue.append(nxt)

        return list(impacted)

    @staticmethod
    def calculate_critical_path(
        task_ids: List[str],
        task_durations: Dict[str, int],
        edges: List[Tuple[str, str]]
    ) -> Tuple[List[str], int]:
        success, topo_order = DependencyEngine.topological_sort(task_ids, edges)
        if not success or not topo_order:
            return (task_ids[:1] if task_ids else [], sum(task_durations.values()) if task_durations else 0)

        outgoing = defaultdict(list)
        incoming = defaultdict(list)
        for src, dst in edges:
            outgoing[src].append(dst)
            incoming[dst].append(src)

        dist = {tid: task_durations.get(tid, 0) for tid in task_ids}
        parent = {tid: None for tid in task_ids}

        for u in topo_order:
            u_dist = dist[u]
            for v in outgoing[u]:
                v_duration = task_durations.get(v, 0)
                if u_dist + v_duration > dist[v]:
                    dist[v] = u_dist + v_duration
                    parent[v] = u

        end_node = max(dist.keys(), key=lambda k: dist[k]) if dist else None
        if not end_node:
            return [], 0

        path = []
        curr = end_node
        while curr is not None:
            path.append(curr)
            curr = parent[curr]

        path.reverse()
        return path, dist[end_node]

    @staticmethod
    def determine_blocked_tasks(
        task_ids: List[str],
        task_statuses: Dict[str, str],
        edges: List[Tuple[str, str]]
    ) -> List[str]:
        incoming = defaultdict(list)
        for src, dst in edges:
            incoming[dst].append(src)

        blocked = []
        for tid in task_ids:
            if task_statuses.get(tid) == "COMPLETED":
                continue
            prereqs = incoming.get(tid, [])
            if not prereqs:
                continue
            has_unresolved = any(task_statuses.get(p) != "COMPLETED" for p in prereqs)
            if has_unresolved:
                blocked.append(tid)

        return blocked
