import uuid
from datetime import datetime, timezone
from sqlalchemy import (
    Column, String, Text, Boolean, Integer, Float, DateTime, ForeignKey, JSON
)
from sqlalchemy.orm import relationship
from app.db.session import Base

def gen_uuid() -> str:
    return str(uuid.uuid4())

def utc_now() -> datetime:
    return datetime.now(timezone.utc)

class Organization(Base):
    __tablename__ = "organizations"

    id = Column(String(36), primary_key=True, default=gen_uuid)
    name = Column(String(255), nullable=False)
    slug = Column(String(100), unique=True, nullable=False)
    created_at = Column(DateTime, default=utc_now)
    updated_at = Column(DateTime, default=utc_now, onupdate=utc_now)

    users = relationship("User", back_populates="organization", cascade="all, delete-orphan")
    incidents = relationship("Incident", back_populates="organization", cascade="all, delete-orphan")
    audit_events = relationship("AuditEvent", back_populates="organization", cascade="all, delete-orphan")


class User(Base):
    __tablename__ = "users"

    id = Column(String(36), primary_key=True, default=gen_uuid)
    organization_id = Column(String(36), ForeignKey("organizations.id", ondelete="CASCADE"), nullable=False)
    email = Column(String(255), unique=True, index=True, nullable=False)
    hashed_password = Column(String(255), nullable=False)
    full_name = Column(String(255), nullable=False)
    role = Column(String(50), default="MEMBER", nullable=False) # OWNER, ADMIN, MEMBER, VIEWER
    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime, default=utc_now)
    updated_at = Column(DateTime, default=utc_now, onupdate=utc_now)

    organization = relationship("Organization", back_populates="users")
    created_incidents = relationship("Incident", back_populates="creator")
    decided_approvals = relationship("Approval", foreign_keys="Approval.decided_by_id")


class Incident(Base):
    __tablename__ = "incidents"

    id = Column(String(36), primary_key=True, default=gen_uuid)
    organization_id = Column(String(36), ForeignKey("organizations.id", ondelete="CASCADE"), nullable=False)
    creator_id = Column(String(36), ForeignKey("users.id", ondelete="SET NULL"), nullable=True)
    title = Column(String(255), nullable=False)
    description = Column(Text, nullable=False)
    category = Column(String(100), default="Other", nullable=False)
    severity = Column(String(50), default="MEDIUM", nullable=False) # CRITICAL, HIGH, MEDIUM, LOW
    priority = Column(String(50), default="Medium", nullable=False) # Low, Medium, High, Critical
    status = Column(String(50), default="ACTIVE", nullable=False)   # ACTIVE, CONTAINED, RESOLVING, RESOLVED, ARCHIVED
    verification_status = Column(String(50), default="UNVERIFIED", nullable=False)
    deadline = Column(String(100), nullable=True)
    known_constraints = Column(Text, nullable=True)
    information_source = Column(String(255), nullable=True)
    created_at = Column(DateTime, default=utc_now)
    updated_at = Column(DateTime, default=utc_now, onupdate=utc_now)

    organization = relationship("Organization", back_populates="incidents")
    creator = relationship("User", back_populates="created_incidents")
    tasks = relationship("Task", back_populates="incident", cascade="all, delete-orphan")
    dependencies = relationship("TaskDependency", back_populates="incident", cascade="all, delete-orphan")
    recovery_plans = relationship("RecoveryPlan", back_populates="incident", cascade="all, delete-orphan")
    approvals = relationship("Approval", back_populates="incident", cascade="all, delete-orphan")
    audit_events = relationship("AuditEvent", back_populates="incident", cascade="all, delete-orphan")


class Task(Base):
    __tablename__ = "tasks"

    id = Column(String(36), primary_key=True, default=gen_uuid)
    incident_id = Column(String(36), ForeignKey("incidents.id", ondelete="CASCADE"), nullable=False)
    title = Column(String(255), nullable=False)
    description = Column(Text, nullable=True)
    status = Column(String(50), default="NOT_STARTED", nullable=False) # NOT_STARTED, IN_PROGRESS, BLOCKED, COMPLETED, CANCELLED
    assignee_id = Column(String(36), ForeignKey("users.id", ondelete="SET NULL"), nullable=True)
    deadline = Column(String(100), nullable=True)
    estimated_minutes = Column(Integer, default=60, nullable=False)
    priority_score = Column(Float, default=50.0, nullable=False)
    is_critical_path = Column(Boolean, default=False)
    risk_level = Column(String(50), default="NONE", nullable=False) # NONE, MODERATE, HIGH, CRITICAL
    created_at = Column(DateTime, default=utc_now)
    updated_at = Column(DateTime, default=utc_now, onupdate=utc_now)

    incident = relationship("Incident", back_populates="tasks")
    assignee = relationship("User")


class TaskDependency(Base):
    __tablename__ = "task_dependencies"

    id = Column(String(36), primary_key=True, default=gen_uuid)
    incident_id = Column(String(36), ForeignKey("incidents.id", ondelete="CASCADE"), nullable=False)
    source_task_id = Column(String(36), ForeignKey("tasks.id", ondelete="CASCADE"), nullable=False)
    target_task_id = Column(String(36), ForeignKey("tasks.id", ondelete="CASCADE"), nullable=False)
    relation_type = Column(String(50), default="BLOCKS", nullable=False) # BLOCKS, PREREQUISITE, REPLACES, AFFECTED_BY, REQUIRES_APPROVAL
    is_confirmed = Column(Boolean, default=True)
    created_at = Column(DateTime, default=utc_now)

    incident = relationship("Incident", back_populates="dependencies")
    source_task = relationship("Task", foreign_keys=[source_task_id])
    target_task = relationship("Task", foreign_keys=[target_task_id])


class RecoveryPlan(Base):
    __tablename__ = "recovery_plans"

    id = Column(String(36), primary_key=True, default=gen_uuid)
    incident_id = Column(String(36), ForeignKey("incidents.id", ondelete="CASCADE"), nullable=False)
    title = Column(String(255), nullable=False)
    strategy = Column(String(100), nullable=False) # MIN_DISRUPTION, FASTEST_FEASIBLE, LOWEST_RISK
    score = Column(Integer, default=80, nullable=False)
    is_selected = Column(Boolean, default=False)
    estimated_duration_mins = Column(Integer, default=120, nullable=False)
    risks = Column(Text, nullable=True)
    tradeoffs = Column(Text, nullable=True)
    created_at = Column(DateTime, default=utc_now)

    incident = relationship("Incident", back_populates="recovery_plans")
    actions = relationship("RecoveryAction", back_populates="plan", cascade="all, delete-orphan", order_by="RecoveryAction.order")


class RecoveryAction(Base):
    __tablename__ = "recovery_actions"

    id = Column(String(36), primary_key=True, default=gen_uuid)
    plan_id = Column(String(36), ForeignKey("recovery_plans.id", ondelete="CASCADE"), nullable=False)
    order = Column(Integer, default=1, nullable=False)
    title = Column(String(255), nullable=False)
    description = Column(Text, nullable=True)
    responsible_role = Column(String(100), default="Incident Commander", nullable=False)
    estimated_minutes = Column(Integer, default=30, nullable=False)
    requires_approval = Column(Boolean, default=True, nullable=False)
    action_type = Column(String(50), default="MANUAL_TASK", nullable=False)
    target_recipient = Column(String(255), nullable=True)
    payload = Column(JSON, nullable=True)
    is_completed = Column(Boolean, default=False)
    created_at = Column(DateTime, default=utc_now)

    plan = relationship("RecoveryPlan", back_populates="actions")
    approvals = relationship("Approval", back_populates="action")


class Approval(Base):
    __tablename__ = "approvals"

    id = Column(String(36), primary_key=True, default=gen_uuid)
    incident_id = Column(String(36), ForeignKey("incidents.id", ondelete="CASCADE"), nullable=False)
    plan_id = Column(String(36), ForeignKey("recovery_plans.id", ondelete="SET NULL"), nullable=True)
    action_id = Column(String(36), ForeignKey("recovery_actions.id", ondelete="SET NULL"), nullable=True)
    title = Column(String(255), nullable=False)
    description = Column(Text, nullable=True)
    action_type = Column(String(50), default="MANUAL_TASK", nullable=False)
    target_recipient = Column(String(255), nullable=True)
    payload = Column(JSON, nullable=True)
    status = Column(String(50), default="AWAITING_APPROVAL", nullable=False)
    requested_by_id = Column(String(36), ForeignKey("users.id", ondelete="SET NULL"), nullable=True)
    decided_by_id = Column(String(36), ForeignKey("users.id", ondelete="SET NULL"), nullable=True)
    decided_at = Column(DateTime, nullable=True)
    rejection_reason = Column(Text, nullable=True)
    execution_result = Column(Text, nullable=True)
    idempotency_key = Column(String(100), unique=True, index=True, nullable=True)
    created_at = Column(DateTime, default=utc_now)

    incident = relationship("Incident", back_populates="approvals")
    plan = relationship("RecoveryPlan")
    action = relationship("RecoveryAction", back_populates="approvals")
    requested_by = relationship("User", foreign_keys=[requested_by_id])
    decided_by = relationship("User", foreign_keys=[decided_by_id], overlaps="decided_approvals")


class AuditEvent(Base):
    __tablename__ = "audit_events"

    id = Column(String(36), primary_key=True, default=gen_uuid)
    incident_id = Column(String(36), ForeignKey("incidents.id", ondelete="CASCADE"), nullable=True)
    organization_id = Column(String(36), ForeignKey("organizations.id", ondelete="CASCADE"), nullable=False)
    actor_id = Column(String(36), ForeignKey("users.id", ondelete="SET NULL"), nullable=True)
    actor_name = Column(String(255), default="System", nullable=False)
    event_type = Column(String(100), nullable=False)
    summary = Column(String(255), nullable=False)
    details = Column(Text, nullable=True)
    created_at = Column(DateTime, default=utc_now)

    organization = relationship("Organization", back_populates="audit_events")
    incident = relationship("Incident", back_populates="audit_events")
    actor = relationship("User")


class Notification(Base):
    __tablename__ = "notifications"

    id = Column(String(36), primary_key=True, default=gen_uuid)
    user_id = Column(String(36), ForeignKey("users.id", ondelete="CASCADE"), nullable=False)
    organization_id = Column(String(36), ForeignKey("organizations.id", ondelete="CASCADE"), nullable=False)
    incident_id = Column(String(36), ForeignKey("incidents.id", ondelete="CASCADE"), nullable=True)
    title = Column(String(255), nullable=False)
    message = Column(Text, nullable=False)
    is_read = Column(Boolean, default=False)
    created_at = Column(DateTime, default=utc_now)

    user = relationship("User")
