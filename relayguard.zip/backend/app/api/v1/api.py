from fastapi import APIRouter
from app.api.v1.endpoints import (
    auth,
    incidents,
    tasks,
    dependencies,
    recovery_plans,
    approvals,
    actions,
    audit,
    ws
)

api_router = APIRouter()

api_router.include_router(auth.router, prefix="/auth", tags=["auth"])
api_router.include_router(incidents.router, prefix="/incidents", tags=["incidents"])
api_router.include_router(tasks.router, prefix="/tasks", tags=["tasks"])
api_router.include_router(dependencies.router, prefix="/dependencies", tags=["dependencies"])
api_router.include_router(recovery_plans.router, prefix="/recovery-plans", tags=["recovery-plans"])
api_router.include_router(approvals.router, prefix="/approvals", tags=["approvals"])
api_router.include_router(actions.router, prefix="/actions", tags=["actions"])
api_router.include_router(audit.router, prefix="/audit", tags=["audit"])
api_router.include_router(ws.router, tags=["websockets"])
