from typing import Dict, Any
from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session

from app.db.session import get_db
from app.models.entities import User
from app.schemas.all_schemas import ActionExecuteRequest
from app.api.deps import get_current_user
from app.services.execution_service import ExecutionService

router = APIRouter()

@router.post("/execute")
def execute_action(
    req: ActionExecuteRequest,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
) -> Dict[str, Any]:
    if not req.idempotency_key or not req.idempotency_key.strip():
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Field 'idempotency_key' is required for action execution."
        )

    result = ExecutionService.execute_action(
        db=db,
        approval_id=req.approval_id,
        idempotency_key=req.idempotency_key.strip(),
        user=current_user
    )
    return result
