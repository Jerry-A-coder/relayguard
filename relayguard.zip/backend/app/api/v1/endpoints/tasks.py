from typing import List, Optional
from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session

from app.db.session import get_db
from app.models.entities import Task, Incident, User
from app.schemas.all_schemas import TaskCreate, TaskUpdate, TaskOut
from app.api.deps import get_current_user
from app.services.replanning_service import ReplanningService
from app.services.audit_service import AuditService

router = APIRouter()

@router.get("", response_model=List[TaskOut])
def list_tasks(
    incident_id: Optional[str] = None,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    query = db.query(Task)
    if incident_id:
        query = query.filter(Task.incident_id == incident_id)
    return query.order_by(Task.created_at.asc()).all()

@router.post("", response_model=TaskOut, status_code=status.HTTP_201_CREATED)
def create_task(
    task_in: TaskCreate,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    incident = db.query(Incident).filter(Incident.id == task_in.incident_id).first()
    if not incident:
        raise HTTPException(status_code=404, detail="Associated incident not found")

    task = Task(
        incident_id=task_in.incident_id,
        title=task_in.title,
        description=task_in.description,
        status=task_in.status or "NOT_STARTED",
        assignee_id=task_in.assignee_id,
        deadline=task_in.deadline,
        estimated_minutes=task_in.estimated_minutes or 60,
        risk_level=task_in.risk_level or "NONE",
    )
    db.add(task)
    db.commit()
    db.refresh(task)

    ReplanningService.recalculate_incident_graph(db, incident.id, current_user)
    db.refresh(task)

    AuditService.log_event(
        db=db,
        organization_id=current_user.organization_id,
        incident_id=incident.id,
        actor=current_user,
        event_type="TASK_CREATED",
        summary=f"Task created: '{task.title}'",
        details=f"Estimated {task.estimated_minutes}m"
    )

    return task

@router.get("/{task_id}", response_model=TaskOut)
def get_task(
    task_id: str,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    task = db.query(Task).filter(Task.id == task_id).first()
    if not task:
        raise HTTPException(status_code=404, detail="Task not found")
    return task

@router.put("/{task_id}", response_model=TaskOut)
def update_task(
    task_id: str,
    update_data: TaskUpdate,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    task = db.query(Task).filter(Task.id == task_id).first()
    if not task:
        raise HTTPException(status_code=404, detail="Task not found")

    old_status = task.status
    for field, val in update_data.model_dump(exclude_unset=True).items():
        setattr(task, field, val)

    db.commit()
    db.refresh(task)

    ReplanningService.recalculate_incident_graph(db, task.incident_id, current_user)
    db.refresh(task)

    AuditService.log_event(
        db=db,
        organization_id=current_user.organization_id,
        incident_id=task.incident_id,
        actor=current_user,
        event_type="TASK_UPDATED",
        summary=f"Task '{task.title}' status shifted from {old_status} to {task.status}",
        details=f"Priority Score: {task.priority_score}, Risk: {task.risk_level}"
    )

    return task

@router.delete("/{task_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_task(
    task_id: str,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    task = db.query(Task).filter(Task.id == task_id).first()
    if not task:
        raise HTTPException(status_code=404, detail="Task not found")

    incident_id = task.incident_id
    db.delete(task)
    db.commit()

    ReplanningService.recalculate_incident_graph(db, incident_id, current_user)
    return None
