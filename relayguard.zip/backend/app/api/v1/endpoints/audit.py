from typing import List, Optional
from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from app.db.session import get_db
from app.models.entities import AuditEvent, User
from app.schemas.all_schemas import AuditEventOut
from app.api.deps import get_current_user

router = APIRouter()

@router.get("", response_model=List[AuditEventOut])
def list_audit_events(
    incident_id: Optional[str] = None,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    query = db.query(AuditEvent).filter(AuditEvent.organization_id == current_user.organization_id)
    if incident_id:
        query = query.filter(AuditEvent.incident_id == incident_id)
    return query.order_by(AuditEvent.created_at.desc()).limit(100).all()
