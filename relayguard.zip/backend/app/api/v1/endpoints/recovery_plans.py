from typing import List
from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel
from sqlalchemy.orm import Session

from app.db.session import get_db
from app.models.entities import Incident, Task, TaskDependency, RecoveryPlan, RecoveryAction, Approval, User
from app.schemas.all_schemas import RecoveryPlanOut, RecoveryPlanSelect
from app.api.deps import get_current_user
from app.services.recovery_planner import RecoveryPlanner
from app.services.audit_service import AuditService

router = APIRouter()

class GeneratePlansRequest(BaseModel):
    incident_id: str

@router.get("", response_model=List[RecoveryPlanOut])
def list_recovery_plans(
    incident_id: str,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    plans = db.query(RecoveryPlan).filter(RecoveryPlan.incident_id == incident_id).all()
    return plans

@router.post("/generate", response_model=List[RecoveryPlanOut])
def generate_recovery_plans(
    req: GeneratePlansRequest,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    incident = db.query(Incident).filter(Incident.id == req.incident_id).first()
    if not incident:
        raise HTTPException(status_code=404, detail="Incident not found")

    tasks = db.query(Task).filter(Task.incident_id == req.incident_id).all()
    dependencies = db.query(TaskDependency).filter(TaskDependency.incident_id == req.incident_id).all()

    generated_data = RecoveryPlanner.generate_plans(incident, tasks, dependencies)

    old_plans = db.query(RecoveryPlan).filter(
        RecoveryPlan.incident_id == req.incident_id,
        RecoveryPlan.is_selected == False
    ).all()
    for op in old_plans:
        db.delete(op)
    db.commit()

    saved_plans = []
    for pdata in generated_data:
        plan = RecoveryPlan(
            incident_id=req.incident_id,
            title=pdata["title"],
            strategy=pdata["strategy"],
            score=pdata["score"],
            is_selected=False,
            estimated_duration_mins=pdata["estimated_duration_mins"],
            risks=pdata["risks"],
            tradeoffs=pdata["tradeoffs"]
        )
        db.add(plan)
        db.flush()

        for act in pdata["actions"]:
            action = RecoveryAction(
                plan_id=plan.id,
                order=act["order"],
                title=act["title"],
                description=act["description"],
                responsible_role=act["responsible_role"],
                estimated_minutes=act["estimated_minutes"],
                requires_approval=act["requires_approval"],
                action_type=act["action_type"],
                target_recipient=act["target_recipient"],
                payload=act["payload"],
                is_completed=False
            )
            db.add(action)

        db.commit()
        db.refresh(plan)
        saved_plans.append(plan)

    AuditService.log_event(
        db=db,
        organization_id=current_user.organization_id,
        incident_id=incident.id,
        actor=current_user,
        event_type="PLAN_GENERATED",
        summary=f"Synthesized 3 contingency plans for '{incident.title}'",
        details="Plans: Accelerated Parallel Path, Fast-Track Bypass, Grace Window"
    )

    return saved_plans

@router.post("/select", response_model=RecoveryPlanOut)
def select_recovery_plan(
    req: RecoveryPlanSelect,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    plan = db.query(RecoveryPlan).filter(RecoveryPlan.id == req.plan_id).first()
    if not plan:
        raise HTTPException(status_code=404, detail="Recovery plan not found")

    db.query(RecoveryPlan).filter(RecoveryPlan.incident_id == plan.incident_id).update({"is_selected": False})
    plan.is_selected = True
    db.commit()

    for action in plan.actions:
        if action.requires_approval:
            existing_app = db.query(Approval).filter(Approval.action_id == action.id).first()
            if not existing_app:
                approval = Approval(
                    incident_id=plan.incident_id,
                    plan_id=plan.id,
                    action_id=action.id,
                    title=action.title,
                    description=action.description,
                    action_type=action.action_type,
                    target_recipient=action.target_recipient,
                    payload=action.payload,
                    status="AWAITING_APPROVAL",
                    requested_by_id=current_user.id
                )
                db.add(approval)

    db.commit()
    db.refresh(plan)

    AuditService.log_event(
        db=db,
        organization_id=current_user.organization_id,
        incident_id=plan.incident_id,
        actor=current_user,
        event_type="PLAN_SELECTED",
        summary=f"Active Recovery Plan adopted: '{plan.title}'",
        details=f"Strategy: {plan.strategy}, Score: {plan.score}%"
    )

    return plan
