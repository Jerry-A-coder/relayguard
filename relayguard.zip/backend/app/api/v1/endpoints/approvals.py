from typing import List, Optional
from fastapi import APIRouter, Depends, status
from sqlalchemy.orm import Session

from app.db.session import get_db
from app.models.entities import Approval, User
from app.schemas.all_schemas import ApprovalCreate, ApprovalDecision, ApprovalOut
from app.api.deps import get_current_user
from app.services.approval_service import ApprovalService

router = APIRouter()

@router.get("", response_model=List[ApprovalOut])
def list_approvals(
    incident_id: Optional[str] = None,
    status: Optional[str] = None,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    query = db.query(Approval)
    if incident_id:
        query = query.filter(Approval.incident_id == incident_id)
    if status:
        query = query.filter(Approval.status == status)
    return query.order_by(Approval.created_at.desc()).all()

@router.post("", response_model=ApprovalOut, status_code=status.HTTP_201_CREATED)
def create_approval(
    app_in: ApprovalCreate,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    approval = Approval(
        incident_id=app_in.incident_id,
        plan_id=app_in.plan_id,
        action_id=app_in.action_id,
        title=app_in.title,
        description=app_in.description,
        action_type=app_in.action_type,
        target_recipient=app_in.target_recipient,
        payload=app_in.payload,
        status="AWAITING_APPROVAL",
        requested_by_id=current_user.id
    )
    db.add(approval)
    db.commit()
    db.refresh(approval)
    return approval

@router.post("/{approval_id}/decide", response_model=ApprovalOut)
def decide_approval(
    approval_id: str,
    decision_in: ApprovalDecision,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    approval = ApprovalService.decide_approval(
        db=db,
        approval_id=approval_id,
        user=current_user,
        decision=decision_in.status,
        rejection_reason=decision_in.rejection_reason
    )
    return approval
