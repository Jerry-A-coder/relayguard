from typing import List, Optional
from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session

from app.db.session import get_db
from app.models.entities import Incident, User
from app.schemas.all_schemas import IncidentCreate, IncidentUpdate, IncidentOut
from app.api.deps import get_current_user
from app.services.audit_service import AuditService

router = APIRouter()

@router.get("", response_model=List[IncidentOut])
def list_incidents(
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
    status: Optional[str] = None
):
    query = db.query(Incident).filter(Incident.organization_id == current_user.organization_id)
    if status:
        query = query.filter(Incident.status == status)
    return query.order_by(Incident.created_at.desc()).all()

@router.post("", response_model=IncidentOut, status_code=status.HTTP_201_CREATED)
def create_incident(
    incident_in: IncidentCreate,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    incident = Incident(
        organization_id=current_user.organization_id,
        creator_id=current_user.id,
        title=incident_in.title,
        description=incident_in.description,
        category=incident_in.category or "Other",
        severity=incident_in.severity or "MEDIUM",
        priority=incident_in.priority or "Medium",
        status=incident_in.status or "ACTIVE",
        verification_status=incident_in.verification_status or "UNVERIFIED",
        deadline=incident_in.deadline,
        known_constraints=incident_in.known_constraints,
        information_source=incident_in.information_source,
    )
    db.add(incident)
    db.commit()
    db.refresh(incident)

    AuditService.log_event(
        db=db,
        organization_id=current_user.organization_id,
        incident_id=incident.id,
        actor=current_user,
        event_type="INCIDENT_CREATED",
        summary=f"Disruption incident declared: '{incident.title}' (Priority: {incident.priority})",
        details=incident.description
    )

    return incident

@router.get("/{incident_id}", response_model=IncidentOut)
def get_incident(
    incident_id: str,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    incident = db.query(Incident).filter(
        Incident.id == incident_id,
        Incident.organization_id == current_user.organization_id
    ).first()
    if not incident:
        raise HTTPException(status_code=404, detail="Incident not found")
    return incident

@router.put("/{incident_id}", response_model=IncidentOut)
def update_incident(
    incident_id: str,
    update_data: IncidentUpdate,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    incident = db.query(Incident).filter(
        Incident.id == incident_id,
        Incident.organization_id == current_user.organization_id
    ).first()
    if not incident:
        raise HTTPException(status_code=404, detail="Incident not found")

    for field, val in update_data.model_dump(exclude_unset=True).items():
        setattr(incident, field, val)

    db.commit()
    db.refresh(incident)

    AuditService.log_event(
        db=db,
        organization_id=current_user.organization_id,
        incident_id=incident.id,
        actor=current_user,
        event_type="INCIDENT_UPDATED",
        summary=f"Incident '{incident.title}' updated",
        details=f"Status: {incident.status}, Priority: {incident.priority}"
    )

    return incident

@router.delete("/{incident_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_incident(
    incident_id: str,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    incident = db.query(Incident).filter(
        Incident.id == incident_id,
        Incident.organization_id == current_user.organization_id
    ).first()
    if not incident:
        raise HTTPException(status_code=404, detail="Incident not found")

    db.delete(incident)
    db.commit()
    return None
