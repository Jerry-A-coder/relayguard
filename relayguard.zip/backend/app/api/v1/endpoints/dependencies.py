from typing import List, Optional
from fastapi import APIRouter, Depends, HTTPException, status
from pydantic import BaseModel
from sqlalchemy.orm import Session

from app.db.session import get_db
from app.models.entities import TaskDependency, Task, User
from app.schemas.all_schemas import DependencyCreate, DependencyOut, ImpactAnalysisResult
from app.api.deps import get_current_user
from app.services.dependency_engine import DependencyEngine
from app.services.replanning_service import ReplanningService
from app.services.audit_service import AuditService

router = APIRouter()

class ImpactAnalysisRequest(BaseModel):
    incident_id: str
    disrupted_task_id: Optional[str] = None

@router.get("", response_model=List[DependencyOut])
def list_dependencies(
    incident_id: Optional[str] = None,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    query = db.query(TaskDependency)
    if incident_id:
        query = query.filter(TaskDependency.incident_id == incident_id)
    return query.all()

@router.post("", response_model=DependencyOut, status_code=status.HTTP_201_CREATED)
def create_dependency(
    dep_in: DependencyCreate,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    if dep_in.source_task_id == dep_in.target_task_id:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="A task cannot depend on itself."
        )

    src_task = db.query(Task).filter(Task.id == dep_in.source_task_id).first()
    dst_task = db.query(Task).filter(Task.id == dep_in.target_task_id).first()
    if not src_task or not dst_task:
        raise HTTPException(status_code=404, detail="Source or target task not found")

    existing_deps = db.query(TaskDependency).filter(
        TaskDependency.incident_id == dep_in.incident_id
    ).all()
    existing_edges = [(d.source_task_id, d.target_task_id) for d in existing_deps]

    all_tasks = db.query(Task).filter(Task.incident_id == dep_in.incident_id).all()
    all_task_ids = [t.id for t in all_tasks]

    new_edge = (dep_in.source_task_id, dep_in.target_task_id)
    if DependencyEngine.will_create_cycle(all_task_ids, existing_edges, new_edge):
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Circular dependency rejected: Adding this dependency would create a cycle deadlock in the workflow."
        )

    dep = TaskDependency(
        incident_id=dep_in.incident_id,
        source_task_id=dep_in.source_task_id,
        target_task_id=dep_in.target_task_id,
        relation_type=dep_in.relation_type or "BLOCKS",
        is_confirmed=dep_in.is_confirmed if dep_in.is_confirmed is not None else True,
    )
    db.add(dep)
    db.commit()
    db.refresh(dep)

    ReplanningService.recalculate_incident_graph(db, dep_in.incident_id, current_user)

    AuditService.log_event(
        db=db,
        organization_id=current_user.organization_id,
        incident_id=dep_in.incident_id,
        actor=current_user,
        event_type="DEPENDENCY_ADDED",
        summary=f"Dependency created: '{src_task.title}' -> '{dst_task.title}' ({dep.relation_type})",
        details="Cycle validation passed successfully"
    )

    return dep

@router.delete("/{dep_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_dependency(
    dep_id: str,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    dep = db.query(TaskDependency).filter(TaskDependency.id == dep_id).first()
    if not dep:
        raise HTTPException(status_code=404, detail="Dependency not found")

    incident_id = dep.incident_id
    db.delete(dep)
    db.commit()

    ReplanningService.recalculate_incident_graph(db, incident_id, current_user)
    return None

@router.post("/impact-analysis", response_model=ImpactAnalysisResult)
def run_impact_analysis(
    req: ImpactAnalysisRequest,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    tasks = db.query(Task).filter(Task.incident_id == req.incident_id).all()
    deps = db.query(TaskDependency).filter(TaskDependency.incident_id == req.incident_id).all()

    task_ids = [t.id for t in tasks]
    edges = [(d.source_task_id, d.target_task_id) for d in deps]
    durations = {t.id: t.estimated_minutes for t in tasks}
    statuses = {t.id: t.status for t in tasks}

    has_cycle, cycle_nodes = DependencyEngine.detect_cycle(task_ids, edges)
    success, topo_order = DependencyEngine.topological_sort(task_ids, edges)
    crit_path, crit_duration = DependencyEngine.calculate_critical_path(task_ids, durations, edges)
    blocked_ids = DependencyEngine.determine_blocked_tasks(task_ids, statuses, edges)

    affected_ids = []
    if req.disrupted_task_id:
        affected_ids = DependencyEngine.calculate_downstream_impact(req.disrupted_task_id, edges)

    return {
        "has_cycle": has_cycle,
        "cycle_nodes": cycle_nodes,
        "topological_order": topo_order if success else [],
        "critical_path": crit_path,
        "critical_path_duration": crit_duration,
        "affected_task_ids": affected_ids,
        "blocked_task_ids": blocked_ids,
        "total_tasks": len(tasks),
    }
