from typing import List, Optional, Dict, Any
from datetime import datetime
from pydantic import BaseModel, Field

# ----------------- Auth Schemas -----------------
class UserRegister(BaseModel):
    email: str
    password: str
    full_name: str
    organization_name: Optional[str] = "RelayGuard Operations"
    role: Optional[str] = "ADMIN"

class UserLogin(BaseModel):
    email: str
    password: str

class Token(BaseModel):
    access_token: str
    token_type: str = "bearer"
    user: Dict[str, Any]

class UserOut(BaseModel):
    id: str
    email: str
    full_name: str
    role: str
    organization_id: str
    is_active: bool
    created_at: datetime

    class Config:
        from_attributes = True

# ----------------- Incident Schemas -----------------
class IncidentCreate(BaseModel):
    title: str
    description: str
    category: Optional[str] = "Other"
    severity: Optional[str] = "MEDIUM"
    priority: Optional[str] = "Medium"
    status: Optional[str] = "ACTIVE"
    verification_status: Optional[str] = "UNVERIFIED"
    deadline: Optional[str] = None
    known_constraints: Optional[str] = None
    information_source: Optional[str] = None

class IncidentUpdate(BaseModel):
    title: Optional[str] = None
    description: Optional[str] = None
    category: Optional[str] = None
    severity: Optional[str] = None
    priority: Optional[str] = None
    status: Optional[str] = None
    verification_status: Optional[str] = None
    deadline: Optional[str] = None
    known_constraints: Optional[str] = None
    information_source: Optional[str] = None

class IncidentOut(BaseModel):
    id: str
    organization_id: str
    creator_id: Optional[str] = None
    title: str
    description: str
    category: str
    severity: str
    priority: str
    status: str
    verification_status: str
    deadline: Optional[str] = None
    known_constraints: Optional[str] = None
    information_source: Optional[str] = None
    created_at: datetime
    updated_at: datetime

    class Config:
        from_attributes = True

# ----------------- Task Schemas -----------------
class TaskCreate(BaseModel):
    incident_id: str
    title: str
    description: Optional[str] = ""
    status: Optional[str] = "NOT_STARTED"
    assignee_id: Optional[str] = None
    deadline: Optional[str] = None
    estimated_minutes: Optional[int] = 60
    risk_level: Optional[str] = "NONE"

class TaskUpdate(BaseModel):
    title: Optional[str] = None
    description: Optional[str] = None
    status: Optional[str] = None
    assignee_id: Optional[str] = None
    deadline: Optional[str] = None
    estimated_minutes: Optional[int] = None
    risk_level: Optional[str] = None
    priority_score: Optional[float] = None
    is_critical_path: Optional[bool] = None

class TaskOut(BaseModel):
    id: str
    incident_id: str
    title: str
    description: Optional[str] = None
    status: str
    assignee_id: Optional[str] = None
    deadline: Optional[str] = None
    estimated_minutes: int
    priority_score: float
    is_critical_path: bool
    risk_level: str
    created_at: datetime
    updated_at: datetime

    class Config:
        from_attributes = True

# ----------------- Dependency Schemas -----------------
class DependencyCreate(BaseModel):
    incident_id: str
    source_task_id: str
    target_task_id: str
    relation_type: Optional[str] = "BLOCKS"
    is_confirmed: Optional[bool] = True

class DependencyOut(BaseModel):
    id: str
    incident_id: str
    source_task_id: str
    target_task_id: str
    relation_type: str
    is_confirmed: bool
    created_at: datetime

    class Config:
        from_attributes = True

# ----------------- Graph Analysis Result -----------------
class ImpactAnalysisResult(BaseModel):
    has_cycle: bool
    cycle_nodes: List[str]
    topological_order: List[str]
    critical_path: List[str]
    critical_path_duration: int
    affected_task_ids: List[str]
    blocked_task_ids: List[str]
    total_tasks: int

# ----------------- Recovery Plan Schemas -----------------
class RecoveryActionOut(BaseModel):
    id: str
    plan_id: str
    order: int
    title: str
    description: Optional[str] = None
    responsible_role: str
    estimated_minutes: int
    requires_approval: bool
    action_type: str
    target_recipient: Optional[str] = None
    payload: Optional[Dict[str, Any]] = None
    is_completed: bool

    class Config:
        from_attributes = True

class RecoveryPlanOut(BaseModel):
    id: str
    incident_id: str
    title: str
    strategy: str
    score: int
    is_selected: bool
    estimated_duration_mins: int
    risks: Optional[str] = None
    tradeoffs: Optional[str] = None
    actions: List[RecoveryActionOut] = []
    created_at: datetime

    class Config:
        from_attributes = True

class RecoveryPlanSelect(BaseModel):
    plan_id: str

# ----------------- Approval & Execution Schemas -----------------
class ApprovalCreate(BaseModel):
    incident_id: str
    plan_id: Optional[str] = None
    action_id: Optional[str] = None
    title: str
    description: Optional[str] = None
    action_type: str
    target_recipient: Optional[str] = None
    payload: Optional[Dict[str, Any]] = None

class ApprovalDecision(BaseModel):
    status: str
    rejection_reason: Optional[str] = None

class ActionExecuteRequest(BaseModel):
    approval_id: str
    idempotency_key: str

class ApprovalOut(BaseModel):
    id: str
    incident_id: str
    plan_id: Optional[str] = None
    action_id: Optional[str] = None
    title: str
    description: Optional[str] = None
    action_type: str
    target_recipient: Optional[str] = None
    payload: Optional[Dict[str, Any]] = None
    status: str
    requested_by_id: Optional[str] = None
    decided_by_id: Optional[str] = None
    decided_at: Optional[datetime] = None
    rejection_reason: Optional[str] = None
    execution_result: Optional[str] = None
    idempotency_key: Optional[str] = None
    created_at: datetime

    class Config:
        from_attributes = True

# ----------------- Audit Schemas -----------------
class AuditEventOut(BaseModel):
    id: str
    incident_id: Optional[str] = None
    organization_id: str
    actor_id: Optional[str] = None
    actor_name: str
    event_type: str
    summary: str
    details: Optional[str] = None
    created_at: datetime

    class Config:
        from_attributes = True
