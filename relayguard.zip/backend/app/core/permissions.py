from enum import Enum
from typing import List
from fastapi import HTTPException, status

class UserRole(str, Enum):
    OWNER = "OWNER"
    ADMIN = "ADMIN"
    MEMBER = "MEMBER"
    VIEWER = "VIEWER"

ROLE_HIERARCHY = {
    UserRole.OWNER: 4,
    UserRole.ADMIN: 3,
    UserRole.MEMBER: 2,
    UserRole.VIEWER: 1,
}

def check_role_permission(user_role: str, required_roles: List[UserRole]) -> bool:
    try:
        current_enum = UserRole(user_role)
    except ValueError:
        return False
    return current_enum in required_roles or any(
        ROLE_HIERARCHY.get(current_enum, 0) >= ROLE_HIERARCHY.get(req, 99)
        for req in required_roles
    )

def require_role(user_role: str, required_roles: List[UserRole]):
    if not check_role_permission(user_role, required_roles):
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail=f"Operation requires one of roles: {[r.value for r in required_roles]}. Current role: {user_role}"
        )
