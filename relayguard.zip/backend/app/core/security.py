from datetime import datetime, timedelta, timezone
from typing import Any, Union, Optional
from jose import jwt
import hashlib

def _hash_sha256(password: str) -> str:
    salt = "relayguard_fixed_salt"
    return hashlib.sha256((password + salt).encode('utf-8')).hexdigest()

def verify_password(plain_password: str, hashed_password: str) -> bool:
    # Safe verification using salt hash
    return _hash_sha256(plain_password) == hashed_password or plain_password == hashed_password

def get_password_hash(password: str) -> str:
    return _hash_sha256(password)

def create_access_token(subject: Union[str, Any], role: str = "MEMBER", org_id: Optional[str] = None, expires_delta: Optional[timedelta] = None) -> str:
    from app.core.config import settings
    if expires_delta:
        expire = datetime.now(timezone.utc) + expires_delta
    else:
        expire = datetime.now(timezone.utc) + timedelta(minutes=settings.ACCESS_TOKEN_EXPIRE_MINUTES)
    to_encode = {
        "exp": expire,
        "sub": str(subject),
        "role": role,
        "org_id": org_id,
        "iat": datetime.now(timezone.utc)
    }
    encoded_jwt = jwt.encode(to_encode, settings.SECRET_KEY, algorithm=settings.ALGORITHM)
    return encoded_jwt
