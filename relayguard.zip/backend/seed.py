import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from app.db.session import SessionLocal, engine, Base
from app.models.entities import (
    Organization, User, Incident, Task, TaskDependency, RecoveryPlan, RecoveryAction, Approval, AuditEvent
)
from app.core.security import get_password_hash
from app.services.dependency_engine import DependencyEngine
from app.services.prioritization_engine import PrioritizationEngine
from app.services.recovery_planner import RecoveryPlanner

def run_seed():
    print("🌱 Initializing RelayGuard Database Schema...")
    Base.metadata.create_all(bind=engine)

    db = SessionLocal()
    try:
        existing_org = db.query(Organization).filter(Organization.slug == "stanford-capstone").first()
        if existing_org:
            print("Database already contains seed data for Stanford Capstone. Refreshing seed...")
            db.query(Organization).filter(Organization.slug == "stanford-capstone").delete()
            db.commit()

        print("🏢 Creating Organization...")
        org = Organization(
            name="Stanford School of Engineering - Senior Capstone",
            slug="stanford-capstone"
        )
        db.add(org)
        db.flush()

        print("👥 Creating Users...")
        owner = User(
            organization_id=org.id,
            email="marcus.vance@stanford.edu",
            hashed_password=get_password_hash("RelayGuard2026!"),
            full_name="Dr. Marcus Vance",
            role="OWNER"
        )
        admin = User(
            organization_id=org.id,
            email="sarah.lin@stanford.edu",
            hashed_password=get_password_hash("RelayGuard2026!"),
            full_name="Sarah Lin (Head TA)",
            role="ADMIN"
        )
        member = User(
            organization_id=org.id,
            email="alex.rivera@stanford.edu",
            hashed_password=get_password_hash("RelayGuard2026!"),
            full_name="Alex Rivera (Student Lead)",
            role="MEMBER"
        )
        db.add_all([owner, admin, member])
        db.flush()

        print("🚨 Creating Disruption Incident (Student Capstone Failure)...")
        incident = Incident(
            organization_id=org.id,
            creator_id=member.id,
            title="Autonomous Drone Capstone: Flight Sensor Telemetry Burnout",
            description="During pre-flight telemetry calibration 48 hours prior to final demonstration deadline, the primary IMU sensor array burned out due to voltage regulator spike. Without telemetry data, safety validation cannot proceed, blocking hardware sign-off and final video demonstration submission.",
            category="Dependency failure",
            severity="CRITICAL",
            priority="Critical",
            status="ACTIVE",
            verification_status="VERIFIED",
            deadline="2026-10-31T17:00:00Z",
            known_constraints="Hard submission deadline to Academic Review Board. PCB revision requires 3 business days unless expedited courier is used. Flight testing venue closes at dusk.",
            information_source="Lab Hardware Bench Diagnostic #4"
        )
        db.add(incident)
        db.flush()

        print("📋 Creating DAG Tasks...")
        t_a = Task(
            incident_id=incident.id,
            title="Procure Replacement Optical Flow & IMU Sensor Unit",
            description="Acquire drop-in replacement sensor module from local Bay Area distributor warehouse.",
            status="BLOCKED",
            assignee_id=member.id,
            estimated_minutes=180,
            deadline="2026-10-24T12:00:00Z"
        )
        t_b = Task(
            incident_id=incident.id,
            title="Soldering & Hardware Harness Integration",
            description="Bench-solder telemetry pins with inline voltage surge protection.",
            status="NOT_STARTED",
            assignee_id=member.id,
            estimated_minutes=90,
            deadline="2026-10-24T15:00:00Z"
        )
        t_c = Task(
            incident_id=incident.id,
            title="Firmware Flash & Low-Level Calibration Test",
            description="Flash PX4 telemetry daemon and calibrate compass, gyro, and accelerometer.",
            status="NOT_STARTED",
            assignee_id=admin.id,
            estimated_minutes=60,
            deadline="2026-10-24T17:00:00Z"
        )
        t_d = Task(
            incident_id=incident.id,
            title="Outdoor Flight Stability Safety Verification",
            description="FAA-compliant airfield hover, geofence return-to-launch, and failsafe test flight.",
            status="NOT_STARTED",
            assignee_id=owner.id,
            estimated_minutes=120,
            deadline="2026-10-25T11:00:00Z"
        )
        t_e = Task(
            incident_id=incident.id,
            title="Final Video Recording & Capstone Submission Assembly",
            description="Package flight telemetry overlay, video demonstration, and upload submission bundle.",
            status="NOT_STARTED",
            assignee_id=member.id,
            estimated_minutes=90,
            deadline="2026-10-25T16:00:00Z"
        )
        t_f = Task(
            incident_id=incident.id,
            title="Academic Peer Review & Code Audit Signoff",
            description="TA and faculty code audit of PID controller changes and flight logs.",
            status="NOT_STARTED",
            assignee_id=admin.id,
            estimated_minutes=45,
            deadline="2026-10-25T14:00:00Z"
        )
        tasks = [t_a, t_b, t_c, t_d, t_e, t_f]
        db.add_all(tasks)
        db.flush()

        print("🔗 Establishing Dependency Graph Edges...")
        deps = [
            TaskDependency(incident_id=incident.id, source_task_id=t_a.id, target_task_id=t_b.id, relation_type="BLOCKS"),
            TaskDependency(incident_id=incident.id, source_task_id=t_b.id, target_task_id=t_c.id, relation_type="BLOCKS"),
            TaskDependency(incident_id=incident.id, source_task_id=t_c.id, target_task_id=t_d.id, relation_type="BLOCKS"),
            TaskDependency(incident_id=incident.id, source_task_id=t_d.id, target_task_id=t_e.id, relation_type="BLOCKS"),
            TaskDependency(incident_id=incident.id, source_task_id=t_c.id, target_task_id=t_f.id, relation_type="BLOCKS"),
            TaskDependency(incident_id=incident.id, source_task_id=t_f.id, target_task_id=t_e.id, relation_type="BLOCKS"),
        ]
        db.add_all(deps)
        db.flush()

        task_ids = [t.id for t in tasks]
        edges = [(d.source_task_id, d.target_task_id) for d in deps]
        durations = {t.id: t.estimated_minutes for t in tasks}
        statuses = {t.id: t.status for t in tasks}

        crit_path, _ = DependencyEngine.calculate_critical_path(task_ids, durations, edges)
        priorities = PrioritizationEngine.calculate_task_priorities(
            task_ids=task_ids,
            task_durations=durations,
            task_statuses=statuses,
            edges=edges,
            incident_severity=incident.severity,
            incident_priority=incident.priority
        )

        for t in tasks:
            t.is_critical_path = t.id in set(crit_path)
            p_info = priorities.get(t.id, {})
            t.priority_score = p_info.get("priority_score", 50.0)
            t.risk_level = p_info.get("risk_level", "NONE")

        print("💡 Synthesizing Multi-Alternative Recovery Plans...")
        generated_plans = RecoveryPlanner.generate_plans(incident, tasks, deps)

        for idx, pdata in enumerate(generated_plans):
            is_sel = (idx == 0)
            plan = RecoveryPlan(
                incident_id=incident.id,
                title=pdata["title"],
                strategy=pdata["strategy"],
                score=pdata["score"],
                is_selected=is_sel,
                estimated_duration_mins=pdata["estimated_duration_mins"],
                risks=pdata["risks"],
                tradeoffs=pdata["tradeoffs"]
            )
            db.add(plan)
            db.flush()

            for act in pdata["actions"]:
                action = RecoveryAction(
                    plan_id=plan.id,
                    order=act["order"],
                    title=act["title"],
                    description=act["description"],
                    responsible_role=act["responsible_role"],
                    estimated_minutes=act["estimated_minutes"],
                    requires_approval=act["requires_approval"],
                    action_type=act["action_type"],
                    target_recipient=act["target_recipient"],
                    payload=act["payload"],
                    is_completed=False
                )
                db.add(action)
                db.flush()

                if is_sel and action.requires_approval:
                    approval = Approval(
                        incident_id=incident.id,
                        plan_id=plan.id,
                        action_id=action.id,
                        title=action.title,
                        description=action.description,
                        action_type=action.action_type,
                        target_recipient=action.target_recipient,
                        payload=action.payload,
                        status="AWAITING_APPROVAL",
                        requested_by_id=member.id
                    )
                    db.add(approval)

        print("📜 Generating Baseline Audit Trail...")
        events = [
            AuditEvent(
                organization_id=org.id,
                incident_id=incident.id,
                actor_id=member.id,
                actor_name=member.full_name,
                event_type="INCIDENT_CREATED",
                summary="Disruption incident reported: Sensor Telemetry Burnout",
                details="Voltage spike detected on hardware bench."
            ),
            AuditEvent(
                organization_id=org.id,
                incident_id=incident.id,
                actor_id=admin.id,
                actor_name=admin.full_name,
                event_type="PLAN_GENERATED",
                summary="Synthesized 3 Recovery Strategies (Accelerated, Fast-Track, Grace Window)",
                details="Plan A selected as primary response plan."
            ),
            AuditEvent(
                organization_id=org.id,
                incident_id=incident.id,
                actor_id=owner.id,
                actor_name=owner.full_name,
                event_type="APPROVAL_REQUESTED",
                summary="Pending Approval: Authorize Emergency Resource Reallocation",
                details="Awaiting faculty advisor signoff."
            ),
        ]
        db.add_all(events)
        db.commit()

        print("✅ Seed scenario successfully generated!")
        print(f"   Organization: {org.name}")
        print(f"   Owner: {owner.email} / RelayGuard2026!")
        print(f"   Admin: {admin.email} / RelayGuard2026!")
        print(f"   Member: {member.email} / RelayGuard2026!")
        print(f"   Incident ID: {incident.id}")

    finally:
        db.close()

if __name__ == "__main__":
    run_seed()
