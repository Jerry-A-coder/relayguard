def test_register_user(client):
    response = client.post("/api/v1/auth/register", json={
        "email": "newuser@relayguard.io",
        "password": "SecurePassword123!",
        "full_name": "New Officer",
        "organization_name": "Crisis Ops Unit",
        "role": "ADMIN"
    })
    assert response.status_code == 200
    data = response.json()
    assert "access_token" in data
    assert data["user"]["email"] == "newuser@relayguard.io"

def test_login_success(client, admin_user):
    response = client.post("/api/v1/auth/login", json={
        "email": admin_user.email,
        "password": "TestPass123!"
    })
    assert response.status_code == 200
    data = response.json()
    assert "access_token" in data
    assert data["user"]["email"] == admin_user.email

def test_login_invalid_credentials(client, admin_user):
    response = client.post("/api/v1/auth/login", json={
        "email": admin_user.email,
        "password": "WrongPassword!"
    })
    assert response.status_code == 401
    assert "Invalid email or password" in response.json()["detail"]

def test_get_current_user_me(client, admin_token, admin_user):
    response = client.get("/api/v1/auth/me", headers={"Authorization": f"Bearer {admin_token}"})
    assert response.status_code == 200
    assert response.json()["email"] == admin_user.email
