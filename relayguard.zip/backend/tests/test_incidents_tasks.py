def test_create_and_list_incident(client, admin_token):
    headers = {"Authorization": f"Bearer {admin_token}"}
    create_res = client.post("/api/v1/incidents", headers=headers, json={
        "title": "Supply Chain Disruption in Assembly Alpha",
        "description": "Component deliveries halted due to weather anomaly",
        "category": "Delayed delivery",
        "severity": "CRITICAL",
        "priority": "Critical",
        "deadline": "2026-11-01T12:00:00Z"
    })
    assert create_res.status_code == 201
    incident_id = create_res.json()["id"]
    assert create_res.json()["priority"] == "Critical"

    list_res = client.get("/api/v1/incidents", headers=headers)
    assert list_res.status_code == 200
    assert any(inc["id"] == incident_id for inc in list_res.json())

    get_res = client.get(f"/api/v1/incidents/{incident_id}", headers=headers)
    assert get_res.status_code == 200
    assert get_res.json()["title"] == "Supply Chain Disruption in Assembly Alpha"

    update_res = client.put(f"/api/v1/incidents/{incident_id}", headers=headers, json={
        "priority": "High",
        "status": "CONTAINED"
    })
    assert update_res.status_code == 200
    assert update_res.json()["priority"] == "High"
    assert update_res.json()["status"] == "CONTAINED"

def test_create_task_and_update_status(client, admin_token):
    headers = {"Authorization": f"Bearer {admin_token}"}
    inc_res = client.post("/api/v1/incidents", headers=headers, json={
        "title": "Incident For Task Testing",
        "description": "Testing tasks",
        "priority": "High"
    })
    incident_id = inc_res.json()["id"]

    task_res = client.post("/api/v1/tasks", headers=headers, json={
        "incident_id": incident_id,
        "title": "Install telemetry harness",
        "estimated_minutes": 120,
        "status": "NOT_STARTED"
    })
    assert task_res.status_code == 201
    task_id = task_res.json()["id"]

    up_res = client.put(f"/api/v1/tasks/{task_id}", headers=headers, json={
        "status": "COMPLETED"
    })
    assert up_res.status_code == 200
    assert up_res.json()["status"] == "COMPLETED"
