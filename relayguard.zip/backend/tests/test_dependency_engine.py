from app.services.dependency_engine import DependencyEngine

def test_engine_cycle_detection():
    has_cycle, path = DependencyEngine.detect_cycle(["A", "B"], [("A", "B"), ("B", "A")])
    assert has_cycle is True
    assert "A" in path and "B" in path

    has_cycle, path = DependencyEngine.detect_cycle(["A", "B", "C"], [("A", "B"), ("B", "C"), ("C", "A")])
    assert has_cycle is True

    has_cycle, path = DependencyEngine.detect_cycle(["A", "B", "C"], [("A", "B"), ("B", "C")])
    assert has_cycle is False

def test_engine_topological_sort():
    success, order = DependencyEngine.topological_sort(
        ["A", "B", "C", "D"],
        [("A", "B"), ("B", "C"), ("A", "D"), ("D", "C")]
    )
    assert success is True
    assert order.index("A") < order.index("B")
    assert order.index("B") < order.index("C")
    assert order.index("D") < order.index("C")

def test_engine_downstream_impact():
    edges = [("A", "B"), ("B", "C"), ("C", "D"), ("E", "F")]
    impacted = DependencyEngine.calculate_downstream_impact("A", edges)
    assert set(impacted) == {"B", "C", "D"}

def test_engine_critical_path():
    durations = {"A": 30, "B": 60, "C": 15, "D": 90}
    edges = [("A", "B"), ("B", "D"), ("A", "C"), ("C", "D")]
    path, duration = DependencyEngine.calculate_critical_path(["A", "B", "C", "D"], durations, edges)
    assert path == ["A", "B", "D"]
    assert duration == 180

def test_engine_blocked_tasks():
    statuses = {"A": "NOT_STARTED", "B": "NOT_STARTED", "C": "COMPLETED", "D": "NOT_STARTED"}
    edges = [("A", "B"), ("C", "D")]
    blocked = DependencyEngine.determine_blocked_tasks(["A", "B", "C", "D"], statuses, edges)
    assert "B" in blocked
    assert "D" not in blocked

def test_api_cycle_rejection(client, admin_token):
    headers = {"Authorization": f"Bearer {admin_token}"}
    inc_res = client.post("/api/v1/incidents", headers=headers, json={
        "title": "Cycle Test Incident",
        "description": "Testing cycle rejection"
    })
    incident_id = inc_res.json()["id"]

    t1 = client.post("/api/v1/tasks", headers=headers, json={"incident_id": incident_id, "title": "Task 1"}).json()["id"]
    t2 = client.post("/api/v1/tasks", headers=headers, json={"incident_id": incident_id, "title": "Task 2"}).json()["id"]

    dep1_res = client.post("/api/v1/dependencies", headers=headers, json={
        "incident_id": incident_id,
        "source_task_id": t1,
        "target_task_id": t2,
        "relation_type": "BLOCKS"
    })
    assert dep1_res.status_code == 201

    dep2_res = client.post("/api/v1/dependencies", headers=headers, json={
        "incident_id": incident_id,
        "source_task_id": t2,
        "target_task_id": t1,
        "relation_type": "BLOCKS"
    })
    assert dep2_res.status_code == 400
    assert "Circular dependency rejected" in dep2_res.json()["detail"]
