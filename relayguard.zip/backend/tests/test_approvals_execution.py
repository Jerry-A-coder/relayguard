import uuid

def test_approval_decision_rbac_and_execution_gating(client, admin_token, member_token):
    admin_headers = {"Authorization": f"Bearer {admin_token}"}
    member_headers = {"Authorization": f"Bearer {member_token}"}

    inc_res = client.post("/api/v1/incidents", headers=admin_headers, json={
        "title": "Approval Gating Verification Incident",
        "description": "Validating gating"
    })
    incident_id = inc_res.json()["id"]

    app_res = client.post("/api/v1/approvals", headers=admin_headers, json={
        "incident_id": incident_id,
        "title": "Emergency Vendor Expedite Authorization",
        "description": "Authorize tier-1 shipping fee",
        "action_type": "SUPPLIER_EXPEDITE",
        "target_recipient": "Express Couriers Inc."
    })
    assert app_res.status_code == 201
    approval_id = app_res.json()["id"]
    assert app_res.json()["status"] == "AWAITING_APPROVAL"

    # Gating Test 1: Try executing while AWAITING_APPROVAL (MUST FAIL with 400)
    exec_fail_res = client.post("/api/v1/actions/execute", headers=admin_headers, json={
        "approval_id": approval_id,
        "idempotency_key": str(uuid.uuid4())
    })
    assert exec_fail_res.status_code == 400
    assert "must be 'APPROVED'" in exec_fail_res.json()["detail"]

    # RBAC Test: Member tries to decide approval (MUST FAIL with 403 Forbidden)
    member_decide_res = client.post(f"/api/v1/approvals/{approval_id}/decide", headers=member_headers, json={
        "status": "APPROVED"
    })
    assert member_decide_res.status_code == 403

    # Admin decides approval (SUCCESS)
    admin_decide_res = client.post(f"/api/v1/approvals/{approval_id}/decide", headers=admin_headers, json={
        "status": "APPROVED"
    })
    assert admin_decide_res.status_code == 200
    assert admin_decide_res.json()["status"] == "APPROVED"

    # Execution Test: Admin executes approved action (SUCCESS)
    idemp_key = f"key-{uuid.uuid4()}"
    exec_success_res = client.post("/api/v1/actions/execute", headers=admin_headers, json={
        "approval_id": approval_id,
        "idempotency_key": idemp_key
    })
    assert exec_success_res.status_code == 200
    assert exec_success_res.json()["status"] == "SUCCEEDED"
    assert "dispatched" in exec_success_res.json()["execution_result"].lower()

    # Idempotency Test: Re-executing with the same key returns idempotent replay
    replay_res = client.post("/api/v1/actions/execute", headers=admin_headers, json={
        "approval_id": approval_id,
        "idempotency_key": idemp_key
    })
    assert replay_res.status_code == 200
    assert replay_res.json()["status"] == "SUCCEEDED"
