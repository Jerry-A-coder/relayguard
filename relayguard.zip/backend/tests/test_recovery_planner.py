def test_generate_and_select_recovery_plan(client, admin_token):
    headers = {"Authorization": f"Bearer {admin_token}"}
    inc_res = client.post("/api/v1/incidents", headers=headers, json={
        "title": "Incident For Recovery Plan Test",
        "description": "Testing plan generation",
        "severity": "CRITICAL",
        "priority": "Critical"
    })
    incident_id = inc_res.json()["id"]

    t1 = client.post("/api/v1/tasks", headers=headers, json={"incident_id": incident_id, "title": "Prerequisite Task", "estimated_minutes": 60}).json()["id"]
    t2 = client.post("/api/v1/tasks", headers=headers, json={"incident_id": incident_id, "title": "Intermediate Task", "estimated_minutes": 45}).json()["id"]
    t3 = client.post("/api/v1/tasks", headers=headers, json={"incident_id": incident_id, "title": "Final Milestone", "estimated_minutes": 30}).json()["id"]

    client.post("/api/v1/dependencies", headers=headers, json={"incident_id": incident_id, "source_task_id": t1, "target_task_id": t2})
    client.post("/api/v1/dependencies", headers=headers, json={"incident_id": incident_id, "source_task_id": t2, "target_task_id": t3})

    gen_res = client.post("/api/v1/recovery-plans/generate", headers=headers, json={"incident_id": incident_id})
    assert gen_res.status_code == 200
    plans = gen_res.json()
    assert len(plans) == 3
    strategies = [p["strategy"] for p in plans]
    assert "MIN_DISRUPTION" in strategies
    assert "FASTEST_FEASIBLE" in strategies
    assert "LOWEST_RISK" in strategies

    plan_a = next(p for p in plans if p["strategy"] == "MIN_DISRUPTION")
    sel_res = client.post("/api/v1/recovery-plans/select", headers=headers, json={"plan_id": plan_a["id"]})
    assert sel_res.status_code == 200
    assert sel_res.json()["is_selected"] is True

    app_res = client.get(f"/api/v1/approvals?incident_id={incident_id}", headers=headers)
    assert app_res.status_code == 200
    approvals = app_res.json()
    assert len(approvals) >= 1
    assert any(a["status"] == "AWAITING_APPROVAL" for a in approvals)
