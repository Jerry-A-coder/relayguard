def test_dynamic_replanning_unblocks_dependent_task(client, admin_token):
    headers = {"Authorization": f"Bearer {admin_token}"}
    inc_res = client.post("/api/v1/incidents", headers=headers, json={
        "title": "Replanning Dynamic Test Incident",
        "description": "Testing dynamic unblocking"
    })
    incident_id = inc_res.json()["id"]

    t1_res = client.post("/api/v1/tasks", headers=headers, json={
        "incident_id": incident_id,
        "title": "Prerequisite Task 1",
        "status": "NOT_STARTED"
    })
    t1_id = t1_res.json()["id"]

    t2_res = client.post("/api/v1/tasks", headers=headers, json={
        "incident_id": incident_id,
        "title": "Dependent Task 2",
        "status": "NOT_STARTED"
    })
    t2_id = t2_res.json()["id"]

    client.post("/api/v1/dependencies", headers=headers, json={
        "incident_id": incident_id,
        "source_task_id": t1_id,
        "target_task_id": t2_id,
        "relation_type": "BLOCKS"
    })

    check_t2 = client.get(f"/api/v1/tasks/{t2_id}", headers=headers).json()
    assert check_t2["status"] == "BLOCKED"

    client.put(f"/api/v1/tasks/{t1_id}", headers=headers, json={
        "status": "COMPLETED"
    })

    check_t2_after = client.get(f"/api/v1/tasks/{t2_id}", headers=headers).json()
    assert check_t2_after["status"] == "NOT_STARTED"

def test_audit_log_captures_events(client, admin_token):
    headers = {"Authorization": f"Bearer {admin_token}"}
    client.post("/api/v1/incidents", headers=headers, json={
        "title": "Incident For Audit Verification",
        "description": "Validating audit trail logging"
    })

    audit_res = client.get("/api/v1/audit", headers=headers)
    assert audit_res.status_code == 200
    events = audit_res.json()
    assert len(events) > 0
    event_types = [e["event_type"] for e in events]
    assert "INCIDENT_CREATED" in event_types
