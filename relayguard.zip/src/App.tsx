import React, { useState } from 'react';
import { AppProvider } from './context/AppContext';
import { Navbar } from './components/layout/Navbar';
import { Sidebar, NavigationTab } from './components/layout/Sidebar';
import { OverviewPage } from './pages/OverviewPage';
import { IntakePage } from './pages/IntakePage';
import { WorkspacePage } from './pages/WorkspacePage';
import { DependencyMapPage } from './pages/DependencyMapPage';
import { PlanComparisonPage } from './pages/PlanComparisonPage';
import { ApprovalCentrePage } from './pages/ApprovalCentrePage';
import { ActivityTimelinePage } from './pages/ActivityTimelinePage';
import { AICommandStudioPage } from './pages/AICommandStudioPage';
import { IntegrationsPage } from './pages/IntegrationsPage';
import { SettingsPage } from './pages/SettingsPage';
import { ReportDisruptionModal } from './components/dialogs/ReportDisruptionModal';

export function RelayGuardApp() {
  const [activeTab, setActiveTab] = useState<NavigationTab>('overview');
  const [isReportModalOpen, setIsReportModalOpen] = useState(false);

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans">
      {/* Top Persistent Navigation */}
      <Navbar onOpenReportModal={() => setIsReportModalOpen(true)} />

      {/* Main Operational Container */}
      <div className="flex-1 flex overflow-hidden">
        {/* Left SaaS Navigation */}
        <Sidebar activeTab={activeTab} onSelectTab={setActiveTab} />

        {/* Content Viewport */}
        <main className="flex-1 overflow-y-auto bg-slate-950">
          {activeTab === 'overview' && (
            <OverviewPage
              onNavigate={setActiveTab}
              onOpenReportModal={() => setIsReportModalOpen(true)}
            />
          )}
          {activeTab === 'intake' && <IntakePage onNavigate={setActiveTab} />}
          {activeTab === 'workspace' && <WorkspacePage onNavigate={setActiveTab} />}
          {activeTab === 'dependency-map' && <DependencyMapPage />}
          {activeTab === 'recovery-plans' && <PlanComparisonPage onNavigate={setActiveTab} />}
          {activeTab === 'approvals' && <ApprovalCentrePage />}
          {activeTab === 'activity' && <ActivityTimelinePage />}
          {activeTab === 'ai-command' && <AICommandStudioPage />}
          {activeTab === 'integrations' && <IntegrationsPage />}
          {activeTab === 'settings' && <SettingsPage />}
        </main>
      </div>

      {/* Quick Disruption Intake Modal */}
      <ReportDisruptionModal
        isOpen={isReportModalOpen}
        onClose={() => setIsReportModalOpen(false)}
        onSuccess={() => setActiveTab('workspace')}
      />
    </div>
  );
}

export default function App() {
  return (
    <AppProvider>
      <RelayGuardApp />
    </AppProvider>
  );
}
