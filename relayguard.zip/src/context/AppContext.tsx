import React, { createContext, useContext, useState, useEffect, useMemo, ReactNode } from 'react';
import {
  UserProfile,
  Workspace,
  Incident,
  Task,
  Dependency,
  RecoveryPlan,
  Approval,
  ActivityLog,
  WorkspaceRole,
  RelationType,
} from '../types';
import {
  DEFAULT_WORKSPACE,
  INITIAL_INCIDENTS,
  INITIAL_TASKS,
  INITIAL_DEPENDENCIES,
  INITIAL_RECOVERY_PLANS,
  INITIAL_APPROVALS,
  INITIAL_ACTIVITIES,
} from '../lib/mockData';
import { db, auth, signInWithGoogle, signOutUser, testFirestoreConnection } from '../lib/firebase';
import { onAuthStateChanged, User as FirebaseUser } from 'firebase/auth';
import { doc, setDoc } from 'firebase/firestore';

interface AppContextType {
  currentUser: UserProfile;
  setCurrentUserRole: (role: WorkspaceRole) => void;
  activeWorkspace: Workspace;
  incidents: Incident[];
  activeIncident: Incident | undefined;
  activeIncidentId: string;
  setActiveIncidentId: (id: string) => void;
  tasks: Task[];
  dependencies: Dependency[];
  recoveryPlans: RecoveryPlan[];
  selectedPlan: RecoveryPlan | undefined;
  approvals: Approval[];
  activities: ActivityLog[];
  createIncident: (incident: Omit<Incident, 'id' | 'workspaceId' | 'createdAt' | 'updatedAt'>) => string;
  updateIncident: (id: string, updates: Partial<Incident>) => void;
  createTask: (task: Omit<Task, 'id' | 'workspaceId' | 'createdAt' | 'updatedAt'>) => string;
  updateTask: (id: string, updates: Partial<Task>) => void;
  deleteTask: (id: string) => void;
  createDependency: (sourceTaskId: string, targetTaskId: string, relationType: RelationType) => { success: boolean; error?: string };
  deleteDependency: (id: string) => void;
  selectRecoveryPlan: (planId: string) => void;
  addRecoveryPlan: (plan: RecoveryPlan) => void;
  approveAction: (approvalId: string) => Promise<{ success: boolean; summary?: string; error?: string }>;
  rejectAction: (approvalId: string, reason?: string) => void;
  requestChangesAction: (approvalId: string, changesNote: string) => void;
  logActivity: (eventType: ActivityLog['eventType'], summary: string, details?: string) => void;
  resetToSampleData: () => void;
  isFirebaseConnected: boolean;
  loginWithGooglePopup: () => Promise<void>;
  logoutUser: () => Promise<void>;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export const AppProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [currentUser, setCurrentUser] = useState<UserProfile>({
    userId: 'usr-jerry-lead',
    displayName: 'Jerry Godwin (Lead Architect)',
    email: 'jerrygodwin04@gmail.com',
    role: 'OWNER',
  });

  const [activeWorkspace] = useState<Workspace>(DEFAULT_WORKSPACE);
  const [activeIncidentId, setActiveIncidentId] = useState<string>('inc-customs-hold-01');

  // Core collections state with initial fallback
  const [incidents, setIncidents] = useState<Incident[]>(() => {
    const saved = localStorage.getItem('relayguard_incidents');
    return saved ? JSON.parse(saved) : INITIAL_INCIDENTS;
  });

  const [tasks, setTasks] = useState<Task[]>(() => {
    const saved = localStorage.getItem('relayguard_tasks');
    return saved ? JSON.parse(saved) : INITIAL_TASKS;
  });

  const [dependencies, setDependencies] = useState<Dependency[]>(() => {
    const saved = localStorage.getItem('relayguard_dependencies');
    return saved ? JSON.parse(saved) : INITIAL_DEPENDENCIES;
  });

  const [recoveryPlans, setRecoveryPlans] = useState<RecoveryPlan[]>(() => {
    const saved = localStorage.getItem('relayguard_plans');
    return saved ? JSON.parse(saved) : INITIAL_RECOVERY_PLANS;
  });

  const [approvals, setApprovals] = useState<Approval[]>(() => {
    const saved = localStorage.getItem('relayguard_approvals');
    return saved ? JSON.parse(saved) : INITIAL_APPROVALS;
  });

  const [activities, setActivities] = useState<ActivityLog[]>(() => {
    const saved = localStorage.getItem('relayguard_activities');
    return saved ? JSON.parse(saved) : INITIAL_ACTIVITIES;
  });

  const [isFirebaseConnected, setIsFirebaseConnected] = useState<boolean>(false);

  // Sync to localStorage
  useEffect(() => {
    localStorage.setItem('relayguard_incidents', JSON.stringify(incidents));
  }, [incidents]);

  useEffect(() => {
    localStorage.setItem('relayguard_tasks', JSON.stringify(tasks));
  }, [tasks]);

  useEffect(() => {
    localStorage.setItem('relayguard_dependencies', JSON.stringify(dependencies));
  }, [dependencies]);

  useEffect(() => {
    localStorage.setItem('relayguard_plans', JSON.stringify(recoveryPlans));
  }, [recoveryPlans]);

  useEffect(() => {
    localStorage.setItem('relayguard_approvals', JSON.stringify(approvals));
  }, [approvals]);

  useEffect(() => {
    localStorage.setItem('relayguard_activities', JSON.stringify(activities));
  }, [activities]);

  // Backend API synchronization on mount
  useEffect(() => {
    async function syncBackendData() {
      try {
        const res = await fetch('/api/v1/incidents');
        if (res.ok) {
          const apiIncidents = await res.json();
          if (Array.isArray(apiIncidents) && apiIncidents.length > 0) {
            setIncidents((prev) => {
              const existingIds = new Set(prev.map(i => i.id));
              const newItems = apiIncidents.filter((ai: any) => !existingIds.has(ai.id)).map((ai: any) => ({
                id: ai.id,
                workspaceId: ai.organization_id || DEFAULT_WORKSPACE.id,
                title: ai.title,
                description: ai.description,
                category: ai.category,
                severity: ai.severity,
                priority: ai.priority,
                status: ai.status,
                verificationStatus: ai.verification_status,
                deadline: ai.deadline,
                knownConstraints: ai.known_constraints,
                informationSource: ai.information_source,
                createdAt: ai.created_at,
                updatedAt: ai.updated_at,
                creatorId: ai.creator_id || 'usr-jerry-lead',
              }));
              return [...newItems, ...prev];
            });
          }
        }
      } catch (err) {
        console.debug('Backend sync note:', err);
      }
    }
    syncBackendData();
  }, []);

  // Firebase connection and auth listener
  useEffect(() => {
    testFirestoreConnection().then((connected) => {
      setIsFirebaseConnected(connected);
    });

    const unsubscribe = onAuthStateChanged(auth, (fbUser: FirebaseUser | null) => {
      if (fbUser) {
        setCurrentUser((prev) => ({
          ...prev,
          userId: fbUser.uid,
          displayName: fbUser.displayName || fbUser.email?.split('@')[0] || 'Authenticated Operator',
          email: fbUser.email || 'operator@relayguard.net',
          photoURL: fbUser.photoURL || undefined,
        }));
      }
    });

    return () => unsubscribe();
  }, []);

  const setCurrentUserRole = (role: WorkspaceRole) => {
    setCurrentUser((prev) => ({ ...prev, role }));
    logActivity('INCIDENT_UPDATED', `Role changed to ${role} for session user`);
  };

  const activeIncident = useMemo(() => {
    return incidents.find((inc) => inc.id === activeIncidentId) || incidents[0];
  }, [incidents, activeIncidentId]);

  const selectedPlan = useMemo(() => {
    return recoveryPlans.find((p) => p.incidentId === activeIncidentId && p.isSelected) || recoveryPlans.find((p) => p.incidentId === activeIncidentId);
  }, [recoveryPlans, activeIncidentId]);

  const logActivity = (eventType: ActivityLog['eventType'], summary: string, details?: string) => {
    const newLog: ActivityLog = {
      id: `act-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
      workspaceId: activeWorkspace.id,
      incidentId: activeIncidentId,
      actorName: currentUser.displayName,
      actorId: currentUser.userId,
      eventType,
      summary,
      details,
      createdAt: new Date().toISOString(),
    };
    setActivities((prev) => [newLog, ...prev]);
  };

  const createIncident = (incidentData: Omit<Incident, 'id' | 'workspaceId' | 'createdAt' | 'updatedAt'>): string => {
    const id = `inc-${Date.now().toString(36)}`;
    const now = new Date().toISOString();
    const newIncident: Incident = {
      ...incidentData,
      id,
      workspaceId: activeWorkspace.id,
      createdAt: now,
      updatedAt: now,
    };
    setIncidents((prev) => [newIncident, ...prev]);
    setActiveIncidentId(id);
    logActivity(
      'INCIDENT_CREATED',
      `Disruption reported: "${newIncident.title}" [Severity: ${newIncident.severity}, Priority: ${newIncident.priority || 'Unassigned'}]`,
      newIncident.description
    );

    // Persist to Firestore database
    try {
      setDoc(doc(db, 'incidents', id), newIncident).catch((err) => {
        console.warn('Firestore incident sync notice:', err);
      });
    } catch (e) {
      console.warn('Firestore write notice:', e);
    }

    return id;
  };

  const updateIncident = (id: string, updates: Partial<Incident>) => {
    setIncidents((prev) =>
      prev.map((inc) => (inc.id === id ? { ...inc, ...updates, updatedAt: new Date().toISOString() } : inc))
    );
    logActivity('INCIDENT_UPDATED', `Incident #${id} details updated`);
  };

  const createTask = (taskData: Omit<Task, 'id' | 'workspaceId' | 'createdAt' | 'updatedAt'>): string => {
    const id = `tsk-${Date.now().toString(36)}`;
    const now = new Date().toISOString();
    const newTask: Task = {
      ...taskData,
      id,
      workspaceId: activeWorkspace.id,
      createdAt: now,
      updatedAt: now,
    };
    setTasks((prev) => [...prev, newTask]);
    logActivity('DEPENDENCY_ADDED', `Task added: "${newTask.title}"`);
    return id;
  };

  const updateTask = (id: string, updates: Partial<Task>) => {
    setTasks((prev) =>
      prev.map((t) => (t.id === id ? { ...t, ...updates, updatedAt: new Date().toISOString() } : t))
    );
  };

  const deleteTask = (id: string) => {
    setTasks((prev) => prev.filter((t) => t.id !== id));
    setDependencies((prev) => prev.filter((d) => d.sourceTaskId !== id && d.targetTaskId !== id));
    logActivity('DEPENDENCY_ADDED', `Task #${id} and associated dependencies removed`);
  };

  const createDependency = (
    sourceTaskId: string,
    targetTaskId: string,
    relationType: RelationType
  ): { success: boolean; error?: string } => {
    if (sourceTaskId === targetTaskId) {
      return { success: false, error: 'A task cannot depend on itself.' };
    }

    // Check if dependency already exists
    const exists = dependencies.some(
      (d) => d.sourceTaskId === sourceTaskId && d.targetTaskId === targetTaskId
    );
    if (exists) {
      return { success: false, error: 'This dependency relationship already exists.' };
    }

    // Cycle detection check
    const tempEdges = [...dependencies, { sourceTaskId, targetTaskId }];
    const adj = new Map<string, string[]>();
    tempEdges.forEach((e) => {
      if (!adj.has(e.sourceTaskId)) adj.set(e.sourceTaskId, []);
      adj.get(e.sourceTaskId)!.push(e.targetTaskId);
    });

    const visited = new Map<string, number>();
    let cycleFound = false;

    function dfs(curr: string) {
      visited.set(curr, 1);
      const neighbors = adj.get(curr) || [];
      for (const n of neighbors) {
        if (visited.get(n) === 1) {
          cycleFound = true;
          return;
        }
        if (!visited.has(n)) {
          dfs(n);
        }
      }
      visited.set(curr, 2);
    }

    dfs(sourceTaskId);
    if (cycleFound) {
      return {
        success: false,
        error: 'Cyclic dependency rejected! Adding this relationship would create an infinite circular deadlock.',
      };
    }

    const newDep: Dependency = {
      id: `dep-${Date.now().toString(36)}`,
      workspaceId: activeWorkspace.id,
      incidentId: activeIncidentId,
      sourceTaskId,
      targetTaskId,
      relationType,
      isConfirmed: true,
      createdAt: new Date().toISOString(),
    };

    setDependencies((prev) => [...prev, newDep]);
    logActivity('DEPENDENCY_ADDED', `Dependency established: ${sourceTaskId} -> ${targetTaskId} (${relationType})`);
    return { success: true };
  };

  const deleteDependency = (id: string) => {
    setDependencies((prev) => prev.filter((d) => d.id !== id));
    logActivity('DEPENDENCY_ADDED', `Dependency edge #${id} removed`);
  };

  const selectRecoveryPlan = (planId: string) => {
    setRecoveryPlans((prev) =>
      prev.map((p) => {
        if (p.incidentId === activeIncidentId) {
          return { ...p, isSelected: p.id === planId };
        }
        return p;
      })
    );
    const chosen = recoveryPlans.find((p) => p.id === planId);
    logActivity('PLAN_SELECTED', `Active recovery plan switched to "${chosen?.title || planId}"`);
  };

  const addRecoveryPlan = (plan: RecoveryPlan) => {
    setRecoveryPlans((prev) => [plan, ...prev]);
    logActivity('PLAN_GENERATED', `New recovery plan formulated: "${plan.title}" [Confidence: ${plan.score}%]`);
  };

  const approveAction = async (approvalId: string): Promise<{ success: boolean; summary?: string; error?: string }> => {
    if (currentUser.role === 'VIEWER') {
      return { success: false, error: 'Viewer role cannot approve consequential actions.' };
    }

    const target = approvals.find((a) => a.id === approvalId);
    if (!target) {
      return { success: false, error: 'Approval request not found.' };
    }

    if (target.status === 'SUCCEEDED' || target.status === 'APPROVED') {
      return { success: false, error: 'Action has already been approved or executed.' };
    }

    // Set executing state
    setApprovals((prev) =>
      prev.map((a) => (a.id === approvalId ? { ...a, status: 'EXECUTING' } : a))
    );

    try {
      const response = await fetch('/api/actions/execute', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          approvalId,
          actionType: target.actionType,
          targetRecipient: target.targetRecipient,
          payload: target.payload,
          idempotencyKey: target.idempotencyKey || `IDEMP-${approvalId}`,
        }),
      });

      const data = await response.json();

      if (!response.ok || !data.success) {
        throw new Error(data.error || 'Execution failed on target adapter');
      }

      setApprovals((prev) =>
        prev.map((a) =>
          a.id === approvalId
            ? {
                ...a,
                status: 'SUCCEEDED',
                decidedBy: currentUser.displayName,
                decidedAt: new Date().toISOString(),
                executionResult: data.summary,
                isSimulated: data.isSimulated,
              }
            : a
        )
      );

      logActivity('ACTION_EXECUTED', `Action authorized & executed: "${target.title}"`, data.summary);
      return { success: true, summary: data.summary };
    } catch (err: any) {
      setApprovals((prev) =>
        prev.map((a) =>
          a.id === approvalId
            ? {
                ...a,
                status: 'FAILED',
                decidedBy: currentUser.displayName,
                decidedAt: new Date().toISOString(),
                executionResult: `Failed: ${err.message}`,
              }
            : a
        )
      );
      logActivity('ACTION_FAILED', `Execution failed for "${target.title}": ${err.message}`);
      return { success: false, error: err.message };
    }
  };

  const rejectAction = (approvalId: string, reason?: string) => {
    setApprovals((prev) =>
      prev.map((a) =>
        a.id === approvalId
          ? {
              ...a,
              status: 'REJECTED',
              decidedBy: currentUser.displayName,
              decidedAt: new Date().toISOString(),
              executionResult: `Rejected by ${currentUser.displayName}: ${reason || 'Decision deferred by coordinator'}`,
            }
          : a
      )
    );
    logActivity('APPROVAL_REJECTED', `Action proposal #${approvalId} rejected: ${reason || 'Disapproved'}`);
  };

  const requestChangesAction = (approvalId: string, changesNote: string) => {
    setApprovals((prev) =>
      prev.map((a) =>
        a.id === approvalId
          ? {
              ...a,
              status: 'CHANGES_REQUESTED',
              decidedBy: currentUser.displayName,
              decidedAt: new Date().toISOString(),
              executionResult: `Modifications requested: ${changesNote}`,
            }
          : a
      )
    );
    logActivity('APPROVAL_REQUESTED', `Modifications requested for #${approvalId}: ${changesNote}`);
  };

  const resetToSampleData = () => {
    setIncidents(INITIAL_INCIDENTS);
    setTasks(INITIAL_TASKS);
    setDependencies(INITIAL_DEPENDENCIES);
    setRecoveryPlans(INITIAL_RECOVERY_PLANS);
    setApprovals(INITIAL_APPROVALS);
    setActivities(INITIAL_ACTIVITIES);
    setActiveIncidentId('inc-customs-hold-01');
    localStorage.clear();
    logActivity('INCIDENT_CREATED', 'System restored to standard operational crisis demonstration state');
  };

  const loginWithGooglePopup = async () => {
    try {
      await signInWithGoogle();
    } catch (e: any) {
      console.warn('Firebase popup login closed or failed, retaining current user session:', e);
    }
  };

  const logoutUser = async () => {
    await signOutUser();
    setCurrentUser({
      userId: 'usr-guest',
      displayName: 'Guest Operator',
      email: 'guest@relayguard.net',
      role: 'VIEWER',
    });
  };

  return (
    <AppContext.Provider
      value={{
        currentUser,
        setCurrentUserRole,
        activeWorkspace,
        incidents,
        activeIncident,
        activeIncidentId,
        setActiveIncidentId,
        tasks,
        dependencies,
        recoveryPlans,
        selectedPlan,
        approvals,
        activities,
        createIncident,
        updateIncident,
        createTask,
        updateTask,
        deleteTask,
        createDependency,
        deleteDependency,
        selectRecoveryPlan,
        addRecoveryPlan,
        approveAction,
        rejectAction,
        requestChangesAction,
        logActivity,
        resetToSampleData,
        isFirebaseConnected,
        loginWithGooglePopup,
        logoutUser,
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
};
