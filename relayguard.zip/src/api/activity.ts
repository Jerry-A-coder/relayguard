import { apiClient } from './client';
import { ActivityLog } from '../types';

export const activityApi = {
  list: async (incidentId?: string): Promise<ActivityLog[]> => {
    const qs = incidentId ? `?incident_id=${encodeURIComponent(incidentId)}` : '';
    return apiClient.get<ActivityLog[]>(`/api/v1/audit${qs}`);
  },
};

export const authApi = {
  login: async (email: string, password: string) => {
    const res = await apiClient.post('/api/v1/auth/login', { email, password });
    if (res?.access_token) {
      apiClient.setToken(res.access_token);
    }
    return res;
  },

  register: async (payload: { email: string; password: string; full_name: string; organization_name?: string; role?: string }) => {
    const res = await apiClient.post('/api/v1/auth/register', payload);
    if (res?.access_token) {
      apiClient.setToken(res.access_token);
    }
    return res;
  },

  getMe: async () => {
    return apiClient.get('/api/v1/auth/me');
  },

  logout: () => {
    apiClient.setToken(null);
  },
};
