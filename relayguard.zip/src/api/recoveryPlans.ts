import { apiClient } from './client';
import { RecoveryPlan } from '../types';

export const recoveryPlansApi = {
  list: async (incidentId: string): Promise<RecoveryPlan[]> => {
    return apiClient.get<RecoveryPlan[]>(`/api/v1/recovery-plans?incident_id=${encodeURIComponent(incidentId)}`);
  },

  generate: async (incidentId: string): Promise<RecoveryPlan[]> => {
    return apiClient.post<RecoveryPlan[]>('/api/v1/recovery-plans/generate', { incident_id: incidentId });
  },

  select: async (planId: string): Promise<RecoveryPlan> => {
    return apiClient.post<RecoveryPlan>('/api/v1/recovery-plans/select', { plan_id: planId });
  },
};
