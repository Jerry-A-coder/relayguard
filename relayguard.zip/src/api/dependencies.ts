import { apiClient } from './client';
import { Dependency } from '../types';

export interface CreateDependencyPayload {
  incident_id: string;
  source_task_id: string;
  target_task_id: string;
  relation_type?: string;
  is_confirmed?: boolean;
}

export interface ImpactAnalysisPayload {
  incident_id: string;
  disrupted_task_id?: string;
}

export interface ImpactAnalysisResult {
  has_cycle: boolean;
  cycle_nodes: string[];
  topological_order: string[];
  critical_path: string[];
  critical_path_duration: number;
  affected_task_ids: string[];
  blocked_task_ids: string[];
  total_tasks: number;
}

export const dependenciesApi = {
  list: async (incidentId?: string): Promise<Dependency[]> => {
    const query = incidentId ? `?incident_id=${encodeURIComponent(incidentId)}` : '';
    return apiClient.get<Dependency[]>(`/api/v1/dependencies${query}`);
  },

  create: async (payload: CreateDependencyPayload): Promise<Dependency> => {
    return apiClient.post<Dependency>('/api/v1/dependencies', payload);
  },

  delete: async (id: string): Promise<void> => {
    return apiClient.delete(`/api/v1/dependencies/${id}`);
  },

  analyzeImpact: async (payload: ImpactAnalysisPayload): Promise<ImpactAnalysisResult> => {
    return apiClient.post<ImpactAnalysisResult>('/api/v1/dependencies/impact-analysis', payload);
  },
};
