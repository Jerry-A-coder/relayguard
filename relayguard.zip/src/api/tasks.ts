import { apiClient } from './client';
import { Task } from '../types';

export interface CreateTaskPayload {
  incident_id: string;
  title: string;
  description?: string;
  status?: string;
  assignee_id?: string;
  deadline?: string;
  estimated_minutes?: number;
  risk_level?: string;
}

export const tasksApi = {
  list: async (incidentId?: string): Promise<Task[]> => {
    const query = incidentId ? `?incident_id=${encodeURIComponent(incidentId)}` : '';
    return apiClient.get<Task[]>(`/api/v1/tasks${query}`);
  },

  get: async (id: string): Promise<Task> => {
    return apiClient.get<Task>(`/api/v1/tasks/${id}`);
  },

  create: async (payload: CreateTaskPayload): Promise<Task> => {
    return apiClient.post<Task>('/api/v1/tasks', payload);
  },

  update: async (id: string, updates: Partial<Task>): Promise<Task> => {
    return apiClient.put<Task>(`/api/v1/tasks/${id}`, updates);
  },

  delete: async (id: string): Promise<void> => {
    return apiClient.delete(`/api/v1/tasks/${id}`);
  },
};
