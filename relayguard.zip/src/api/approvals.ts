import { apiClient } from './client';
import { Approval } from '../types';

export const approvalsApi = {
  list: async (incidentId?: string, status?: string): Promise<Approval[]> => {
    const params = new URLSearchParams();
    if (incidentId) params.append('incident_id', incidentId);
    if (status) params.append('status', status);
    const qs = params.toString() ? `?${params.toString()}` : '';
    return apiClient.get<Approval[]>(`/api/v1/approvals${qs}`);
  },

  decide: async (approvalId: string, decision: 'APPROVED' | 'REJECTED' | 'CHANGES_REQUESTED', rejectionReason?: string): Promise<Approval> => {
    return apiClient.post<Approval>(`/api/v1/approvals/${approvalId}/decide`, {
      status: decision,
      rejection_reason: rejectionReason,
    });
  },
};

export const actionsApi = {
  execute: async (approvalId: string, idempotencyKey: string): Promise<any> => {
    return apiClient.post('/api/v1/actions/execute', {
      approval_id: approvalId,
      idempotency_key: idempotencyKey,
    });
  },
};
