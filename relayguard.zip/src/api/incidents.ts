import { apiClient } from './client';
import { Incident } from '../types';

export interface CreateIncidentPayload {
  title: string;
  description: string;
  category?: string;
  severity?: string;
  priority?: string;
  status?: string;
  verification_status?: string;
  deadline?: string;
  known_constraints?: string;
  information_source?: string;
}

export const incidentsApi = {
  list: async (status?: string): Promise<Incident[]> => {
    const query = status ? `?status=${encodeURIComponent(status)}` : '';
    return apiClient.get<Incident[]>(`/api/v1/incidents${query}`);
  },

  get: async (id: string): Promise<Incident> => {
    return apiClient.get<Incident>(`/api/v1/incidents/${id}`);
  },

  create: async (payload: CreateIncidentPayload): Promise<Incident> => {
    return apiClient.post<Incident>('/api/v1/incidents', payload);
  },

  update: async (id: string, updates: Partial<Incident>): Promise<Incident> => {
    return apiClient.put<Incident>(`/api/v1/incidents/${id}`, updates);
  },

  delete: async (id: string): Promise<void> => {
    return apiClient.delete(`/api/v1/incidents/${id}`);
  },
};
