import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { Settings, Users, Shield, RotateCcw, Download, Check, AlertTriangle } from 'lucide-react';
import { WorkspaceRole } from '../types';

export const SettingsPage: React.FC = () => {
  const {
    activeWorkspace,
    currentUser,
    setCurrentUserRole,
    resetToSampleData,
    incidents,
    tasks,
    dependencies,
    recoveryPlans,
    approvals,
  } = useApp();

  const [confirmReset, setConfirmReset] = useState(false);
  const [resetSuccess, setResetSuccess] = useState(false);

  const teamMembers = [
    { id: 'usr-jerry-lead', name: 'Jerry Godwin (Lead Architect)', email: 'jerrygodwin04@gmail.com', role: 'OWNER' },
    { id: 'usr-sarah-coord', name: 'Sarah Chen (Academic Coordinator)', email: 'sarah.chen@univ.edu', role: 'ADMIN' },
    { id: 'usr-david-eng', name: 'David K. (Systems Reliability)', email: 'david.k@relayguard.net', role: 'MEMBER' },
    { id: 'usr-audit-ext', name: 'External Compliance Auditor', email: 'auditor@compliance-eu.org', role: 'VIEWER' },
  ];

  const handleReset = () => {
    resetToSampleData();
    setConfirmReset(false);
    setResetSuccess(true);
    setTimeout(() => setResetSuccess(false), 3000);
  };

  const handleExportAll = () => {
    const fullState = {
      workspace: activeWorkspace,
      incidents,
      tasks,
      dependencies,
      recoveryPlans,
      approvals,
      exportedAt: new Date().toISOString(),
    };
    const dataStr = 'data:text/json;charset=utf-8,' + encodeURIComponent(JSON.stringify(fullState, null, 2));
    const downloadAnchor = document.createElement('a');
    downloadAnchor.setAttribute('href', dataStr);
    downloadAnchor.setAttribute('download', `RelayGuard_Full_Workspace_${Date.now()}.json`);
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();
  };

  return (
    <div className="p-6 max-w-4xl mx-auto space-y-6">
      <div className="border-b border-slate-800 pb-4">
        <h1 className="text-xl font-bold text-slate-100 flex items-center gap-2">
          <Settings className="w-5 h-5 text-indigo-400" />
          <span>Workspace Preferences & Access Control (RBAC)</span>
        </h1>
        <p className="text-xs text-slate-400 mt-1">
          Configure multi-user permissions, audit boundaries, and sample resilience crisis scenarios.
        </p>
      </div>

      {/* Workspace Identity */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-sm space-y-3">
        <h2 className="text-xs font-semibold uppercase tracking-wider text-indigo-400">Workspace Identity</h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
          <div>
            <label className="block text-slate-500 font-mono text-[11px] mb-1">Workspace Name</label>
            <input
              type="text"
              readOnly
              value={activeWorkspace.name}
              className="w-full bg-slate-950 border border-slate-800 rounded px-3 py-1.5 text-slate-200"
            />
          </div>
          <div>
            <label className="block text-slate-500 font-mono text-[11px] mb-1">Workspace ID</label>
            <input
              type="text"
              readOnly
              value={activeWorkspace.id}
              className="w-full bg-slate-950 border border-slate-800 rounded px-3 py-1.5 text-slate-400 font-mono"
            />
          </div>
        </div>
      </div>

      {/* Multi-User Members & Roles */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-sm space-y-3">
        <div className="flex items-center justify-between">
          <h2 className="text-xs font-semibold uppercase tracking-wider text-indigo-400 flex items-center gap-2">
            <Users className="w-4 h-4" />
            <span>Workspace Membership & Role-Based Permissions (RBAC)</span>
          </h2>
          <span className="text-[11px] font-mono text-slate-400">4 Members</span>
        </div>

        <div className="border border-slate-800 rounded-lg overflow-hidden">
          <table className="w-full text-left text-xs text-slate-300">
            <thead className="bg-slate-950 text-slate-400 font-mono text-[11px] border-b border-slate-800">
              <tr>
                <th className="py-2.5 px-3">Member</th>
                <th className="py-2.5 px-3">Email</th>
                <th className="py-2.5 px-3">Assigned Role</th>
                <th className="py-2.5 px-3 text-right">Switch Active Role</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/80">
              {teamMembers.map((m) => (
                <tr key={m.id} className="hover:bg-slate-800/40">
                  <td className="py-2.5 px-3 font-medium text-slate-100">{m.name}</td>
                  <td className="py-2.5 px-3 font-mono text-slate-400 text-[11px]">{m.email}</td>
                  <td className="py-2.5 px-3">
                    <span
                      className={`px-2 py-0.5 rounded text-[10px] font-mono font-bold ${
                        m.role === 'OWNER'
                          ? 'bg-purple-950 text-purple-300 border border-purple-800'
                          : m.role === 'ADMIN'
                          ? 'bg-indigo-950 text-indigo-300 border border-indigo-800'
                          : m.role === 'MEMBER'
                          ? 'bg-cyan-950 text-cyan-300 border border-cyan-800'
                          : 'bg-slate-800 text-slate-400 border border-slate-700'
                      }`}
                    >
                      {m.role}
                    </span>
                  </td>
                  <td className="py-2.5 px-3 text-right">
                    <button
                      onClick={() => setCurrentUserRole(m.role as WorkspaceRole)}
                      className={`px-2 py-1 rounded text-[11px] font-mono transition-colors cursor-pointer ${
                        currentUser.role === m.role
                          ? 'bg-indigo-600 text-white font-semibold'
                          : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
                      }`}
                    >
                      {currentUser.role === m.role ? 'Active Role' : 'Adopt Role'}
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Data Export & Reset */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-sm space-y-4">
        <h2 className="text-xs font-semibold uppercase tracking-wider text-indigo-400">
          Data Export & Resilience Test Seed
        </h2>

        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 p-3.5 rounded-lg bg-slate-950 border border-slate-800 text-xs">
          <div>
            <h3 className="font-semibold text-slate-200">Export Complete Workspace JSON</h3>
            <p className="text-slate-400 text-[11px] mt-0.5">
              Download all incidents, tasks, dependencies, and audit events in standard JSON format.
            </p>
          </div>
          <button
            onClick={handleExportAll}
            className="px-3.5 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded text-xs font-medium border border-slate-700 flex items-center gap-1.5 transition-colors cursor-pointer shrink-0"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Export Snapshot</span>
          </button>
        </div>

        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 p-3.5 rounded-lg bg-rose-950/20 border border-rose-900/40 text-xs">
          <div>
            <h3 className="font-semibold text-rose-300 flex items-center gap-1.5">
              <RotateCcw className="w-3.5 h-3.5" />
              <span>Restore Standard Demonstration Data</span>
            </h3>
            <p className="text-slate-400 text-[11px] mt-0.5">
              Resets all current modifications and restores the realistic Supply Chain Customs Hold scenario with verified dependencies.
            </p>
          </div>

          {!confirmReset ? (
            <button
              onClick={() => setConfirmReset(true)}
              className="px-3.5 py-2 bg-slate-800 hover:bg-rose-900 text-slate-300 hover:text-rose-200 rounded text-xs font-medium border border-slate-700 transition-colors cursor-pointer shrink-0"
            >
              Reset Data
            </button>
          ) : (
            <div className="flex items-center gap-2">
              <button
                onClick={() => setConfirmReset(false)}
                className="px-3 py-1.5 text-xs text-slate-400 hover:text-slate-200 cursor-pointer"
              >
                Cancel
              </button>
              <button
                onClick={handleReset}
                className="px-3 py-1.5 bg-rose-600 hover:bg-rose-500 text-white rounded text-xs font-semibold cursor-pointer"
              >
                Confirm Reset
              </button>
            </div>
          )}
        </div>

        {resetSuccess && (
          <div className="p-2.5 rounded bg-emerald-950 text-emerald-300 border border-emerald-800 text-xs flex items-center gap-2">
            <Check className="w-4 h-4" />
            <span>Workspace restored to standard operational crisis demonstration state.</span>
          </div>
        )}
      </div>
    </div>
  );
};
