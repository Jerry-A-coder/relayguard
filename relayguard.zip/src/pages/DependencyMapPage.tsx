import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { DependencyCanvas3D } from '../components/three/DependencyCanvas3D';
import { DependencyGraph2D } from '../components/graph/DependencyGraph2D';
import { Box, GitFork, X, CheckCircle, Ban, Clock, User, ArrowRight } from 'lucide-react';

export const DependencyMapPage: React.FC = () => {
  const {
    tasks,
    dependencies,
    activeIncident,
    updateTask,
    createDependency,
    deleteDependency,
    logActivity,
  } = useApp();

  const [viewMode, setViewMode] = useState<'3D' | '2D'>('3D');
  const [selectedTaskId, setSelectedTaskId] = useState<string | null>('tsk-02');

  const selectedTask = tasks.find((t) => t.id === selectedTaskId);
  const incomingDependencies = dependencies.filter((d) => d.targetTaskId === selectedTaskId);
  const outgoingDependencies = dependencies.filter((d) => d.sourceTaskId === selectedTaskId);

  const handleStatusChange = (status: any) => {
    if (!selectedTaskId) return;
    const isNowBlocked = status === 'BLOCKED';
    updateTask(selectedTaskId, { status, isBlocked: isNowBlocked });
    logActivity('DEPENDENCY_ADDED', `Task status for "${selectedTask?.title}" updated to ${status}`);
  };

  return (
    <div className="h-[calc(100vh-3.5rem)] flex flex-col bg-slate-950 overflow-hidden relative">
      {/* Top Controls Bar */}
      <div className="h-12 border-b border-slate-800 bg-slate-900 px-4 flex items-center justify-between shrink-0 text-xs">
        <div className="flex items-center gap-3">
          <span className="font-semibold text-slate-100 flex items-center gap-2">
            <span>Dependency Topology:</span>
            <span className="text-slate-400 font-normal truncate max-w-xs">{activeIncident?.title}</span>
          </span>
        </div>

        {/* 3D vs 2D Toggle */}
        <div className="flex items-center gap-1 bg-slate-950 border border-slate-800 rounded p-1">
          <button
            onClick={() => setViewMode('3D')}
            className={`px-3 py-1 rounded text-xs font-medium flex items-center gap-1.5 transition-colors cursor-pointer ${
              viewMode === '3D' ? 'bg-indigo-600 text-white font-semibold' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Box className="w-3.5 h-3.5" />
            <span>3D Spatial Hangar</span>
          </button>
          <button
            onClick={() => setViewMode('2D')}
            className={`px-3 py-1 rounded text-xs font-medium flex items-center gap-1.5 transition-colors cursor-pointer ${
              viewMode === '2D' ? 'bg-indigo-600 text-white font-semibold' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <GitFork className="w-3.5 h-3.5" />
            <span>2D Topological Map</span>
          </button>
        </div>
      </div>

      {/* Main View Area */}
      <div className="flex-1 relative overflow-hidden flex">
        <div className="flex-1 h-full overflow-y-auto">
          {viewMode === '3D' ? (
            <DependencyCanvas3D
              tasks={tasks}
              dependencies={dependencies}
              selectedTaskId={selectedTaskId}
              onSelectTask={(id) => setSelectedTaskId(id)}
            />
          ) : (
            <div className="p-6 max-w-7xl mx-auto">
              <DependencyGraph2D
                tasks={tasks}
                dependencies={dependencies}
                selectedTaskId={selectedTaskId}
                onSelectTask={(id) => setSelectedTaskId(id)}
                onCreateDependency={createDependency}
                onDeleteDependency={deleteDependency}
              />
            </div>
          )}
        </div>

        {/* Selected Task Inspector Drawer (Right Side) */}
        {selectedTask && (
          <div className="w-80 md:w-96 border-l border-slate-800 bg-slate-900/95 flex flex-col shrink-0 shadow-2xl z-30">
            <div className="p-4 border-b border-slate-800 flex items-center justify-between">
              <div>
                <span className="text-[10px] font-mono text-slate-500 uppercase">Task Node Dossier</span>
                <h3 className="text-sm font-bold text-slate-100 truncate">{selectedTask.title}</h3>
              </div>
              <button
                onClick={() => setSelectedTaskId(null)}
                className="text-slate-400 hover:text-white p-1 rounded transition-colors cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="flex-1 p-4 overflow-y-auto space-y-4 text-xs text-slate-300">
              {/* Status & Risk Pill */}
              <div className="flex items-center justify-between">
                <div>
                  <span className="block text-[11px] text-slate-500 font-mono">Current Status</span>
                  <select
                    value={selectedTask.status}
                    onChange={(e) => handleStatusChange(e.target.value)}
                    className="mt-1 bg-slate-950 border border-slate-700 rounded px-2.5 py-1 text-xs text-slate-200 font-mono font-semibold focus:outline-none focus:border-indigo-500 cursor-pointer"
                  >
                    <option value="NOT_STARTED">NOT_STARTED</option>
                    <option value="IN_PROGRESS">IN_PROGRESS</option>
                    <option value="BLOCKED">BLOCKED</option>
                    <option value="COMPLETED">COMPLETED</option>
                    <option value="CANCELLED">CANCELLED</option>
                  </select>
                </div>

                <div className="text-right">
                  <span className="block text-[11px] text-slate-500 font-mono">Risk Level</span>
                  <span
                    className={`inline-block mt-1 px-2 py-0.5 rounded text-[10px] font-mono font-bold ${
                      selectedTask.riskLevel === 'CRITICAL'
                        ? 'bg-rose-950 text-rose-300 border border-rose-800'
                        : selectedTask.riskLevel === 'HIGH'
                        ? 'bg-amber-950 text-amber-300 border border-amber-800'
                        : 'bg-emerald-950 text-emerald-300 border border-emerald-800'
                    }`}
                  >
                    {selectedTask.riskLevel || 'NONE'}
                  </span>
                </div>
              </div>

              <div>
                <span className="block text-[11px] text-slate-500 font-mono mb-1">Description</span>
                <p className="p-2.5 rounded bg-slate-950 border border-slate-800 text-slate-300 leading-relaxed">
                  {selectedTask.description}
                </p>
              </div>

              <div className="grid grid-cols-2 gap-3 text-slate-400">
                <div className="p-2.5 rounded bg-slate-950 border border-slate-800">
                  <span className="block text-[10px] font-mono text-slate-500">Assignee</span>
                  <span className="font-medium text-slate-200 truncate block mt-0.5">
                    {selectedTask.assignee || 'Unassigned'}
                  </span>
                </div>
                <div className="p-2.5 rounded bg-slate-950 border border-slate-800">
                  <span className="block text-[10px] font-mono text-slate-500">Est. Duration</span>
                  <span className="font-medium text-slate-200 block mt-0.5">
                    {selectedTask.estimatedMinutes ? `${selectedTask.estimatedMinutes} mins` : 'N/A'}
                  </span>
                </div>
              </div>

              {/* Direct Upstream Prerequisites */}
              <div>
                <span className="block text-[11px] text-slate-400 font-mono uppercase mb-1.5">
                  Prerequisites Required ({incomingDependencies.length})
                </span>
                {incomingDependencies.length === 0 ? (
                  <p className="text-[11px] text-slate-500 italic">No upstream prerequisites. Can begin immediately.</p>
                ) : (
                  <div className="space-y-1.5">
                    {incomingDependencies.map((d) => {
                      const prereq = tasks.find((t) => t.id === d.sourceTaskId);
                      return (
                        <div
                          key={d.id}
                          className="p-2 rounded bg-slate-950 border border-slate-800 flex items-center justify-between text-[11px]"
                        >
                          <span className="font-medium text-slate-200 truncate">{prereq?.title || d.sourceTaskId}</span>
                          <span
                            className={`font-mono text-[10px] px-1.5 py-0.2 rounded ${
                              prereq?.status === 'COMPLETED' ? 'text-emerald-400' : 'text-rose-400'
                            }`}
                          >
                            {prereq?.status}
                          </span>
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>

              {/* Direct Downstream Dependents */}
              <div>
                <span className="block text-[11px] text-slate-400 font-mono uppercase mb-1.5">
                  Downstream Dependents Blocked ({outgoingDependencies.length})
                </span>
                {outgoingDependencies.length === 0 ? (
                  <p className="text-[11px] text-slate-500 italic">Terminal step. No downstream dependents.</p>
                ) : (
                  <div className="space-y-1.5">
                    {outgoingDependencies.map((d) => {
                      const dep = tasks.find((t) => t.id === d.targetTaskId);
                      return (
                        <div
                          key={d.id}
                          className="p-2 rounded bg-slate-950 border border-slate-800 flex items-center justify-between text-[11px]"
                        >
                          <span className="font-medium text-slate-200 truncate">{dep?.title || d.targetTaskId}</span>
                          <span className="font-mono text-[10px] text-amber-400">{dep?.status}</span>
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
