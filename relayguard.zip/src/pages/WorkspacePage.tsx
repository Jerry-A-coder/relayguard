import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import {
  ShieldAlert,
  Clock,
  Ban,
  CheckCircle2,
  TrendingUp,
  FileText,
  History,
  Compass,
  ArrowRight,
  AlertTriangle,
  RotateCcw,
  Sparkles,
  ExternalLink,
  Mic,
  MessageSquare,
} from 'lucide-react';
import { NavigationTab } from '../components/layout/Sidebar';
import { VoiceDictationNotes } from '../components/voice/VoiceDictationNotes';
import { GeminiChatbot } from '../components/chat/GeminiChatbot';

interface WorkspacePageProps {
  onNavigate: (tab: NavigationTab) => void;
}

export const WorkspacePage: React.FC<WorkspacePageProps> = ({ onNavigate }) => {
  const {
    activeIncident,
    tasks,
    dependencies,
    recoveryPlans,
    selectedPlan,
    approvals,
    activities,
    updateIncident,
    logActivity,
  } = useApp();

  const [activeTab, setActiveTab] = useState<
    'overview' | 'impact' | 'plan' | 'dictation' | 'chat' | 'evidence' | 'activity'
  >('overview');
  const [isRecalculating, setIsRecalculating] = useState(false);

  if (!activeIncident) {
    return (
      <div className="p-8 text-center text-slate-400">
        <p>No active incident selected. Please select or report an incident from the Overview.</p>
      </div>
    );
  }

  const incidentTasks = tasks.filter((t) => t.incidentId === activeIncident.id || !t.incidentId);
  const blockedTasks = incidentTasks.filter((t) => t.isBlocked || t.status === 'BLOCKED');
  const incidentPlans = recoveryPlans.filter((p) => p.incidentId === activeIncident.id);
  const incidentApprovals = approvals.filter((a) => a.incidentId === activeIncident.id);
  const incidentActivities = activities.filter((a) => a.incidentId === activeIncident.id);

  const handleRecalculate = async () => {
    setIsRecalculating(true);
    try {
      const response = await fetch('/api/recovery/impact-analysis', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          tasks: incidentTasks,
          edges: dependencies,
          disruptedTaskId: incidentTasks[1]?.id,
        }),
      });
      const data = await response.json();
      logActivity(
        'IMPACT_CALCULATED',
        `Recalculated graph topology for "${activeIncident.title}"`,
        `Identified ${data.blockedTaskIds?.length || 0} blocked tasks and ${data.affectedTaskIds?.length || 0} downstream tasks.`
      );
    } catch (e) {
      console.error(e);
    } finally {
      setIsRecalculating(false);
    }
  };

  return (
    <div className="p-6 max-w-7xl mx-auto space-y-6">
      {/* Incident Header Dossier */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-lg">
        <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4 pb-4 border-b border-slate-800">
          <div className="space-y-1.5">
            <div className="flex flex-wrap items-center gap-2">
              <span
                className={`px-2.5 py-0.5 rounded text-[11px] font-mono font-bold ${
                  activeIncident.severity === 'CRITICAL'
                    ? 'bg-rose-950 text-rose-300 border border-rose-800'
                    : 'bg-amber-950 text-amber-300 border border-amber-800'
                }`}
              >
                {activeIncident.severity}
              </span>
              {activeIncident.priority && (
                <span
                  className={`px-2.5 py-0.5 rounded text-[11px] font-mono font-bold ${
                    activeIncident.priority === 'Critical'
                      ? 'bg-rose-950 text-rose-300 border border-rose-800'
                      : activeIncident.priority === 'High'
                      ? 'bg-amber-950 text-amber-300 border border-amber-800'
                      : activeIncident.priority === 'Medium'
                      ? 'bg-blue-950 text-blue-300 border border-blue-800'
                      : 'bg-slate-800 text-slate-300 border border-slate-700'
                  }`}
                >
                  PRIORITY: {activeIncident.priority.toUpperCase()}
                </span>
              )}
              <span className="text-xs px-2 py-0.5 rounded bg-slate-800 text-slate-300 border border-slate-700">
                {activeIncident.category}
              </span>
              <span className="text-xs px-2 py-0.5 rounded bg-cyan-950 text-cyan-300 border border-cyan-800 font-mono">
                {activeIncident.verificationStatus}
              </span>
              <span className="text-xs text-slate-400 font-mono">ID: {activeIncident.id}</span>
            </div>

            <h1 className="text-lg font-bold text-slate-100">{activeIncident.title}</h1>
            <p className="text-xs text-slate-400 max-w-3xl">{activeIncident.description}</p>
          </div>

          <div className="flex flex-wrap items-center gap-2 shrink-0">
            <button
              onClick={handleRecalculate}
              disabled={isRecalculating}
              className="px-3.5 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded text-xs font-medium flex items-center gap-2 border border-slate-700 transition-colors cursor-pointer"
            >
              <RotateCcw className={`w-3.5 h-3.5 ${isRecalculating ? 'animate-spin' : ''}`} />
              <span>{isRecalculating ? 'Recalculating...' : 'Recalculate Impact'}</span>
            </button>

            <button
              onClick={() => onNavigate('ai-command')}
              className="px-3.5 py-2 bg-indigo-600 hover:bg-indigo-500 text-white rounded text-xs font-semibold flex items-center gap-2 shadow-sm transition-colors cursor-pointer"
            >
              <Sparkles className="w-3.5 h-3.5" />
              <span>High Thinking Contingency (Argon)</span>
            </button>
          </div>
        </div>

        {/* Quick Facts Grid */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 pt-3 text-xs text-slate-400">
          <div>
            <span className="block text-[11px] text-slate-500 font-mono">Target Deadline</span>
            <span className="font-semibold text-slate-200">
              {activeIncident.deadline ? new Date(activeIncident.deadline).toLocaleString() : 'Open / Unset'}
            </span>
          </div>
          <div>
            <span className="block text-[11px] text-slate-500 font-mono">Reporter / Owner</span>
            <span className="font-semibold text-slate-200">{activeIncident.creatorName || activeIncident.creatorId}</span>
          </div>
          <div>
            <span className="block text-[11px] text-slate-500 font-mono">Evidence Source</span>
            <span className="font-semibold text-slate-200 truncate block">
              {activeIncident.informationSource || 'Verified API Telemetry'}
            </span>
          </div>
          <div>
            <span className="block text-[11px] text-slate-500 font-mono">Active Recovery Plan</span>
            <span className="font-semibold text-indigo-400 truncate block">
              {selectedPlan ? selectedPlan.title : 'None Selected'}
            </span>
          </div>
        </div>
      </div>

      {/* Tabs Navigation */}
      <div className="flex items-center gap-1 border-b border-slate-800 text-xs font-medium">
        {[
          { id: 'overview', label: 'Dossier & Constraints', icon: FileText },
          { id: 'impact', label: `Impact Analysis (${blockedTasks.length} Blocked)`, icon: Ban },
          { id: 'plan', label: `Recovery Plan (${selectedPlan?.actions.length || 0} Actions)`, icon: Compass },
          { id: 'dictation', label: 'Voice Notes & Dictation', icon: Mic },
          { id: 'chat', label: 'Resilience AI Chatbot', icon: MessageSquare },
          { id: 'evidence', label: 'Evidence & Verification', icon: CheckCircle2 },
          { id: 'activity', label: `Activity Audit (${incidentActivities.length})`, icon: History },
        ].map((tab) => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;

          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={`flex items-center gap-2 px-4 py-2.5 border-b-2 transition-colors cursor-pointer ${
                isActive
                  ? 'border-indigo-500 text-indigo-400 font-semibold bg-slate-900/50'
                  : 'border-transparent text-slate-400 hover:text-slate-200 hover:border-slate-700'
              }`}
            >
              <Icon className="w-3.5 h-3.5" />
              <span>{tab.label}</span>
            </button>
          );
        })}
      </div>

      {/* TAB CONTENT 1: OVERVIEW */}
      {activeTab === 'overview' && (
        <div className="space-y-4">
          <div className="bg-slate-900 border border-slate-800 rounded-xl p-5">
            <h3 className="text-sm font-semibold text-slate-100 mb-2">Ground Truth vs Working Assumptions</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="p-3.5 rounded-lg bg-slate-950 border border-slate-800">
                <span className="text-xs font-semibold text-emerald-400 flex items-center gap-1.5 mb-1.5">
                  <CheckCircle2 className="w-3.5 h-3.5" />
                  <span>Verified Operational Facts</span>
                </span>
                <ul className="text-xs text-slate-300 space-y-1 list-disc list-inside">
                  <li>Disruption confirmed through carrier notice / telemetry.</li>
                  <li>Prerequisite task &ldquo;{incidentTasks[0]?.title}&rdquo; is logged COMPLETED.</li>
                  <li>Physical hold verified at customs hub Rotterdam.</li>
                </ul>
              </div>

              <div className="p-3.5 rounded-lg bg-slate-950 border border-slate-800">
                <span className="text-xs font-semibold text-amber-400 flex items-center gap-1.5 mb-1.5">
                  <AlertTriangle className="w-3.5 h-3.5" />
                  <span>Unresolved Working Assumptions</span>
                </span>
                <ul className="text-xs text-slate-300 space-y-1 list-disc list-inside">
                  <li>Client flexibility on 48h acceptance window unconfirmed until formal request.</li>
                  <li>Hamburg reserve inventory available subject to warehouse physical count.</li>
                </ul>
              </div>
            </div>
          </div>

          <div className="bg-slate-900 border border-slate-800 rounded-xl p-5">
            <h3 className="text-sm font-semibold text-slate-100 mb-2">Governing Constraints</h3>
            <p className="text-xs text-slate-300 leading-relaxed bg-slate-950 p-3 rounded border border-slate-800">
              {activeIncident.knownConstraints || 'No explicit constraints recorded for this operational window.'}
            </p>
          </div>
        </div>
      )}

      {/* TAB CONTENT 2: IMPACT ANALYSIS */}
      {activeTab === 'impact' && (
        <div className="space-y-4">
          <div className="bg-slate-900 border border-slate-800 rounded-xl p-5">
            <div className="flex items-center justify-between mb-3 border-b border-slate-800 pb-2">
              <div>
                <h3 className="text-sm font-semibold text-slate-100">Downstream Impact & Dependency Cascade</h3>
                <p className="text-xs text-slate-400">
                  The graph traversal engine identifies tasks whose prerequisites fail or remain uncompleted.
                </p>
              </div>
              <button
                onClick={() => onNavigate('dependency-map')}
                className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-cyan-300 text-xs font-medium rounded border border-slate-700 flex items-center gap-1.5 cursor-pointer"
              >
                <span>View in 3D Hangar</span>
                <ExternalLink className="w-3 h-3" />
              </button>
            </div>

            <div className="space-y-3">
              {incidentTasks.map((t) => (
                <div
                  key={t.id}
                  className={`p-3.5 rounded-lg border flex items-center justify-between gap-4 ${
                    t.isBlocked || t.status === 'BLOCKED'
                      ? 'bg-rose-950/30 border-rose-800/80'
                      : t.status === 'COMPLETED'
                      ? 'bg-emerald-950/20 border-emerald-800/60'
                      : 'bg-slate-950 border-slate-800'
                  }`}
                >
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="font-semibold text-xs text-slate-200">{t.title}</span>
                      <span
                        className={`text-[10px] font-mono px-2 py-0.5 rounded ${
                          t.isBlocked || t.status === 'BLOCKED'
                            ? 'bg-rose-950 text-rose-300 border border-rose-800'
                            : t.status === 'COMPLETED'
                            ? 'bg-emerald-950 text-emerald-300 border border-emerald-800'
                            : 'bg-slate-800 text-slate-400'
                        }`}
                      >
                        {t.status}
                      </span>
                    </div>
                    <p className="text-xs text-slate-400 mt-0.5">{t.description}</p>
                  </div>

                  <div className="text-right text-xs text-slate-400 shrink-0">
                    <span className="block font-medium text-slate-300">{t.assignee || 'Unassigned'}</span>
                    <span className="block text-[11px] font-mono">{t.deadline ? new Date(t.deadline).toLocaleDateString() : 'No deadline'}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* TAB CONTENT 3: ACTIVE RECOVERY PLAN */}
      {activeTab === 'plan' && (
        <div className="space-y-4">
          {selectedPlan ? (
            <div className="bg-slate-900 border border-indigo-900/60 rounded-xl p-5 shadow-lg">
              <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 mb-4 pb-3 border-b border-slate-800">
                <div>
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-mono font-bold px-2 py-0.5 rounded bg-indigo-950 text-indigo-300 border border-indigo-800">
                      ACTIVE RECOVERY STRATEGY
                    </span>
                    <span className="text-xs text-emerald-400 font-mono font-semibold">
                      Confidence Score: {selectedPlan.score}%
                    </span>
                  </div>
                  <h3 className="text-base font-bold text-slate-100 mt-1">{selectedPlan.title}</h3>
                  <p className="text-xs text-slate-400 mt-0.5">Estimated Duration: {selectedPlan.estimatedDuration}</p>
                </div>

                <button
                  onClick={() => onNavigate('recovery-plans')}
                  className="px-3.5 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded text-xs font-medium border border-slate-700 cursor-pointer self-start sm:self-auto"
                >
                  Compare All 3 Alternative Plans &rarr;
                </button>
              </div>

              {/* Ordered Actions List */}
              <div className="space-y-3">
                <h4 className="text-xs font-semibold uppercase tracking-wider text-slate-400">
                  Sequential Recovery Actions
                </h4>
                {selectedPlan.actions.map((act) => (
                  <div
                    key={act.id}
                    className="p-3.5 rounded-lg bg-slate-950 border border-slate-800 flex flex-col md:flex-row md:items-center md:justify-between gap-3"
                  >
                    <div className="space-y-1">
                      <div className="flex items-center gap-2">
                        <span className="w-5 h-5 rounded-full bg-indigo-900/80 border border-indigo-700 text-indigo-300 text-xs font-mono font-bold flex items-center justify-center">
                          {act.order}
                        </span>
                        <span className="text-xs font-semibold text-slate-100">{act.title}</span>
                        {act.requiresApproval && (
                          <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-amber-950 text-amber-300 border border-amber-800">
                            APPROVAL REQUIRED
                          </span>
                        )}
                      </div>
                      <p className="text-xs text-slate-400">{act.description}</p>
                      <div className="text-[11px] text-slate-500 font-mono flex items-center gap-4">
                        <span>Role: {act.responsibleRole}</span>
                        <span>Est: {act.estimatedMinutes} mins</span>
                        {act.targetRecipient && <span>Target: {act.targetRecipient}</span>}
                      </div>
                    </div>

                    {act.requiresApproval && (
                      <button
                        onClick={() => onNavigate('approvals')}
                        className="px-3 py-1.5 bg-indigo-600 hover:bg-indigo-500 text-white rounded text-xs font-medium shrink-0 cursor-pointer"
                      >
                        Go to Approval Queue
                      </button>
                    )}
                  </div>
                ))}
              </div>
            </div>
          ) : (
            <div className="bg-slate-900 border border-slate-800 rounded-xl p-8 text-center text-slate-400">
              <Compass className="w-8 h-8 text-indigo-400 mx-auto mb-2" />
              <p className="text-sm font-semibold text-slate-200">No Recovery Plan Currently Selected</p>
              <p className="text-xs text-slate-400 mt-1 mb-4">
                Generate or compare alternative recovery workflows to unblock the operational commitments.
              </p>
              <button
                onClick={() => onNavigate('recovery-plans')}
                className="px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white rounded text-xs font-medium cursor-pointer"
              >
                Open Plan Comparison Matrix
              </button>
            </div>
          )}
        </div>
      )}

      {/* TAB CONTENT 4: VOICE DICTATION & FIELD NOTES */}
      {activeTab === 'dictation' && (
        <div className="space-y-4">
          <VoiceDictationNotes />
        </div>
      )}

      {/* TAB CONTENT 5: GEMINI RESILIENCE CHATBOT */}
      {activeTab === 'chat' && (
        <div className="space-y-4">
          <GeminiChatbot />
        </div>
      )}

      {/* TAB CONTENT 6: EVIDENCE */}
      {activeTab === 'evidence' && (
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-4">
          <h3 className="text-sm font-semibold text-slate-100">Evidence & Verification Trail</h3>
          <div className="bg-slate-950 p-4 rounded-lg border border-slate-800 text-xs text-slate-300 space-y-2">
            <div className="flex items-center justify-between">
              <span className="font-semibold text-slate-200">Registered Source</span>
              <span className="font-mono text-cyan-400">{activeIncident.informationSource || 'Carrier API'}</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="font-semibold text-slate-200">Verification Level</span>
              <span className="font-mono text-emerald-400">{activeIncident.verificationStatus}</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="font-semibold text-slate-200">Registered Timestamp</span>
              <span className="font-mono text-slate-400">{new Date(activeIncident.createdAt).toISOString()}</span>
            </div>
          </div>
        </div>
      )}

      {/* TAB CONTENT 7: ACTIVITY AUDIT WITH DIRECT DICTATION */}
      {activeTab === 'activity' && (
        <div className="space-y-5">
          {/* Direct Voice Dictation Header */}
          <VoiceDictationNotes />

          <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-3">
            <h3 className="text-sm font-semibold text-slate-100 mb-2">Incident Audit Timeline</h3>
            {incidentActivities.length === 0 ? (
              <p className="text-xs text-slate-400">No activity events recorded yet.</p>
            ) : (
              <div className="space-y-2.5">
                {incidentActivities.map((act) => (
                  <div key={act.id} className="p-3 rounded bg-slate-950 border border-slate-800 text-xs">
                    <div className="flex items-center justify-between text-[11px] text-slate-400 mb-1">
                      <span className="font-semibold text-slate-300">{act.actorName}</span>
                      <span className="font-mono">{new Date(act.createdAt).toLocaleTimeString()}</span>
                    </div>
                    <p className="text-slate-200 font-medium">{act.summary}</p>
                    {act.details && <p className="text-[11px] text-slate-400 mt-1">{act.details}</p>}
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
