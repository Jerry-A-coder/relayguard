import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { IncidentCategory, IncidentPriority, IncidentSeverity, VerificationStatus } from '../types';
import { AlertCircle, CheckCircle2, ShieldAlert, ArrowRight, Sparkles } from 'lucide-react';
import { NavigationTab } from '../components/layout/Sidebar';

interface IntakePageProps {
  onNavigate: (tab: NavigationTab) => void;
}

export const IntakePage: React.FC<IntakePageProps> = ({ onNavigate }) => {
  const { createIncident, currentUser, tasks } = useApp();

  const [title, setTitle] = useState('');
  const [category, setCategory] = useState<IncidentCategory>('Delayed delivery');
  const [severity, setSeverity] = useState<IncidentSeverity>('CRITICAL');
  const [priority, setPriority] = useState<IncidentPriority>('Critical');
  const [verificationStatus, setVerificationStatus] = useState<VerificationStatus>('VERIFIED');
  const [description, setDescription] = useState('');
  const [deadline, setDeadline] = useState('');
  const [knownConstraints, setKnownConstraints] = useState('');
  const [informationSource, setInformationSource] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [impactAssessmentChoice, setImpactAssessmentChoice] = useState<'IMMEDIATE' | 'LATER'>('IMMEDIATE');

  const categories: IncidentCategory[] = [
    'Missing document',
    'Delayed delivery',
    'Appointment change',
    'Approval delay',
    'Service interruption',
    'Dependency failure',
    'Regulatory hold',
    'Other',
  ];

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim() || !description.trim()) return;

    setIsSubmitting(true);
    try {
      const newId = createIncident({
        title,
        description,
        category,
        severity,
        priority,
        status: 'ACTIVE',
        verificationStatus,
        creatorId: currentUser.userId,
        creatorName: currentUser.displayName,
        deadline: deadline || undefined,
        knownConstraints: knownConstraints || undefined,
        informationSource: informationSource || 'User Operator Intake',
      });

      // Navigate directly to incident workspace
      onNavigate('workspace');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="p-6 max-w-4xl mx-auto space-y-6">
      <div className="border-b border-slate-800 pb-4">
        <h1 className="text-xl font-bold text-slate-100 flex items-center gap-2">
          <AlertCircle className="w-5 h-5 text-rose-500" />
          <span>Disruption Intake & Verification Wizard</span>
        </h1>
        <p className="text-xs text-slate-400 mt-1">
          Capture and validate unexpected events to immediately compute downstream dependency breakage.
        </p>
      </div>

      <form onSubmit={handleSubmit} className="bg-slate-900 border border-slate-800 rounded-xl p-6 shadow-xl space-y-5">
        {/* Step 1: Disruption Essentials */}
        <div className="space-y-4">
          <h2 className="text-xs font-semibold uppercase tracking-wider text-indigo-400 border-b border-slate-800 pb-1.5">
            1. Core Incident Parameters
          </h2>

          <div>
            <label className="block text-xs font-medium text-slate-300 mb-1">
              Disruption Title <span className="text-rose-400">*</span>
            </label>
            <input
              type="text"
              required
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="e.g., Cargo Vessel Engine Breakdown Holding Batch #772"
              className="w-full bg-slate-950 border border-slate-700 rounded-lg px-3.5 py-2 text-xs text-slate-100 placeholder-slate-500 focus:outline-none focus:border-indigo-500"
            />
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">Category</label>
              <select
                value={category}
                onChange={(e) => setCategory(e.target.value as IncidentCategory)}
                className="w-full bg-slate-950 border border-slate-700 rounded-lg px-3 py-2 text-xs text-slate-200 focus:outline-none focus:border-indigo-500 cursor-pointer"
              >
                {categories.map((c) => (
                  <option key={c} value={c}>
                    {c}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">Severity</label>
              <select
                value={severity}
                onChange={(e) => setSeverity(e.target.value as IncidentSeverity)}
                className="w-full bg-slate-950 border border-slate-700 rounded-lg px-3 py-2 text-xs text-slate-200 focus:outline-none focus:border-indigo-500 cursor-pointer font-bold"
              >
                <option value="CRITICAL" className="text-rose-400">CRITICAL</option>
                <option value="HIGH" className="text-amber-400">HIGH</option>
                <option value="MEDIUM" className="text-blue-400">MEDIUM</option>
                <option value="LOW" className="text-slate-400">LOW</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">Priority</label>
              <select
                value={priority}
                onChange={(e) => setPriority(e.target.value as IncidentPriority)}
                className="w-full bg-slate-950 border border-slate-700 rounded-lg px-3 py-2 text-xs text-slate-200 focus:outline-none focus:border-indigo-500 cursor-pointer font-bold"
              >
                <option value="Critical" className="text-rose-400">Critical</option>
                <option value="High" className="text-amber-400">High</option>
                <option value="Medium" className="text-blue-400">Medium</option>
                <option value="Low" className="text-slate-400">Low</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">Confidence</label>
              <select
                value={verificationStatus}
                onChange={(e) => setVerificationStatus(e.target.value as VerificationStatus)}
                className="w-full bg-slate-950 border border-slate-700 rounded-lg px-3 py-2 text-xs text-slate-200 focus:outline-none focus:border-indigo-500 cursor-pointer"
              >
                <option value="VERIFIED">VERIFIED</option>
                <option value="USER_REPORTED">USER_REPORTED</option>
                <option value="UNVERIFIED">UNVERIFIED</option>
                <option value="CONJECTURE">CONJECTURE</option>
              </select>
            </div>
          </div>
        </div>

        {/* Step 2: Context & Evidence */}
        <div className="space-y-4 pt-3 border-t border-slate-800">
          <h2 className="text-xs font-semibold uppercase tracking-wider text-indigo-400 border-b border-slate-800 pb-1.5">
            2. Operational Context & Constraints
          </h2>

          <div>
            <label className="block text-xs font-medium text-slate-300 mb-1">
              Factual Description of the Disruption <span className="text-rose-400">*</span>
            </label>
            <textarea
              required
              rows={3}
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Provide exact facts: What failed, when, what was scheduled to occur, and what cannot proceed..."
              className="w-full bg-slate-950 border border-slate-700 rounded-lg px-3.5 py-2 text-xs text-slate-100 placeholder-slate-500 focus:outline-none focus:border-indigo-500"
            />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">Hard Deadline at Risk</label>
              <input
                type="datetime-local"
                value={deadline}
                onChange={(e) => setDeadline(e.target.value)}
                className="w-full bg-slate-950 border border-slate-700 rounded-lg px-3 py-2 text-xs text-slate-200 focus:outline-none focus:border-indigo-500"
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">Information / Evidence Source</label>
              <input
                type="text"
                value={informationSource}
                onChange={(e) => setInformationSource(e.target.value)}
                placeholder="e.g., Port Authority Notice #448, Carrier API, Email"
                className="w-full bg-slate-950 border border-slate-700 rounded-lg px-3 py-2 text-xs text-slate-200 placeholder-slate-500 focus:outline-none focus:border-indigo-500"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-medium text-slate-300 mb-1">Known Constraints & Non-Negotiables</label>
            <textarea
              rows={2}
              value={knownConstraints}
              onChange={(e) => setKnownConstraints(e.target.value)}
              placeholder="e.g., Cleanroom assembly slot expires Thursday 5 PM; budget ceiling for expedite courier is €600..."
              className="w-full bg-slate-950 border border-slate-700 rounded-lg px-3.5 py-2 text-xs text-slate-100 placeholder-slate-500 focus:outline-none focus:border-indigo-500"
            />
          </div>
        </div>

        {/* Step 3: Progressive Disclosure Impact Mode */}
        <div className="pt-3 border-t border-slate-800 space-y-3">
          <h2 className="text-xs font-semibold uppercase tracking-wider text-indigo-400">
            3. Downstream Dependency Linking
          </h2>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <label
              onClick={() => setImpactAssessmentChoice('IMMEDIATE')}
              className={`p-3.5 rounded-lg border flex items-start gap-3 cursor-pointer transition-colors ${
                impactAssessmentChoice === 'IMMEDIATE'
                  ? 'bg-indigo-950/40 border-indigo-500 text-white'
                  : 'bg-slate-950 border-slate-800 text-slate-400 hover:border-slate-700'
              }`}
            >
              <input
                type="radio"
                name="impactChoice"
                checked={impactAssessmentChoice === 'IMMEDIATE'}
                onChange={() => setImpactAssessmentChoice('IMMEDIATE')}
                className="mt-0.5 text-indigo-500"
              />
              <div>
                <span className="text-xs font-semibold block text-slate-200">Run Deterministic Impact Traversal</span>
                <span className="text-[11px] text-slate-400 block mt-0.5">
                  Calculate blocked tasks and candidate recovery workflows immediately upon registration.
                </span>
              </div>
            </label>

            <label
              onClick={() => setImpactAssessmentChoice('LATER')}
              className={`p-3.5 rounded-lg border flex items-start gap-3 cursor-pointer transition-colors ${
                impactAssessmentChoice === 'LATER'
                  ? 'bg-indigo-950/40 border-indigo-500 text-white'
                  : 'bg-slate-950 border-slate-800 text-slate-400 hover:border-slate-700'
              }`}
            >
              <input
                type="radio"
                name="impactChoice"
                checked={impactAssessmentChoice === 'LATER'}
                onChange={() => setImpactAssessmentChoice('LATER')}
                className="mt-0.5 text-indigo-500"
              />
              <div>
                <span className="text-xs font-semibold block text-slate-200">Save as &ldquo;Impact Not Yet Assessed&rdquo;</span>
                <span className="text-[11px] text-slate-400 block mt-0.5">
                  Record disruption without altering task statuses until evidence verification is completed.
                </span>
              </div>
            </label>
          </div>
        </div>

        {/* Submit Bar */}
        <div className="flex items-center justify-between pt-4 border-t border-slate-800">
          <button
            type="button"
            onClick={() => onNavigate('overview')}
            className="px-4 py-2 text-xs text-slate-400 hover:text-slate-200 cursor-pointer"
          >
            Cancel
          </button>

          <button
            type="submit"
            disabled={isSubmitting}
            className="px-5 py-2.5 bg-rose-600 hover:bg-rose-500 disabled:opacity-50 text-white rounded-lg text-xs font-semibold flex items-center gap-2 shadow-lg transition-colors cursor-pointer"
          >
            <ShieldAlert className="w-4 h-4" />
            <span>{isSubmitting ? 'Registering & Computing...' : 'Register Disruption & Open Workspace'}</span>
            <ArrowRight className="w-4 h-4 ml-1" />
          </button>
        </div>
      </form>
    </div>
  );
};
