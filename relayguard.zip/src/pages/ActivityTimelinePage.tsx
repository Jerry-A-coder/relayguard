import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { History, Search, Download, Filter, Clock, User, ShieldCheck } from 'lucide-react';

export const ActivityTimelinePage: React.FC = () => {
  const { activities, activeWorkspace } = useApp();

  const [searchTerm, setSearchTerm] = useState('');
  const [filterType, setFilterType] = useState('ALL');

  const filteredActivities = activities.filter((act) => {
    if (filterType !== 'ALL' && act.eventType !== filterType) return false;
    if (!searchTerm.trim()) return true;
    const term = searchTerm.toLowerCase();
    return (
      act.summary.toLowerCase().includes(term) ||
      (act.details && act.details.toLowerCase().includes(term)) ||
      act.actorName.toLowerCase().includes(term)
    );
  });

  const handleExport = () => {
    const dataStr = 'data:text/json;charset=utf-8,' + encodeURIComponent(JSON.stringify(activities, null, 2));
    const downloadAnchor = document.createElement('a');
    downloadAnchor.setAttribute('href', dataStr);
    downloadAnchor.setAttribute('download', `RelayGuard_Audit_Trail_${Date.now()}.json`);
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();
  };

  const getEventBadgeClass = (eventType: string) => {
    switch (eventType) {
      case 'ACTION_EXECUTED':
      case 'APPROVAL_GRANTED':
        return 'bg-emerald-950 text-emerald-300 border-emerald-800';
      case 'ACTION_FAILED':
      case 'APPROVAL_REJECTED':
        return 'bg-rose-950 text-rose-300 border-rose-800';
      case 'INCIDENT_CREATED':
        return 'bg-purple-950 text-purple-300 border-purple-800';
      case 'PLAN_SELECTED':
      case 'PLAN_GENERATED':
        return 'bg-indigo-950 text-indigo-300 border-indigo-800';
      case 'IMPACT_CALCULATED':
        return 'bg-cyan-950 text-cyan-300 border-cyan-800';
      default:
        return 'bg-slate-800 text-slate-300 border-slate-700';
    }
  };

  return (
    <div className="p-6 max-w-5xl mx-auto space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 border-b border-slate-800 pb-4">
        <div>
          <h1 className="text-xl font-bold text-slate-100 flex items-center gap-2">
            <History className="w-5 h-5 text-indigo-400" />
            <span>Immutable Activity & Audit Timeline</span>
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            Chronological audit trail of all operational decisions, algorithmic impact calculations, and authorized executions.
          </p>
        </div>

        <button
          onClick={handleExport}
          className="px-3.5 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-medium rounded border border-slate-700 flex items-center gap-2 transition-colors cursor-pointer self-start sm:self-auto"
        >
          <Download className="w-3.5 h-3.5" />
          <span>Export Audit Log</span>
        </button>
      </div>

      {/* Filter and Search Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center gap-3 bg-slate-900 p-3 rounded-lg border border-slate-800 text-xs">
        <div className="flex-1 relative">
          <Search className="w-3.5 h-3.5 text-slate-500 absolute left-3 top-2.5" />
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="Search audit trail by summary, actor, or detail..."
            className="w-full bg-slate-950 border border-slate-800 rounded pl-8 pr-3 py-1.5 text-xs text-slate-200 placeholder-slate-500 focus:outline-none focus:border-indigo-500"
          />
        </div>

        <div className="flex items-center gap-2 shrink-0">
          <Filter className="w-3.5 h-3.5 text-slate-500" />
          <select
            value={filterType}
            onChange={(e) => setFilterType(e.target.value)}
            className="bg-slate-950 border border-slate-800 rounded px-2.5 py-1.5 text-xs text-slate-300 focus:outline-none focus:border-indigo-500 cursor-pointer"
          >
            <option value="ALL">All Event Types</option>
            <option value="INCIDENT_CREATED">Incident Created</option>
            <option value="IMPACT_CALCULATED">Impact Calculated</option>
            <option value="PLAN_GENERATED">Plan Generated</option>
            <option value="PLAN_SELECTED">Plan Selected</option>
            <option value="APPROVAL_REQUESTED">Approval Requested</option>
            <option value="ACTION_EXECUTED">Action Executed</option>
            <option value="ACTION_FAILED">Action Failed</option>
          </select>
        </div>
      </div>

      {/* Activity Timeline List */}
      <div className="space-y-3 relative before:absolute before:inset-0 before:left-5 before:w-0.5 before:bg-slate-800 before:z-0">
        {filteredActivities.length === 0 ? (
          <div className="bg-slate-900 border border-slate-800 rounded-xl p-8 text-center text-slate-400 z-10 relative">
            <p className="text-xs">No matching activity records found.</p>
          </div>
        ) : (
          filteredActivities.map((act) => (
            <div
              key={act.id}
              className="relative z-10 flex items-start gap-4 p-4 rounded-xl bg-slate-900 border border-slate-800/90 shadow-sm hover:border-slate-700 transition-colors"
            >
              <div className="w-10 h-10 rounded-full bg-slate-950 border border-slate-800 flex items-center justify-center shrink-0 text-indigo-400 mt-0.5">
                <Clock className="w-4 h-4" />
              </div>

              <div className="flex-1 space-y-1 text-xs">
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <div className="flex items-center gap-2">
                    <span className="font-semibold text-slate-200 text-xs">{act.actorName}</span>
                    <span className={`text-[10px] font-mono px-2 py-0.5 rounded border ${getEventBadgeClass(act.eventType)}`}>
                      {act.eventType}
                    </span>
                  </div>
                  <span className="text-[11px] font-mono text-slate-500">
                    {new Date(act.createdAt).toLocaleString()}
                  </span>
                </div>

                <p className="text-slate-100 font-medium">{act.summary}</p>
                {act.details && (
                  <p className="text-slate-400 text-[11px] leading-relaxed pt-1 border-t border-slate-800/60 mt-1">
                    {act.details}
                  </p>
                )}
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
};
