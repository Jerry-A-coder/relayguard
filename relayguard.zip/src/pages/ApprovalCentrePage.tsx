import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import {
  CheckSquare,
  CheckCircle2,
  XCircle,
  HelpCircle,
  AlertTriangle,
  Clock,
  ShieldAlert,
  Send,
  RotateCcw,
  Check,
  X,
  MessageSquare,
} from 'lucide-react';
import { Approval } from '../types';

export const ApprovalCentrePage: React.FC = () => {
  const { approvals, approveAction, rejectAction, requestChangesAction, currentUser, activeIncident } = useApp();

  const [executingId, setExecutingId] = useState<string | null>(null);
  const [rejectingApprovalId, setRejectingApprovalId] = useState<string | null>(null);
  const [rejectReason, setRejectReason] = useState('');
  const [changesApprovalId, setChangesApprovalId] = useState<string | null>(null);
  const [changesNote, setChangesNote] = useState('');
  const [resultMessage, setResultMessage] = useState<{ id: string; msg: string; isError?: boolean } | null>(null);

  const handleApprove = async (appr: Approval) => {
    setExecutingId(appr.id);
    setResultMessage(null);
    try {
      const res = await approveAction(appr.id);
      if (res.success) {
        setResultMessage({ id: appr.id, msg: res.summary || 'Action authorized and dispatched successfully.' });
      } else {
        setResultMessage({ id: appr.id, msg: res.error || 'Execution failed', isError: true });
      }
    } finally {
      setExecutingId(null);
    }
  };

  const handleConfirmReject = (e: React.FormEvent) => {
    e.preventDefault();
    if (rejectingApprovalId) {
      rejectAction(rejectingApprovalId, rejectReason);
      setRejectingApprovalId(null);
      setRejectReason('');
    }
  };

  const handleConfirmChanges = (e: React.FormEvent) => {
    e.preventDefault();
    if (changesApprovalId) {
      requestChangesAction(changesApprovalId, changesNote);
      setChangesApprovalId(null);
      setChangesNote('');
    }
  };

  const isViewer = currentUser.role === 'VIEWER';

  return (
    <div className="p-6 max-w-5xl mx-auto space-y-6">
      {/* Header */}
      <div className="border-b border-slate-800 pb-4 flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <div>
          <h1 className="text-xl font-bold text-slate-100 flex items-center gap-2">
            <CheckSquare className="w-5 h-5 text-indigo-400" />
            <span>Operational Approval Centre</span>
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            Consequential operations are held in this queue. Zero autonomous actions execute without human sign-off.
          </p>
        </div>

        {isViewer && (
          <div className="p-2 rounded bg-amber-950/80 border border-amber-800 text-amber-300 text-xs flex items-center gap-2">
            <AlertTriangle className="w-4 h-4 text-amber-400 shrink-0" />
            <span>Viewer role is read-only. Switch to ADMIN or OWNER in top bar to authorize actions.</span>
          </div>
        )}
      </div>

      {/* Approvals Queue List */}
      <div className="space-y-4">
        {approvals.length === 0 ? (
          <div className="bg-slate-900 border border-slate-800 rounded-xl p-8 text-center text-slate-400">
            <CheckCircle2 className="w-8 h-8 text-emerald-400 mx-auto mb-2" />
            <p className="text-sm font-semibold text-slate-200">No Actions Awaiting Decision</p>
            <p className="text-xs text-slate-400 mt-1">
              All proposed external recovery steps have been resolved or authorized.
            </p>
          </div>
        ) : (
          approvals.map((appr) => {
            const isPending = appr.status === 'AWAITING_APPROVAL' || appr.status === 'PROPOSED';
            const isExecuting = executingId === appr.id || appr.status === 'EXECUTING';

            return (
              <div
                key={appr.id}
                className={`bg-slate-900 border rounded-xl p-5 shadow-lg space-y-4 transition-all ${
                  isPending
                    ? 'border-indigo-900/80 hover:border-indigo-700'
                    : appr.status === 'SUCCEEDED'
                    ? 'border-emerald-900/60 bg-slate-900/80'
                    : 'border-slate-800 opacity-90'
                }`}
              >
                {/* Top Status & Type */}
                <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2 border-b border-slate-800/80 pb-3">
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-mono font-bold px-2 py-0.5 rounded bg-indigo-950 text-indigo-300 border border-indigo-800">
                      {appr.actionType}
                    </span>
                    <span className="text-xs text-slate-400 font-mono">ID: {appr.id}</span>
                  </div>

                  <div className="flex items-center gap-2">
                    <span
                      className={`text-xs font-mono font-bold px-2.5 py-0.5 rounded border ${
                        appr.status === 'SUCCEEDED'
                          ? 'bg-emerald-950 text-emerald-300 border-emerald-800'
                          : appr.status === 'REJECTED'
                          ? 'bg-rose-950 text-rose-300 border-rose-800'
                          : appr.status === 'CHANGES_REQUESTED'
                          ? 'bg-amber-950 text-amber-300 border-amber-800'
                          : appr.status === 'EXECUTING'
                          ? 'bg-cyan-950 text-cyan-300 border-cyan-800 animate-pulse'
                          : 'bg-indigo-950 text-indigo-300 border-indigo-800'
                      }`}
                    >
                      {appr.status}
                    </span>
                  </div>
                </div>

                {/* Details */}
                <div className="space-y-2 text-xs">
                  <h3 className="text-sm font-bold text-slate-100">{appr.title}</h3>
                  <p className="text-slate-300 leading-relaxed">{appr.description}</p>

                  <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3 p-3 rounded-lg bg-slate-950 border border-slate-800 text-[11px] text-slate-400 font-mono">
                    <div>
                      <span className="text-slate-500 block">Intended Target:</span>
                      <span className="text-slate-200 font-semibold truncate block">
                        {appr.targetRecipient || 'Internal Service Broker'}
                      </span>
                    </div>
                    <div>
                      <span className="text-slate-500 block">Requested By:</span>
                      <span className="text-slate-200 block">{appr.requestedBy}</span>
                    </div>
                    <div>
                      <span className="text-slate-500 block">Idempotency Guard:</span>
                      <span className="text-indigo-400 block truncate">{appr.idempotencyKey || 'Protected'}</span>
                    </div>
                  </div>

                  {appr.payload && (
                    <div className="p-2.5 rounded bg-slate-950/70 border border-slate-800 text-[11px] font-mono text-slate-400 overflow-x-auto">
                      <span className="text-slate-500 block mb-1">Payload Envelope:</span>
                      <code>{JSON.stringify(appr.payload, null, 2)}</code>
                    </div>
                  )}

                  {/* Execution result / simulation badge */}
                  {appr.executionResult && (
                    <div className="p-3 rounded-lg bg-slate-950 border border-emerald-900 text-xs">
                      <div className="flex items-center gap-1.5 text-emerald-400 font-semibold mb-1">
                        <CheckCircle2 className="w-4 h-4" />
                        <span>Execution Record ({appr.isSimulated !== false ? 'Simulated Adapter' : 'Real Adapter'})</span>
                      </div>
                      <p className="text-slate-300">{appr.executionResult}</p>
                      <div className="text-[10px] text-slate-500 mt-1 flex items-center gap-3">
                        <span>Decided by: {appr.decidedBy || 'Coordinator'}</span>
                        {appr.decidedAt && <span>Timestamp: {new Date(appr.decidedAt).toLocaleString()}</span>}
                      </div>
                    </div>
                  )}

                  {resultMessage && resultMessage.id === appr.id && (
                    <div
                      className={`p-2.5 rounded text-xs flex items-center gap-2 ${
                        resultMessage.isError
                          ? 'bg-rose-950 text-rose-300 border border-rose-800'
                          : 'bg-emerald-950 text-emerald-300 border border-emerald-800'
                      }`}
                    >
                      <span>{resultMessage.msg}</span>
                    </div>
                  )}
                </div>

                {/* Actions Bar */}
                {isPending && (
                  <div className="flex flex-wrap items-center justify-end gap-2.5 pt-3 border-t border-slate-800">
                    <button
                      disabled={isViewer}
                      onClick={() => setRejectingApprovalId(appr.id)}
                      className="px-3 py-1.5 rounded bg-slate-800 hover:bg-rose-950 hover:text-rose-300 text-slate-300 text-xs font-medium border border-slate-700 transition-colors disabled:opacity-40 cursor-pointer flex items-center gap-1.5"
                    >
                      <X className="w-3.5 h-3.5" />
                      <span>Reject</span>
                    </button>

                    <button
                      disabled={isViewer}
                      onClick={() => setChangesApprovalId(appr.id)}
                      className="px-3 py-1.5 rounded bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-medium border border-slate-700 transition-colors disabled:opacity-40 cursor-pointer flex items-center gap-1.5"
                    >
                      <MessageSquare className="w-3.5 h-3.5" />
                      <span>Request Modifications</span>
                    </button>

                    <button
                      disabled={isViewer || isExecuting}
                      onClick={() => handleApprove(appr)}
                      className="px-4 py-1.5 rounded bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50 text-white text-xs font-semibold shadow-sm transition-colors cursor-pointer flex items-center gap-1.5"
                    >
                      <Check className="w-3.5 h-3.5" />
                      <span>{isExecuting ? 'Dispatching...' : 'Authorize & Execute'}</span>
                    </button>
                  </div>
                )}
              </div>
            );
          })
        )}
      </div>

      {/* Reject Reason Modal */}
      {rejectingApprovalId && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4">
          <form onSubmit={handleConfirmReject} className="bg-slate-900 border border-slate-700 rounded-xl p-5 max-w-md w-full shadow-2xl space-y-4">
            <h3 className="text-sm font-semibold text-slate-100 flex items-center gap-2">
              <XCircle className="w-4 h-4 text-rose-400" />
              <span>Reject Action Proposal</span>
            </h3>
            <p className="text-xs text-slate-400">
              Provide formal rationale for rejecting this action. An audit record will be preserved.
            </p>
            <textarea
              rows={3}
              required
              value={rejectReason}
              onChange={(e) => setRejectReason(e.target.value)}
              placeholder="e.g., Budget ceiling exceeded; alternative domestic stock should be prioritized..."
              className="w-full bg-slate-950 border border-slate-700 rounded p-2.5 text-xs text-slate-200 placeholder-slate-500 focus:outline-none focus:border-rose-500"
            />
            <div className="flex justify-end gap-2">
              <button
                type="button"
                onClick={() => setRejectingApprovalId(null)}
                className="px-3 py-1.5 text-xs text-slate-400 hover:text-slate-200 cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-4 py-1.5 bg-rose-600 hover:bg-rose-500 text-white rounded text-xs font-medium cursor-pointer"
              >
                Confirm Rejection
              </button>
            </div>
          </form>
        </div>
      )}

      {/* Request Modifications Modal */}
      {changesApprovalId && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4">
          <form onSubmit={handleConfirmChanges} className="bg-slate-900 border border-slate-700 rounded-xl p-5 max-w-md w-full shadow-2xl space-y-4">
            <h3 className="text-sm font-semibold text-slate-100 flex items-center gap-2">
              <MessageSquare className="w-4 h-4 text-amber-400" />
              <span>Request Action Modifications</span>
            </h3>
            <p className="text-xs text-slate-400">
              Specify what terms, quantities, or recipients need to be modified before authorization.
            </p>
            <textarea
              rows={3}
              required
              value={changesNote}
              onChange={(e) => setChangesNote(e.target.value)}
              placeholder="e.g., Adjust shipment quantity to 150 units instead of 200..."
              className="w-full bg-slate-950 border border-slate-700 rounded p-2.5 text-xs text-slate-200 placeholder-slate-500 focus:outline-none focus:border-amber-500"
            />
            <div className="flex justify-end gap-2">
              <button
                type="button"
                onClick={() => setChangesApprovalId(null)}
                className="px-3 py-1.5 text-xs text-slate-400 hover:text-slate-200 cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-4 py-1.5 bg-amber-600 hover:bg-amber-500 text-white rounded text-xs font-medium cursor-pointer"
              >
                Send Request
              </button>
            </div>
          </form>
        </div>
      )}
    </div>
  );
};
