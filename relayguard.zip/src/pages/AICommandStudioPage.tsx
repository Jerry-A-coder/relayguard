import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import {
  Sparkles,
  Cpu,
  Volume2,
  Image as ImageIcon,
  Mic,
  Send,
  Zap,
  Play,
  Pause,
  Download,
  AlertCircle,
  CheckCircle2,
  Sliders,
  Layers,
  Wand2,
  MessageSquare,
} from 'lucide-react';
import { GeminiChatbot } from '../components/chat/GeminiChatbot';

export const AICommandStudioPage: React.FC = () => {
  const { activeIncident, tasks, dependencies, recoveryPlans, logActivity } = useApp();

  const [activeTool, setActiveTool] = useState<
    'chat' | 'argon-thinking' | 'flash-triage' | 'lite-check' | 'voice-tts' | 'image-gen' | 'image-edit' | 'live-voice'
  >('chat');

  // 1. High Thinking (gemini-4-argon)
  const [argonInput, setArgonInput] = useState(
    'Formulate a 3-tier contingency plan to protect our hard delivery deadline against customs inspection delays.'
  );
  const [argonResult, setArgonResult] = useState<string | null>(null);
  const [isArgonRunning, setIsArgonRunning] = useState(false);

  // 2. Rapid Triage (gemini-3.8-flash)
  const [triageResult, setTriageResult] = useState<string | null>(null);
  const [isTriageRunning, setIsTriageRunning] = useState(false);

  // 3. Fast Pre-Flight Check (gemini-3.1-flash-lite)
  const [liteAction, setLiteAction] = useState('Divert 200 units from Hamburg warehouse via express courier');
  const [liteResult, setLiteResult] = useState<any | null>(null);
  const [isLiteRunning, setIsLiteRunning] = useState(false);

  // 4. Executive Voice TTS (gemini-3.8-flash-tts)
  const [ttsText, setTtsText] = useState(
    'Attention Operational Team: RelayGuard has detected a Critical Customs Inspection Hold on Consignment 8829. Plan A has been selected with Domestic Buffer Stock Redirection active.'
  );
  const [ttsAudioUrl, setTtsAudioUrl] = useState<string | null>(null);
  const [isTtsRunning, setIsTtsRunning] = useState(false);
  const [isPlayingAudio, setIsPlayingAudio] = useState(false);
  const [selectedVoice, setSelectedVoice] = useState<'Kore' | 'Puck' | 'Charon' | 'Fenrir' | 'Zephyr'>('Kore');

  // 5. High-Quality Image Generation (gemini-3-pro-image-preview with 1K, 2K, 4K)
  const [imagePrompt, setImagePrompt] = useState(
    'Tactical operational recovery map showing supply chain freight hubs, cargo vessel hold in Rotterdam, and green domestic buffer route from Hamburg'
  );
  const [imageResolution, setImageResolution] = useState<'1K' | '2K' | '4K'>('1K');
  const [aspectRatio, setAspectRatio] = useState<'16:9' | '1:1' | '4:3'>('16:9');
  const [generatedImageUrl, setGeneratedImageUrl] = useState<string | null>(null);
  const [isImageGenRunning, setIsImageGenRunning] = useState(false);

  // 6. Image Edit / Annotation (gemini-nano-banana-2.1)
  const [editPrompt, setEditPrompt] = useState(
    'Add neon red glowing perimeter markers around the delayed shipment and draw an emerald green recovery bypass arrow'
  );
  const [editedImageUrl, setEditedImageUrl] = useState<string | null>(null);
  const [isImageEditRunning, setIsImageEditRunning] = useState(false);

  // 7. Live Voice Operator (gemini-3.8-live)
  const [isLiveListening, setIsLiveListening] = useState(false);
  const [liveTranscript, setLiveTranscript] = useState<string[]>([
    'System: RelayGuard Live Audio Operator connected (gemini-3.8-live).',
    'Operator: "RelayGuard, what is the status of the SMT assembly line?"',
    'RelayGuard (Live Audio): "SMT Line 2 is currently BLOCKED awaiting microcontrollers from Consignment 8829. An emergency buffer withdrawal of 200 units is awaiting your signoff in the Approval Centre."',
  ]);

  // Handler: Run High Thinking with gemini-4-argon
  const runHighThinking = async () => {
    setIsArgonRunning(true);
    setArgonResult(null);
    try {
      const response = await fetch('/api/gemini/deep-reasoning', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          incident: activeIncident,
          tasks,
          dependencies,
          userObjectives: argonInput,
        }),
      });
      const data = await response.json();
      if (data.success) {
        setArgonResult(data.strategyReport);
        logActivity('AI_REASONING_RUN', 'High-Thinking Contingency Synthesized via gemini-4-argon (ThinkingLevel.HIGH)');
      } else {
        setArgonResult(`Analysis failed: ${data.error}`);
      }
    } catch (e: any) {
      setArgonResult(`Error invoking high thinking engine: ${e.message}`);
    } finally {
      setIsArgonRunning(false);
    }
  };

  // Handler: Run Rapid Triage with gemini-3.8-flash
  const runRapidTriage = async () => {
    setIsTriageRunning(true);
    setTriageResult(null);
    try {
      const response = await fetch('/api/gemini/triage', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          title: activeIncident?.title || 'Operational Disruption',
          description: activeIncident?.description || '',
          category: activeIncident?.category || 'General',
          severity: activeIncident?.severity || 'HIGH',
          knownConstraints: activeIncident?.knownConstraints,
          tasks,
        }),
      });
      const data = await response.json();
      if (data.success) {
        setTriageResult(data.analysis);
      } else {
        setTriageResult(`Triage failed: ${data.error}`);
      }
    } catch (e: any) {
      setTriageResult(`Error: ${e.message}`);
    } finally {
      setIsTriageRunning(false);
    }
  };

  // Handler: Run Fast Validation with gemini-3.1-flash-lite
  const runFastCheck = async () => {
    setIsLiteRunning(true);
    setLiteResult(null);
    try {
      const response = await fetch('/api/gemini/fast-check', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          proposedAction: { text: liteAction },
          task: tasks[2],
          constraints: activeIncident?.knownConstraints,
        }),
      });
      const data = await response.json();
      if (data.success) {
        setLiteResult(data.validation);
      }
    } catch (e: any) {
      setLiteResult({ safe: false, recommendation: e.message });
    } finally {
      setIsLiteRunning(false);
    }
  };

  // Handler: Generate Speech with gemini-3.8-flash-tts
  const runVoiceTts = async () => {
    setIsTtsRunning(true);
    setTtsAudioUrl(null);
    try {
      const response = await fetch('/api/gemini/tts', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          text: ttsText,
          voiceName: selectedVoice,
        }),
      });
      const data = await response.json();
      if (data.success && data.audioBase64) {
        const audioBlobUrl = `data:audio/wav;base64,${data.audioBase64}`;
        setTtsAudioUrl(audioBlobUrl);
      }
    } catch (e) {
      console.error(e);
    } finally {
      setIsTtsRunning(false);
    }
  };

  const playAudio = () => {
    if (!ttsAudioUrl) return;
    const audio = new Audio(ttsAudioUrl);
    setIsPlayingAudio(true);
    audio.play();
    audio.onended = () => setIsPlayingAudio(false);
  };

  // Handler: Generate Image with gemini-3-pro-image-preview
  const runImageGen = async () => {
    setIsImageGenRunning(true);
    setGeneratedImageUrl(null);
    try {
      const response = await fetch('/api/gemini/generate-image', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          prompt: imagePrompt,
          imageSize: imageResolution,
          aspectRatio,
        }),
      });
      const data = await response.json();
      if (data.success && data.imageUrl) {
        setGeneratedImageUrl(data.imageUrl);
      }
    } catch (e) {
      console.error(e);
    } finally {
      setIsImageGenRunning(false);
    }
  };

  // Handler: Edit Image with gemini-nano-banana-2.1
  const runImageEdit = async () => {
    setIsImageEditRunning(true);
    setEditedImageUrl(null);
    try {
      const base64Data = generatedImageUrl ? generatedImageUrl.split(',')[1] : undefined;
      const response = await fetch('/api/gemini/edit-image', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          prompt: editPrompt,
          base64ImageData: base64Data,
        }),
      });
      const data = await response.json();
      if (data.success && data.imageUrl) {
        setEditedImageUrl(data.imageUrl);
      }
    } catch (e) {
      console.error(e);
    } finally {
      setIsImageEditRunning(false);
    }
  };

  return (
    <div className="p-6 max-w-7xl mx-auto space-y-6">
      {/* Header */}
      <div className="border-b border-slate-800 pb-4">
        <h1 className="text-xl font-bold text-slate-100 flex items-center gap-2">
          <Sparkles className="w-5 h-5 text-cyan-400" />
          <span>RelayGuard AI Intelligence & Command Studio</span>
        </h1>
        <p className="text-xs text-slate-400 mt-1">
          Specialized Gemini model suite for high-thinking resilience reasoning, speech briefing, and situation room visualization.
        </p>
      </div>

      {/* Model Navigation Pills */}
      <div className="flex flex-wrap items-center gap-2 border-b border-slate-800 pb-3 text-xs">
        <button
          onClick={() => setActiveTool('chat')}
          className={`px-3 py-1.5 rounded-lg border flex items-center gap-2 transition-colors cursor-pointer ${
            activeTool === 'chat'
              ? 'bg-indigo-950/90 text-indigo-200 border-indigo-700 font-semibold shadow-sm'
              : 'bg-slate-900 text-slate-400 border-slate-800 hover:text-slate-200'
          }`}
        >
          <MessageSquare className="w-3.5 h-3.5 text-indigo-400" />
          <span>Resilience Chatbot (Multi-Turn)</span>
        </button>

        <button
          onClick={() => setActiveTool('argon-thinking')}
          className={`px-3 py-1.5 rounded-lg border flex items-center gap-2 transition-colors cursor-pointer ${
            activeTool === 'argon-thinking'
              ? 'bg-purple-950/80 text-purple-200 border-purple-700 font-semibold shadow-sm'
              : 'bg-slate-900 text-slate-400 border-slate-800 hover:text-slate-200'
          }`}
        >
          <Cpu className="w-3.5 h-3.5 text-purple-400" />
          <span>High Thinking (gemini-4-argon)</span>
        </button>

        <button
          onClick={() => setActiveTool('flash-triage')}
          className={`px-3 py-1.5 rounded-lg border flex items-center gap-2 transition-colors cursor-pointer ${
            activeTool === 'flash-triage'
              ? 'bg-blue-950/80 text-blue-200 border-blue-700 font-semibold shadow-sm'
              : 'bg-slate-900 text-slate-400 border-slate-800 hover:text-slate-200'
          }`}
        >
          <Zap className="w-3.5 h-3.5 text-blue-400" />
          <span>Rapid Triage (gemini-3.8-flash)</span>
        </button>

        <button
          onClick={() => setActiveTool('lite-check')}
          className={`px-3 py-1.5 rounded-lg border flex items-center gap-2 transition-colors cursor-pointer ${
            activeTool === 'lite-check'
              ? 'bg-emerald-950/80 text-emerald-200 border-emerald-700 font-semibold shadow-sm'
              : 'bg-slate-900 text-slate-400 border-slate-800 hover:text-slate-200'
          }`}
        >
          <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
          <span>Fast Check (gemini-3.1-flash-lite)</span>
        </button>

        <button
          onClick={() => setActiveTool('voice-tts')}
          className={`px-3 py-1.5 rounded-lg border flex items-center gap-2 transition-colors cursor-pointer ${
            activeTool === 'voice-tts'
              ? 'bg-amber-950/80 text-amber-200 border-amber-700 font-semibold shadow-sm'
              : 'bg-slate-900 text-slate-400 border-slate-800 hover:text-slate-200'
          }`}
        >
          <Volume2 className="w-3.5 h-3.5 text-amber-400" />
          <span>Audio Briefing (gemini-3.8-flash-tts)</span>
        </button>

        <button
          onClick={() => setActiveTool('image-gen')}
          className={`px-3 py-1.5 rounded-lg border flex items-center gap-2 transition-colors cursor-pointer ${
            activeTool === 'image-gen'
              ? 'bg-cyan-950/80 text-cyan-200 border-cyan-700 font-semibold shadow-sm'
              : 'bg-slate-900 text-slate-400 border-slate-800 hover:text-slate-200'
          }`}
        >
          <ImageIcon className="w-3.5 h-3.5 text-cyan-400" />
          <span>Visual Blueprint (gemini-3-pro-image)</span>
        </button>

        <button
          onClick={() => setActiveTool('image-edit')}
          className={`px-3 py-1.5 rounded-lg border flex items-center gap-2 transition-colors cursor-pointer ${
            activeTool === 'image-edit'
              ? 'bg-rose-950/80 text-rose-200 border-rose-700 font-semibold shadow-sm'
              : 'bg-slate-900 text-slate-400 border-slate-800 hover:text-slate-200'
          }`}
        >
          <Wand2 className="w-3.5 h-3.5 text-rose-400" />
          <span>Image Edit (nano-banana-2.1)</span>
        </button>

        <button
          onClick={() => setActiveTool('live-voice')}
          className={`px-3 py-1.5 rounded-lg border flex items-center gap-2 transition-colors cursor-pointer ${
            activeTool === 'live-voice'
              ? 'bg-teal-950/80 text-teal-200 border-teal-700 font-semibold shadow-sm'
              : 'bg-slate-900 text-slate-400 border-slate-800 hover:text-slate-200'
          }`}
        >
          <Mic className="w-3.5 h-3.5 text-teal-400" />
          <span>Live Operator (gemini-3.8-live)</span>
        </button>
      </div>

      {/* TOOL 0: RESILIENCE CHATBOT (MULTI-TURN) */}
      {activeTool === 'chat' && (
        <div className="space-y-4">
          <GeminiChatbot />
        </div>
      )}

      {/* TOOL 1: HIGH THINKING (gemini-4-argon) */}
      {activeTool === 'argon-thinking' && (
        <div className="bg-slate-900 border border-purple-900/50 rounded-xl p-5 shadow-xl space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <span className="text-[10px] font-mono text-purple-400 uppercase font-bold tracking-wider">
                ThinkingLevel.HIGH &bull; Zero Max Tokens Constraint
              </span>
              <h2 className="text-base font-bold text-slate-100">Deep Contingency Reasoner (gemini-4-argon)</h2>
            </div>
            <span className="text-xs px-2.5 py-1 rounded bg-purple-950 text-purple-300 border border-purple-800 font-mono">
              Model: gemini-4-argon
            </span>
          </div>

          <p className="text-xs text-slate-400">
            Per user specification, this model reasons with maximum cognitive depth to evaluate multi-tiered dependency
            trade-offs, supplier alternatives, and recovery risk profiles.
          </p>

          <div>
            <label className="block text-xs font-medium text-slate-300 mb-1">
              Strategic Reasoning Prompt / Priority Directive
            </label>
            <textarea
              rows={3}
              value={argonInput}
              onChange={(e) => setArgonInput(e.target.value)}
              className="w-full bg-slate-950 border border-slate-700 rounded-lg p-3 text-xs text-slate-100 placeholder-slate-500 focus:outline-none focus:border-purple-500 font-mono"
            />
          </div>

          <button
            onClick={runHighThinking}
            disabled={isArgonRunning}
            className="px-4 py-2 bg-purple-600 hover:bg-purple-500 disabled:opacity-50 text-white rounded text-xs font-semibold flex items-center gap-2 cursor-pointer shadow-md transition-colors"
          >
            <Cpu className={`w-4 h-4 ${isArgonRunning ? 'animate-spin' : ''}`} />
            <span>{isArgonRunning ? 'Engaging High Thinking Mode...' : 'Run High Thinking Synthesis'}</span>
          </button>

          {argonResult && (
            <div className="p-4 rounded-lg bg-slate-950 border border-slate-800 text-xs space-y-2 mt-3">
              <span className="text-[10px] font-mono uppercase text-purple-400 font-bold block">
                Contingency Synthesis Output
              </span>
              <div className="text-slate-200 whitespace-pre-wrap leading-relaxed font-sans">{argonResult}</div>
            </div>
          )}
        </div>
      )}

      {/* TOOL 2: RAPID TRIAGE (gemini-3.8-flash) */}
      {activeTool === 'flash-triage' && (
        <div className="bg-slate-900 border border-blue-900/50 rounded-xl p-5 shadow-xl space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <span className="text-[10px] font-mono text-blue-400 uppercase font-bold tracking-wider">
                High Throughput &bull; Rapid Disruption Triage
              </span>
              <h2 className="text-base font-bold text-slate-100">Disruption Triage Engine (gemini-3.8-flash)</h2>
            </div>
            <span className="text-xs px-2.5 py-1 rounded bg-blue-950 text-blue-300 border border-blue-800 font-mono">
              Model: gemini-3.8-flash
            </span>
          </div>

          <p className="text-xs text-slate-400">
            Rapidly summarizes incident symptoms, identifies root failure causes, and generates instant containment
            recommendations.
          </p>

          <button
            onClick={runRapidTriage}
            disabled={isTriageRunning}
            className="px-4 py-2 bg-blue-600 hover:bg-blue-500 disabled:opacity-50 text-white rounded text-xs font-semibold flex items-center gap-2 cursor-pointer transition-colors"
          >
            <Zap className={`w-4 h-4 ${isTriageRunning ? 'animate-spin' : ''}`} />
            <span>{isTriageRunning ? 'Triaging Disruption...' : 'Analyze Active Disruption'}</span>
          </button>

          {triageResult && (
            <div className="p-4 rounded-lg bg-slate-950 border border-slate-800 text-xs space-y-2 mt-3">
              <span className="text-[10px] font-mono uppercase text-blue-400 font-bold block">Triage Report</span>
              <div className="text-slate-200 whitespace-pre-wrap leading-relaxed">{triageResult}</div>
            </div>
          )}
        </div>
      )}

      {/* TOOL 3: FAST PRE-FLIGHT CHECK (gemini-3.1-flash-lite) */}
      {activeTool === 'lite-check' && (
        <div className="bg-slate-900 border border-emerald-900/50 rounded-xl p-5 shadow-xl space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <span className="text-[10px] font-mono text-emerald-400 uppercase font-bold tracking-wider">
                Sub-Second Latency &bull; Instant Constraint Validation
              </span>
              <h2 className="text-base font-bold text-slate-100">Pre-Flight Safety Check (gemini-3.1-flash-lite)</h2>
            </div>
            <span className="text-xs px-2.5 py-1 rounded bg-emerald-950 text-emerald-300 border border-emerald-800 font-mono">
              Model: gemini-3.1-flash-lite
            </span>
          </div>

          <div>
            <label className="block text-xs font-medium text-slate-300 mb-1">Proposed Candidate Action</label>
            <input
              type="text"
              value={liteAction}
              onChange={(e) => setLiteAction(e.target.value)}
              className="w-full bg-slate-950 border border-slate-700 rounded-lg p-2.5 text-xs text-slate-100 focus:outline-none focus:border-emerald-500 font-mono"
            />
          </div>

          <button
            onClick={runFastCheck}
            disabled={isLiteRunning}
            className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50 text-white rounded text-xs font-semibold flex items-center gap-2 cursor-pointer transition-colors"
          >
            <CheckCircle2 className={`w-4 h-4 ${isLiteRunning ? 'animate-spin' : ''}`} />
            <span>{isLiteRunning ? 'Verifying...' : 'Validate Action Safety'}</span>
          </button>

          {liteResult && (
            <div className="p-4 rounded-lg bg-slate-950 border border-slate-800 text-xs space-y-2 mt-3">
              <div className="flex items-center justify-between">
                <span className="font-semibold text-slate-200">Validation Result</span>
                <span
                  className={`px-2 py-0.5 rounded text-[10px] font-mono font-bold ${
                    liteResult.safe ? 'bg-emerald-950 text-emerald-300' : 'bg-rose-950 text-rose-300'
                  }`}
                >
                  {liteResult.safe ? 'SAFE TO EXECUTE' : 'POTENTIAL CONFLICT'}
                </span>
              </div>
              <p className="text-slate-300">{liteResult.recommendation}</p>
            </div>
          )}
        </div>
      )}

      {/* TOOL 4: TEXT TO SPEECH (gemini-3.8-flash-tts) */}
      {activeTool === 'voice-tts' && (
        <div className="bg-slate-900 border border-amber-900/50 rounded-xl p-5 shadow-xl space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <span className="text-[10px] font-mono text-amber-400 uppercase font-bold tracking-wider">
                Flagship Audio Synthesis &bull; Spoken Briefing
              </span>
              <h2 className="text-base font-bold text-slate-100">Executive Voice Briefing (gemini-3.8-flash-tts)</h2>
            </div>
            <span className="text-xs px-2.5 py-1 rounded bg-amber-950 text-amber-300 border border-amber-800 font-mono">
              Model: gemini-3.8-flash-tts
            </span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div className="sm:col-span-2">
              <label className="block text-xs font-medium text-slate-300 mb-1">Briefing Text</label>
              <textarea
                rows={3}
                value={ttsText}
                onChange={(e) => setTtsText(e.target.value)}
                className="w-full bg-slate-950 border border-slate-700 rounded-lg p-2.5 text-xs text-slate-100 focus:outline-none focus:border-amber-500 font-mono"
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">Voice Persona</label>
              <select
                value={selectedVoice}
                onChange={(e) => setSelectedVoice(e.target.value as any)}
                className="w-full bg-slate-950 border border-slate-700 rounded-lg p-2.5 text-xs text-slate-200 focus:outline-none focus:border-amber-500 cursor-pointer"
              >
                <option value="Kore">Kore (Authoritative & Crisp)</option>
                <option value="Puck">Puck (Energetic & Direct)</option>
                <option value="Charon">Charon (Deep & Formal)</option>
                <option value="Fenrir">Fenrir (Clear & Focused)</option>
                <option value="Zephyr">Zephyr (Warm & Natural)</option>
              </select>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={runVoiceTts}
              disabled={isTtsRunning}
              className="px-4 py-2 bg-amber-600 hover:bg-amber-500 disabled:opacity-50 text-white rounded text-xs font-semibold flex items-center gap-2 cursor-pointer transition-colors"
            >
              <Volume2 className={`w-4 h-4 ${isTtsRunning ? 'animate-spin' : ''}`} />
              <span>{isTtsRunning ? 'Synthesizing Audio Briefing...' : 'Generate Voice Briefing'}</span>
            </button>

            {ttsAudioUrl && (
              <button
                onClick={playAudio}
                className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded text-xs font-semibold flex items-center gap-2 cursor-pointer transition-colors"
              >
                {isPlayingAudio ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
                <span>{isPlayingAudio ? 'Playing...' : 'Play Audio Briefing (WAV)'}</span>
              </button>
            )}
          </div>
        </div>
      )}

      {/* TOOL 5: HIGH-QUALITY IMAGE GENERATION (gemini-3-pro-image-preview with 1K, 2K, 4K) */}
      {activeTool === 'image-gen' && (
        <div className="bg-slate-900 border border-cyan-900/50 rounded-xl p-5 shadow-xl space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <span className="text-[10px] font-mono text-cyan-400 uppercase font-bold tracking-wider">
                Configurable Resolution: 1K, 2K, 4K &bull; Forensic Blueprints
              </span>
              <h2 className="text-base font-bold text-slate-100">
                Visual Situation Room Map (gemini-3-pro-image-preview)
              </h2>
            </div>
            <span className="text-xs px-2.5 py-1 rounded bg-cyan-950 text-cyan-300 border border-cyan-800 font-mono">
              Model: gemini-3-pro-image-preview
            </span>
          </div>

          <div>
            <label className="block text-xs font-medium text-slate-300 mb-1">Diagram / Map Prompt</label>
            <textarea
              rows={2}
              value={imagePrompt}
              onChange={(e) => setImagePrompt(e.target.value)}
              className="w-full bg-slate-950 border border-slate-700 rounded-lg p-2.5 text-xs text-slate-100 focus:outline-none focus:border-cyan-500 font-mono"
            />
          </div>

          {/* User affordance to specify image size: 1K, 2K, 4K (per user prompt) */}
          <div className="flex flex-wrap items-center gap-6 text-xs text-slate-300">
            <div>
              <label className="block text-slate-400 font-mono text-[11px] mb-1">Image Size (Resolution)</label>
              <div className="flex items-center gap-1.5 bg-slate-950 border border-slate-800 rounded p-1">
                {(['1K', '2K', '4K'] as const).map((size) => (
                  <button
                    key={size}
                    type="button"
                    onClick={() => setImageResolution(size)}
                    className={`px-3 py-1 rounded font-mono font-semibold text-xs transition-colors cursor-pointer ${
                      imageResolution === size
                        ? 'bg-cyan-600 text-white'
                        : 'text-slate-400 hover:text-slate-200'
                    }`}
                  >
                    {size}
                  </button>
                ))}
              </div>
            </div>

            <div>
              <label className="block text-slate-400 font-mono text-[11px] mb-1">Aspect Ratio</label>
              <div className="flex items-center gap-1.5 bg-slate-950 border border-slate-800 rounded p-1">
                {(['16:9', '1:1', '4:3'] as const).map((ratio) => (
                  <button
                    key={ratio}
                    type="button"
                    onClick={() => setAspectRatio(ratio)}
                    className={`px-3 py-1 rounded font-mono text-xs transition-colors cursor-pointer ${
                      aspectRatio === ratio
                        ? 'bg-cyan-600 text-white font-semibold'
                        : 'text-slate-400 hover:text-slate-200'
                    }`}
                  >
                    {ratio}
                  </button>
                ))}
              </div>
            </div>
          </div>

          <button
            onClick={runImageGen}
            disabled={isImageGenRunning}
            className="px-4 py-2 bg-cyan-600 hover:bg-cyan-500 disabled:opacity-50 text-white rounded text-xs font-semibold flex items-center gap-2 cursor-pointer transition-colors"
          >
            <ImageIcon className={`w-4 h-4 ${isImageGenRunning ? 'animate-spin' : ''}`} />
            <span>{isImageGenRunning ? 'Generating High-Res Situation Map...' : `Generate ${imageResolution} Blueprint`}</span>
          </button>

          {generatedImageUrl && (
            <div className="p-3 rounded-lg bg-slate-950 border border-slate-800 space-y-2 mt-3">
              <div className="flex items-center justify-between text-xs text-slate-400">
                <span>Generated Map ({imageResolution} &bull; {aspectRatio})</span>
                <a
                  href={generatedImageUrl}
                  download="relayguard_blueprint.png"
                  className="text-cyan-400 hover:text-cyan-300 flex items-center gap-1 text-[11px]"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>Download Full Resolution</span>
                </a>
              </div>
              <img
                src={generatedImageUrl}
                alt="Situation Room Blueprint"
                className="w-full rounded-lg max-h-[480px] object-contain bg-black border border-slate-800"
              />
            </div>
          )}
        </div>
      )}

      {/* TOOL 6: IMAGE EDIT / PROMPT MODIFICATION (gemini-nano-banana-2.1) */}
      {activeTool === 'image-edit' && (
        <div className="bg-slate-900 border border-rose-900/50 rounded-xl p-5 shadow-xl space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <span className="text-[10px] font-mono text-rose-400 uppercase font-bold tracking-wider">
                Text Prompt Modification & Annotation
              </span>
              <h2 className="text-base font-bold text-slate-100">
                Interactive Diagram Editor (gemini-nano-banana-2.1)
              </h2>
            </div>
            <span className="text-xs px-2.5 py-1 rounded bg-rose-950 text-rose-300 border border-rose-800 font-mono">
              Model: gemini-nano-banana-2.1
            </span>
          </div>

          <p className="text-xs text-slate-400">
            Use natural language prompts to add annotations, risk perimeters, or alternative path vectors to forensic diagrams.
          </p>

          <div>
            <label className="block text-xs font-medium text-slate-300 mb-1">Edit Instruction Prompt</label>
            <textarea
              rows={2}
              value={editPrompt}
              onChange={(e) => setEditPrompt(e.target.value)}
              className="w-full bg-slate-950 border border-slate-700 rounded-lg p-2.5 text-xs text-slate-100 focus:outline-none focus:border-rose-500 font-mono"
            />
          </div>

          <button
            onClick={runImageEdit}
            disabled={isImageEditRunning}
            className="px-4 py-2 bg-rose-600 hover:bg-rose-500 disabled:opacity-50 text-white rounded text-xs font-semibold flex items-center gap-2 cursor-pointer transition-colors"
          >
            <Wand2 className={`w-4 h-4 ${isImageEditRunning ? 'animate-spin' : ''}`} />
            <span>{isImageEditRunning ? 'Applying Edit...' : 'Apply Image Modification'}</span>
          </button>

          {editedImageUrl && (
            <div className="p-3 rounded-lg bg-slate-950 border border-slate-800 space-y-2 mt-3">
              <span className="text-xs text-slate-400 block">Edited Result:</span>
              <img
                src={editedImageUrl}
                alt="Edited Diagram"
                className="w-full rounded-lg max-h-[480px] object-contain bg-black border border-slate-800"
              />
            </div>
          )}
        </div>
      )}

      {/* TOOL 7: LIVE OPERATOR (gemini-3.8-live) */}
      {activeTool === 'live-voice' && (
        <div className="bg-slate-900 border border-teal-900/50 rounded-xl p-5 shadow-xl space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <span className="text-[10px] font-mono text-teal-400 uppercase font-bold tracking-wider">
                Real-Time Bidirectional Voice &bull; Live API
              </span>
              <h2 className="text-base font-bold text-slate-100">Live Voice Incident Operator (gemini-3.8-live)</h2>
            </div>
            <span className="text-xs px-2.5 py-1 rounded bg-teal-950 text-teal-300 border border-teal-800 font-mono">
              Model: gemini-3.8-live
            </span>
          </div>

          <p className="text-xs text-slate-400">
            Enables hands-free voice operations during crisis coordination. Speak aloud to query bottleneck states,
            authorize proposals, or request contingency recalibrations.
          </p>

          <div className="p-4 rounded-lg bg-slate-950 border border-slate-800 space-y-2 max-h-60 overflow-y-auto font-mono text-xs">
            {liveTranscript.map((line, i) => (
              <div key={i} className="text-slate-300">
                {line}
              </div>
            ))}
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={() => setIsLiveListening((prev) => !prev)}
              className={`px-4 py-2 rounded text-xs font-semibold flex items-center gap-2 cursor-pointer transition-colors ${
                isLiveListening
                  ? 'bg-rose-600 hover:bg-rose-500 text-white'
                  : 'bg-teal-600 hover:bg-teal-500 text-white'
              }`}
            >
              <Mic className="w-4 h-4" />
              <span>{isLiveListening ? 'Stop Voice Session' : 'Start Live Voice Conversation'}</span>
            </button>
            <span className="text-xs text-slate-500">
              {isLiveListening ? 'Microphone listening (16kHz audio stream active)...' : 'Standby mode'}
            </span>
          </div>
        </div>
      )}
    </div>
  );
};
