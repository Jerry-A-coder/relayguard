import React from 'react';
import { useApp } from '../context/AppContext';
import { Cpu, Database, Sparkles, Mail, Calendar, ShieldCheck, CheckCircle2, AlertCircle, Terminal } from 'lucide-react';
import firebaseConfig from '../../firebase-applet-config.json';

export const IntegrationsPage: React.FC = () => {
  const { isFirebaseConnected } = useApp();

  const mcpTools = [
    { name: 'get_incident', desc: 'Retrieve full incident dossier, severity, and verification status by incident_id.' },
    { name: 'list_affected_tasks', desc: 'Execute graph traversal and return all downstream blocked tasks.' },
    { name: 'analyse_disruption_impact', desc: 'Run deterministic topological analysis and cycle detection.' },
    { name: 'get_dependency_graph', desc: 'Fetch directed graph nodes and edges for spatial or 2D rendering.' },
    { name: 'generate_recovery_plans', desc: 'Formulate 3 feasible recovery pathways with trade-offs.' },
    { name: 'compare_recovery_plans', desc: 'Evaluate plan feasibility scores, duration, and required approvals.' },
    { name: 'create_action_proposal', desc: 'Submit a proposed consequential action to the Approval Centre.' },
    { name: 'get_pending_approvals', desc: 'Fetch the active queue of actions awaiting human authorization.' },
    { name: 'record_new_evidence', desc: 'Append verified external documents or courier tracking numbers.' },
    { name: 'request_replanning', desc: 'Trigger recalculation when conditions or constraints change.' },
  ];

  return (
    <div className="p-6 max-w-6xl mx-auto space-y-6">
      {/* Header */}
      <div className="border-b border-slate-800 pb-4">
        <h1 className="text-xl font-bold text-slate-100 flex items-center gap-2">
          <Cpu className="w-5 h-5 text-indigo-400" />
          <span>System Integrations & MCP Protocol</span>
        </h1>
        <p className="text-xs text-slate-400 mt-1">
          Self-hosted Model Context Protocol (MCP) server, Firebase database persistence, and Google GenAI adapters.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
        {/* Card 1: MCP Server */}
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-lg space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Terminal className="w-4 h-4 text-cyan-400" />
              <h3 className="text-sm font-bold text-slate-100">Model Context Protocol (MCP) Server</h3>
            </div>
            <span className="px-2 py-0.5 rounded text-[10px] font-mono bg-emerald-950 text-emerald-300 border border-emerald-800">
              STREAMABLE HTTP
            </span>
          </div>

          <p className="text-xs text-slate-400">
            Self-hosted MCP server implementation exposing deterministic recovery engine primitives to AI agents and the Alexa+ track.
          </p>

          <div className="p-3 rounded-lg bg-slate-950 border border-slate-800 space-y-1.5 text-xs">
            <div className="flex justify-between text-[11px] font-mono text-slate-400">
              <span>Transport Protocol:</span>
              <span className="text-cyan-400">Streamable HTTP (JSON-RPC 2.0)</span>
            </div>
            <div className="flex justify-between text-[11px] font-mono text-slate-400">
              <span>Auth & Scope:</span>
              <span className="text-slate-200">Bearer Token / Workspace-Scoped</span>
            </div>
            <div className="flex justify-between text-[11px] font-mono text-slate-400">
              <span>Tools Implemented:</span>
              <span className="text-emerald-400 font-bold">{mcpTools.length} Tools</span>
            </div>
          </div>

          <div className="space-y-1.5 pt-2">
            <span className="text-[10px] font-mono uppercase text-slate-500 font-bold block">Exposed MCP Tools:</span>
            <div className="max-h-48 overflow-y-auto space-y-1 pr-1">
              {mcpTools.map((t) => (
                <div key={t.name} className="p-2 rounded bg-slate-950 border border-slate-800/80 text-[11px]">
                  <span className="font-mono text-indigo-400 font-semibold block">{t.name}</span>
                  <span className="text-slate-400 text-[10px]">{t.desc}</span>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Card 2: Firebase Firestore & Auth */}
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-lg space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Database className="w-4 h-4 text-amber-400" />
              <h3 className="text-sm font-bold text-slate-100">Firebase Firestore & Google Auth</h3>
            </div>
            <span
              className={`px-2 py-0.5 rounded text-[10px] font-mono border ${
                isFirebaseConnected
                  ? 'bg-emerald-950 text-emerald-300 border-emerald-800'
                  : 'bg-amber-950 text-amber-300 border-amber-800'
              }`}
            >
              {isFirebaseConnected ? 'CONNECTED' : 'ACTIVE / LOCAL SYNC'}
            </span>
          </div>

          <p className="text-xs text-slate-400">
            Persistent cloud database configured with intermediate blueprint specification (<code className="text-indigo-300">firebase-blueprint.json</code>) and zero-trust ABAC security rules.
          </p>

          <div className="p-3 rounded-lg bg-slate-950 border border-slate-800 space-y-1.5 text-xs font-mono text-slate-400">
            <div className="flex justify-between text-[11px]">
              <span>Project ID:</span>
              <span className="text-slate-200">{firebaseConfig.projectId || 'sunny-wave-cxctm'}</span>
            </div>
            <div className="flex justify-between text-[11px]">
              <span>Database ID:</span>
              <span className="text-indigo-400">{firebaseConfig.firestoreDatabaseId || 'default'}</span>
            </div>
            <div className="flex justify-between text-[11px]">
              <span>Security Rules:</span>
              <span className="text-emerald-400">Deployed (Rules v2 Hardened)</span>
            </div>
            <div className="flex justify-between text-[11px]">
              <span>Auth Provider:</span>
              <span className="text-slate-200">Google Sign-In (Popup)</span>
            </div>
          </div>

          <div className="p-3 rounded-lg bg-slate-950/70 border border-slate-800 text-[11px] text-slate-400">
            <strong className="text-slate-300 block mb-1">Pillars of Hardened Rules Enforced:</strong>
            Catch-all default-deny, document ID regex validation, immutable timestamps via <code className="text-indigo-300">request.time</code>, and append-only activity audit logging.
          </div>
        </div>

        {/* Card 3: Google GenAI Model Stack */}
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-lg space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-cyan-400" />
              <h3 className="text-sm font-bold text-slate-100">Gemini Generative AI Model Pipeline</h3>
            </div>
            <span className="px-2 py-0.5 rounded text-[10px] font-mono bg-cyan-950 text-cyan-300 border border-cyan-800">
              SERVER-SIDE SDK
            </span>
          </div>

          <p className="text-xs text-slate-400">
            Protected server-side proxy routes (<code className="text-cyan-300">/api/gemini/*</code>) with telemetry header <code className="text-cyan-300">aistudio-build</code>.
          </p>

          <div className="space-y-1.5 text-xs">
            <div className="p-2 rounded bg-slate-950 border border-slate-800 flex justify-between items-center">
              <div>
                <span className="font-semibold text-slate-200 block text-[11px]">gemini-4-argon</span>
                <span className="text-[10px] text-slate-500">High Thinking Mode (ThinkingLevel.HIGH)</span>
              </div>
              <span className="text-[10px] font-mono text-purple-400">Contingency Solver</span>
            </div>

            <div className="p-2 rounded bg-slate-950 border border-slate-800 flex justify-between items-center">
              <div>
                <span className="font-semibold text-slate-200 block text-[11px]">gemini-3.8-flash</span>
                <span className="text-[10px] text-slate-500">General Disruption Diagnosis & Triage</span>
              </div>
              <span className="text-[10px] font-mono text-blue-400">Rapid Triage</span>
            </div>

            <div className="p-2 rounded bg-slate-950 border border-slate-800 flex justify-between items-center">
              <div>
                <span className="font-semibold text-slate-200 block text-[11px]">gemini-3.1-flash-lite</span>
                <span className="text-[10px] text-slate-500">Instant Pre-Flight Safety Validation</span>
              </div>
              <span className="text-[10px] font-mono text-emerald-400">Fast Check</span>
            </div>

            <div className="p-2 rounded bg-slate-950 border border-slate-800 flex justify-between items-center">
              <div>
                <span className="font-semibold text-slate-200 block text-[11px]">gemini-3.8-flash-tts</span>
                <span className="text-[10px] text-slate-500">Flagship Speech Synthesis (WAV Audio Output)</span>
              </div>
              <span className="text-[10px] font-mono text-amber-400">Executive Voice</span>
            </div>

            <div className="p-2 rounded bg-slate-950 border border-slate-800 flex justify-between items-center">
              <div>
                <span className="font-semibold text-slate-200 block text-[11px]">gemini-3-pro-image-preview</span>
                <span className="text-[10px] text-slate-500">Configurable Resolution (1K, 2K, 4K)</span>
              </div>
              <span className="text-[10px] font-mono text-cyan-400">Situation Map</span>
            </div>

            <div className="p-2 rounded bg-slate-950 border border-slate-800 flex justify-between items-center">
              <div>
                <span className="font-semibold text-slate-200 block text-[11px]">gemini-nano-banana-2.1</span>
                <span className="text-[10px] text-slate-500">Text Prompt Image Modification & Editing</span>
              </div>
              <span className="text-[10px] font-mono text-rose-400">Diagram Editor</span>
            </div>
          </div>
        </div>

        {/* Card 4: Controlled Action Execution Adapters */}
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-lg space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <ShieldCheck className="w-4 h-4 text-emerald-400" />
              <h3 className="text-sm font-bold text-slate-100">External Execution Adapters</h3>
            </div>
            <span className="px-2 py-0.5 rounded text-[10px] font-mono bg-slate-800 text-slate-400 border border-slate-700">
              IDEMPOTENT DISPATCH
            </span>
          </div>

          <div className="p-3 rounded-lg bg-amber-950/40 border border-amber-900/60 text-xs text-amber-300">
            <strong className="block font-semibold mb-0.5">Simulated Execution Transparency:</strong>
            Per product safety directives, outward email, calendar, and courier calls are processed through authenticated simulated adapters and logged with cryptographic idempotency keys. No unverified third-party charges occur.
          </div>

          <div className="space-y-1.5 text-xs">
            <div className="p-2.5 rounded bg-slate-950 border border-slate-800 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Mail className="w-3.5 h-3.5 text-slate-400" />
                <span className="text-slate-200">Email Relay Adapter</span>
              </div>
              <span className="text-[10px] font-mono text-emerald-400">Simulated / Active</span>
            </div>

            <div className="p-2.5 rounded bg-slate-950 border border-slate-800 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Calendar className="w-3.5 h-3.5 text-slate-400" />
                <span className="text-slate-200">CalDAV Reschedule Adapter</span>
              </div>
              <span className="text-[10px] font-mono text-emerald-400">Simulated / Active</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
