import React from 'react';
import { useApp } from '../context/AppContext';
import {
  AlertTriangle,
  Ban,
  Clock,
  CheckSquare,
  ShieldAlert,
  ArrowRight,
  TrendingUp,
  AlertCircle,
  FolderGit2,
} from 'lucide-react';
import { NavigationTab } from '../components/layout/Sidebar';

interface OverviewPageProps {
  onNavigate: (tab: NavigationTab) => void;
  onOpenReportModal: () => void;
}

export const OverviewPage: React.FC<OverviewPageProps> = ({ onNavigate, onOpenReportModal }) => {
  const { incidents, tasks, approvals, recoveryPlans, setActiveIncidentId } = useApp();

  const activeIncidents = incidents.filter((i) => i.status === 'ACTIVE');
  const blockedTasks = tasks.filter((t) => t.isBlocked || t.status === 'BLOCKED');
  const pendingApprovals = approvals.filter(
    (a) => a.status === 'AWAITING_APPROVAL' || a.status === 'PROPOSED'
  );
  const activePlans = recoveryPlans.filter((p) => p.isSelected);

  return (
    <div className="p-6 max-w-7xl mx-auto space-y-6">
      {/* Top Banner / Heading */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 border-b border-slate-800 pb-5">
        <div>
          <h1 className="text-xl font-bold text-slate-100 flex items-center gap-2">
            <span>Operational Resilience Overview</span>
            <span className="text-xs font-mono font-normal px-2.5 py-0.5 rounded bg-rose-950/80 text-rose-300 border border-rose-800">
              {activeIncidents.length} Active Disruption{activeIncidents.length === 1 ? '' : 's'}
            </span>
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            Real-time dependency health, cascade impact detection, and human approval queues.
          </p>
        </div>

        <div className="flex items-center gap-2.5">
          <button
            onClick={() => onNavigate('ai-command')}
            className="px-3.5 py-2 rounded bg-slate-800 hover:bg-slate-700 text-cyan-300 border border-cyan-800/50 text-xs font-medium flex items-center gap-2 transition-colors cursor-pointer"
          >
            <TrendingUp className="w-3.5 h-3.5 text-cyan-400" />
            <span>AI Command Studio</span>
          </button>
          <button
            onClick={onOpenReportModal}
            className="px-4 py-2 rounded bg-rose-600 hover:bg-rose-500 text-white text-xs font-medium flex items-center gap-2 shadow-sm transition-colors cursor-pointer"
          >
            <AlertCircle className="w-3.5 h-3.5" />
            <span>Report a Disruption</span>
          </button>
        </div>
      </div>

      {/* KPI Cards Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Card 1: Active Incidents */}
        <div
          onClick={() => onNavigate('workspace')}
          className="bg-slate-900 border border-slate-800 hover:border-slate-700 p-4 rounded-xl transition-all cursor-pointer shadow-sm"
        >
          <div className="flex items-center justify-between text-slate-400 mb-2">
            <span className="text-xs font-medium">Active Incidents</span>
            <ShieldAlert className="w-4 h-4 text-rose-400" />
          </div>
          <div className="text-2xl font-bold text-slate-100">{activeIncidents.length}</div>
          <p className="text-[11px] text-slate-400 mt-1">
            {incidents.filter((i) => i.severity === 'CRITICAL').length} critical severity
          </p>
        </div>

        {/* Card 2: Blocked Tasks */}
        <div
          onClick={() => onNavigate('dependency-map')}
          className="bg-slate-900 border border-slate-800 hover:border-slate-700 p-4 rounded-xl transition-all cursor-pointer shadow-sm"
        >
          <div className="flex items-center justify-between text-slate-400 mb-2">
            <span className="text-xs font-medium">Blocked Tasks</span>
            <Ban className="w-4 h-4 text-amber-400" />
          </div>
          <div className="text-2xl font-bold text-slate-100">{blockedTasks.length}</div>
          <p className="text-[11px] text-slate-400 mt-1">
            Halted by missing upstream prerequisites
          </p>
        </div>

        {/* Card 3: Pending Approvals */}
        <div
          onClick={() => onNavigate('approvals')}
          className="bg-slate-900 border border-slate-800 hover:border-slate-700 p-4 rounded-xl transition-all cursor-pointer shadow-sm"
        >
          <div className="flex items-center justify-between text-slate-400 mb-2">
            <span className="text-xs font-medium">Pending Approvals</span>
            <CheckSquare className="w-4 h-4 text-cyan-400" />
          </div>
          <div className="text-2xl font-bold text-slate-100">{pendingApprovals.length}</div>
          <p className="text-[11px] text-slate-400 mt-1">
            Consequential actions awaiting authorization
          </p>
        </div>

        {/* Card 4: Active Recovery Plans */}
        <div
          onClick={() => onNavigate('recovery-plans')}
          className="bg-slate-900 border border-slate-800 hover:border-slate-700 p-4 rounded-xl transition-all cursor-pointer shadow-sm"
        >
          <div className="flex items-center justify-between text-slate-400 mb-2">
            <span className="text-xs font-medium">Active Plans in Flight</span>
            <Clock className="w-4 h-4 text-emerald-400" />
          </div>
          <div className="text-2xl font-bold text-slate-100">{activePlans.length}</div>
          <p className="text-[11px] text-slate-400 mt-1">
            {recoveryPlans.length} alternative paths calculated
          </p>
        </div>
      </div>

      {/* "Needs Attention" Actionable Operational Queue */}
      <div className="bg-slate-900 border border-amber-900/40 rounded-xl p-5 shadow-sm">
        <div className="flex items-center justify-between mb-3 border-b border-slate-800 pb-2.5">
          <h2 className="text-sm font-semibold text-amber-300 flex items-center gap-2">
            <AlertTriangle className="w-4 h-4 text-amber-400" />
            <span>Needs Immediate Attention</span>
          </h2>
          <span className="text-[11px] font-mono text-slate-400">Governance & Execution Priority</span>
        </div>

        <div className="space-y-3">
          {pendingApprovals.map((appr) => {
            const inc = incidents.find((i) => i.id === appr.incidentId);

            return (
              <div
                key={appr.id}
                className="bg-slate-950/80 border border-slate-800 rounded-lg p-3.5 flex flex-col md:flex-row md:items-center md:justify-between gap-3"
              >
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-semibold text-slate-100">{appr.title}</span>
                    <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-indigo-950 text-indigo-300 border border-indigo-800">
                      {appr.actionType}
                    </span>
                  </div>
                  <p className="text-xs text-slate-400">
                    <strong className="text-slate-300 font-medium">Why it matters:</strong> {appr.description}
                  </p>
                  <p className="text-[11px] text-slate-400">
                    Belongs to: <span className="text-slate-300">{inc?.title || appr.incidentId}</span> &bull; Target:{' '}
                    <span className="font-mono text-slate-300">{appr.targetRecipient || 'System'}</span>
                  </p>
                </div>

                <div className="flex items-center gap-2 shrink-0">
                  <button
                    onClick={() => {
                      if (appr.incidentId) setActiveIncidentId(appr.incidentId);
                      onNavigate('approvals');
                    }}
                    className="px-3 py-1.5 bg-indigo-600 hover:bg-indigo-500 text-white rounded text-xs font-medium flex items-center gap-1.5 transition-colors cursor-pointer"
                  >
                    <span>Review in Approvals</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            );
          })}

          {blockedTasks.slice(0, 2).map((tsk) => {
            const inc = incidents.find((i) => i.id === tsk.incidentId);

            return (
              <div
                key={tsk.id}
                className="bg-slate-950/80 border border-slate-800 rounded-lg p-3.5 flex flex-col md:flex-row md:items-center md:justify-between gap-3"
              >
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-semibold text-slate-100">Critical Task Blocked: {tsk.title}</span>
                    <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-rose-950 text-rose-300 border border-rose-800">
                      BLOCKED
                    </span>
                  </div>
                  <p className="text-xs text-slate-400">
                    <strong className="text-slate-300 font-medium">Why it matters:</strong> Prevents downstream workflow progression and threatens deadline of {tsk.deadline ? new Date(tsk.deadline).toLocaleDateString() : 'N/A'}.
                  </p>
                  <p className="text-[11px] text-slate-400">
                    Incident: <span className="text-slate-300">{inc?.title || tsk.incidentId}</span> &bull; Assignee:{' '}
                    <span className="text-slate-300">{tsk.assignee || 'Unassigned'}</span>
                  </p>
                </div>

                <div className="flex items-center gap-2 shrink-0">
                  <button
                    onClick={() => {
                      if (tsk.incidentId) setActiveIncidentId(tsk.incidentId);
                      onNavigate('dependency-map');
                    }}
                    className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 rounded text-xs font-medium flex items-center gap-1.5 transition-colors cursor-pointer"
                  >
                    <span>Inspect 3D Conduits</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Disruption Registry Table */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-sm">
        <div className="flex items-center justify-between mb-3 border-b border-slate-800 pb-2.5">
          <h2 className="text-sm font-semibold text-slate-100 flex items-center gap-2">
            <FolderGit2 className="w-4 h-4 text-indigo-400" />
            <span>Disruptions & Crises Roster</span>
          </h2>
          <span className="text-xs text-slate-400 font-mono">{incidents.length} Total Registered</span>
        </div>

        <div className="border border-slate-800 rounded-lg overflow-hidden">
          <table className="w-full text-left text-xs text-slate-300">
            <thead className="bg-slate-950 text-slate-400 font-mono text-[11px] border-b border-slate-800">
              <tr>
                <th className="py-2.5 px-3">Title & Category</th>
                <th className="py-2.5 px-3">Severity</th>
                <th className="py-2.5 px-3">Verification</th>
                <th className="py-2.5 px-3">Status</th>
                <th className="py-2.5 px-3">Deadline</th>
                <th className="py-2.5 px-3 text-right">Command</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/80">
              {incidents.map((inc) => (
                <tr key={inc.id} className="hover:bg-slate-800/40 transition-colors">
                  <td className="py-3 px-3">
                    <span className="font-semibold text-slate-100 block">{inc.title}</span>
                    <span className="text-[11px] text-slate-400">{inc.category}</span>
                  </td>
                  <td className="py-3 px-3">
                    <div className="flex flex-col gap-1 items-start">
                      <span
                        className={`px-2 py-0.5 rounded text-[10px] font-mono font-bold ${
                          inc.severity === 'CRITICAL'
                            ? 'bg-rose-950 text-rose-300 border border-rose-800'
                            : inc.severity === 'HIGH'
                            ? 'bg-amber-950 text-amber-300 border border-amber-800'
                            : 'bg-blue-950 text-blue-300 border border-blue-800'
                        }`}
                      >
                        {inc.severity}
                      </span>
                      {inc.priority && (
                        <span className="text-[10px] font-mono text-slate-400">
                          Priority: <strong className="text-slate-200">{inc.priority}</strong>
                        </span>
                      )}
                    </div>
                  </td>
                  <td className="py-3 px-3">
                    <span className="font-mono text-[11px] text-slate-400">{inc.verificationStatus}</span>
                  </td>
                  <td className="py-3 px-3">
                    <span
                      className={`px-2 py-0.5 rounded text-[10px] font-mono ${
                        inc.status === 'ACTIVE'
                          ? 'bg-emerald-950 text-emerald-300 border border-emerald-800'
                          : 'bg-slate-800 text-slate-400 border border-slate-700'
                      }`}
                    >
                      {inc.status}
                    </span>
                  </td>
                  <td className="py-3 px-3 font-mono text-slate-400">
                    {inc.deadline ? new Date(inc.deadline).toLocaleString() : 'N/A'}
                  </td>
                  <td className="py-3 px-3 text-right">
                    <button
                      onClick={() => {
                        setActiveIncidentId(inc.id);
                        onNavigate('workspace');
                      }}
                      className="px-2.5 py-1 bg-indigo-600 hover:bg-indigo-500 text-white rounded text-xs font-medium transition-colors cursor-pointer"
                    >
                      Open Workspace
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
