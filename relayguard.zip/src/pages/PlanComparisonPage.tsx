import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { Compass, CheckCircle2, ShieldCheck, AlertTriangle, ArrowRight, Sparkles, Download, Layers } from 'lucide-react';
import { NavigationTab } from '../components/layout/Sidebar';

interface PlanComparisonPageProps {
  onNavigate: (tab: NavigationTab) => void;
}

export const PlanComparisonPage: React.FC<PlanComparisonPageProps> = ({ onNavigate }) => {
  const { recoveryPlans, selectRecoveryPlan, activeIncident } = useApp();

  const [filterStrategy, setFilterStrategy] = useState<string>('ALL');

  const filteredPlans = recoveryPlans.filter((p) => {
    if (activeIncident && p.incidentId !== activeIncident.id) return false;
    if (filterStrategy === 'ALL') return true;
    return p.strategy.toLowerCase().includes(filterStrategy.toLowerCase());
  });

  const handleExport = (plan: any) => {
    const dataStr = 'data:text/json;charset=utf-8,' + encodeURIComponent(JSON.stringify(plan, null, 2));
    const downloadAnchor = document.createElement('a');
    downloadAnchor.setAttribute('href', dataStr);
    downloadAnchor.setAttribute('download', `RelayGuard_Plan_${plan.id}.json`);
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();
  };

  return (
    <div className="p-6 max-w-7xl mx-auto space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4 border-b border-slate-800 pb-4">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-xl font-bold text-slate-100 flex items-center gap-2">
              <Compass className="w-5 h-5 text-indigo-400" />
              <span>Recovery Plan Comparison Matrix</span>
            </h1>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            Compare alternative contingency pathways side-by-side with trade-off analysis, approval requirements, and feasibility scoring.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => onNavigate('ai-command')}
            className="px-3.5 py-2 bg-indigo-600 hover:bg-indigo-500 text-white rounded text-xs font-semibold flex items-center gap-2 transition-colors cursor-pointer"
          >
            <Sparkles className="w-3.5 h-3.5" />
            <span>Generate Custom Plan via Argon</span>
          </button>
        </div>
      </div>

      {/* Disruption Context Banner */}
      {activeIncident && (
        <div className="p-3.5 rounded-lg bg-slate-900 border border-slate-800 text-xs flex items-center justify-between">
          <span className="text-slate-300">
            Evaluating contingency alternatives for:{' '}
            <strong className="text-white font-semibold">{activeIncident.title}</strong>
          </span>
          <span className="text-[11px] font-mono text-cyan-400 bg-cyan-950 px-2 py-0.5 rounded border border-cyan-800">
            {activeIncident.severity} SEVERITY
          </span>
        </div>
      )}

      {/* Side-by-side comparison grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
        {filteredPlans.map((plan) => {
          const approvalCount = plan.actions.filter((a) => a.requiresApproval).length;

          return (
            <div
              key={plan.id}
              className={`rounded-xl border flex flex-col transition-all bg-slate-900 shadow-xl ${
                plan.isSelected
                  ? 'border-indigo-500 ring-2 ring-indigo-500/30'
                  : 'border-slate-800 hover:border-slate-700'
              }`}
            >
              {/* Card Header */}
              <div className="p-5 border-b border-slate-800/80">
                <div className="flex items-center justify-between gap-2 mb-2">
                  <span className="text-[10px] font-mono font-bold uppercase tracking-wider px-2 py-0.5 rounded bg-slate-800 text-indigo-300 border border-slate-700">
                    {plan.strategy}
                  </span>
                  <div className="flex items-center gap-1.5">
                    <span className="text-xs font-mono font-bold text-emerald-400">{plan.score}% Feasibility</span>
                  </div>
                </div>

                <h3 className="text-sm font-bold text-slate-100">{plan.title}</h3>
                <p className="text-xs text-slate-400 mt-1">Est. Duration: {plan.estimatedDuration}</p>

                {plan.isSelected && (
                  <div className="mt-3 flex items-center gap-1.5 text-xs text-indigo-400 font-semibold bg-indigo-950/60 p-2 rounded border border-indigo-800">
                    <CheckCircle2 className="w-4 h-4" />
                    <span>Currently Selected Recovery Plan</span>
                  </div>
                )}
              </div>

              {/* Trade-offs & Risks */}
              <div className="p-5 space-y-3 flex-1 border-b border-slate-800/80 text-xs">
                <div>
                  <span className="block font-mono text-[10px] uppercase text-slate-500 mb-1">Trade-offs</span>
                  <p className="p-2.5 rounded bg-slate-950 border border-slate-800 text-slate-300 leading-relaxed">
                    {plan.tradeoffs}
                  </p>
                </div>

                <div>
                  <span className="block font-mono text-[10px] uppercase text-slate-500 mb-1">Critical Risks</span>
                  <p className="p-2.5 rounded bg-slate-950 border border-slate-800 text-amber-300/90 leading-relaxed">
                    {plan.risks}
                  </p>
                </div>

                {/* Ordered Actions List */}
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <span className="font-mono text-[10px] uppercase text-slate-500">
                      Action Items ({plan.actions.length})
                    </span>
                    <span className="text-[10px] font-mono text-amber-400">
                      {approvalCount} Approvals Required
                    </span>
                  </div>
                  <div className="space-y-2">
                    {plan.actions.map((act) => (
                      <div key={act.id} className="p-2.5 rounded bg-slate-950 border border-slate-800/80 text-[11px]">
                        <div className="flex items-center justify-between gap-1 mb-1">
                          <span className="font-semibold text-slate-200">
                            {act.order}. {act.title}
                          </span>
                          {act.requiresApproval && (
                            <span className="px-1.5 py-0.2 rounded text-[9px] font-mono bg-amber-950 text-amber-300 border border-amber-800 shrink-0">
                              GATE
                            </span>
                          )}
                        </div>
                        <p className="text-slate-400 text-[10px] line-clamp-2">{act.description}</p>
                        <div className="flex items-center justify-between text-slate-500 text-[10px] font-mono mt-1 pt-1 border-t border-slate-900">
                          <span>Role: {act.responsibleRole}</span>
                          <span>{act.estimatedMinutes}m</span>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>

              {/* Card Footer Actions */}
              <div className="p-4 bg-slate-950 flex items-center justify-between gap-2 rounded-b-xl">
                <button
                  onClick={() => handleExport(plan)}
                  title="Export Plan JSON"
                  className="p-2 text-slate-400 hover:text-slate-200 rounded hover:bg-slate-800 transition-colors cursor-pointer"
                >
                  <Download className="w-4 h-4" />
                </button>

                {plan.isSelected ? (
                  <button
                    onClick={() => onNavigate('approvals')}
                    className="flex-1 py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded text-xs font-semibold flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
                  >
                    <span>Proceed to Approvals</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                ) : (
                  <button
                    onClick={() => selectRecoveryPlan(plan.id)}
                    className="flex-1 py-2 bg-indigo-600 hover:bg-indigo-500 text-white rounded text-xs font-semibold transition-colors cursor-pointer"
                  >
                    Select this Plan
                  </button>
                )}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
