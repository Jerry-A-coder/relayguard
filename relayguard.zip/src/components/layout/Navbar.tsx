import React from 'react';
import { useApp } from '../../context/AppContext';
import { Shield, AlertCircle, CheckCircle, Database, LogIn, LogOut, ChevronDown } from 'lucide-react';
import { WorkspaceRole } from '../../types';

interface NavbarProps {
  onOpenReportModal: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({ onOpenReportModal }) => {
  const {
    currentUser,
    setCurrentUserRole,
    activeWorkspace,
    incidents,
    activeIncident,
    activeIncidentId,
    setActiveIncidentId,
    isFirebaseConnected,
    loginWithGooglePopup,
    logoutUser,
  } = useApp();

  const roles: WorkspaceRole[] = ['OWNER', 'ADMIN', 'MEMBER', 'VIEWER'];

  return (
    <header className="h-14 border-b border-slate-800 bg-slate-900/95 sticky top-0 z-40 px-4 flex items-center justify-between text-xs text-slate-200">
      {/* Brand & Workspace Identity */}
      <div className="flex items-center gap-4">
        <div className="flex items-center gap-2 font-bold text-sm tracking-tight text-white">
          <div className="w-7 h-7 rounded bg-indigo-600 flex items-center justify-center text-white shadow-sm">
            <Shield className="w-4 h-4" />
          </div>
          <span>RelayGuard</span>
        </div>

        <div className="hidden sm:flex items-center gap-2 pl-4 border-l border-slate-800 text-slate-400">
          <span className="font-medium text-slate-300">{activeWorkspace.name}</span>
          <span className="text-[10px] px-1.5 py-0.5 rounded bg-slate-800 text-slate-400 border border-slate-700 font-mono">
            ID: {activeWorkspace.id}
          </span>
        </div>
      </div>

      {/* Incident Switcher & Operations Quick Bar */}
      <div className="flex items-center gap-3">
        <div className="hidden md:flex items-center gap-2 bg-slate-950 border border-slate-800 rounded px-2.5 py-1">
          <span className="text-slate-400 text-[11px]">Active Disruption:</span>
          <select
            value={activeIncidentId}
            onChange={(e) => setActiveIncidentId(e.target.value)}
            className="bg-transparent text-slate-200 text-xs font-medium focus:outline-none cursor-pointer max-w-[220px] truncate"
          >
            {incidents.map((inc) => (
              <option key={inc.id} value={inc.id} className="bg-slate-900 text-slate-200">
                [{inc.severity}] {inc.title}
              </option>
            ))}
          </select>
        </div>

        <button
          onClick={onOpenReportModal}
          className="bg-rose-600 hover:bg-rose-500 text-white font-medium px-3 py-1.5 rounded shadow flex items-center gap-1.5 transition-colors cursor-pointer text-xs"
        >
          <AlertCircle className="w-3.5 h-3.5" />
          <span>Report Disruption</span>
        </button>

        {/* Database & Auth status */}
        <div className="hidden lg:flex items-center gap-1.5 px-2 py-1 rounded bg-slate-950 border border-slate-800 text-[11px] text-slate-400">
          <Database className="w-3.5 h-3.5 text-indigo-400" />
          <span>Firestore:</span>
          <span className={isFirebaseConnected ? 'text-emerald-400 font-mono' : 'text-amber-400 font-mono'}>
            {isFirebaseConnected ? 'Connected' : 'Active'}
          </span>
        </div>

        {/* User Role Switcher (RBAC testing) */}
        <div className="flex items-center gap-1.5 bg-slate-950 border border-slate-800 rounded px-2 py-1">
          <span className="text-[11px] text-slate-400">Role:</span>
          <select
            value={currentUser.role}
            onChange={(e) => setCurrentUserRole(e.target.value as WorkspaceRole)}
            className="bg-transparent text-xs font-mono font-semibold text-indigo-300 focus:outline-none cursor-pointer"
          >
            {roles.map((r) => (
              <option key={r} value={r} className="bg-slate-900 text-slate-200">
                {r}
              </option>
            ))}
          </select>
        </div>

        {/* Auth action */}
        {currentUser.email ? (
          <div className="flex items-center gap-2 pl-2">
            <div className="hidden xl:block text-right">
              <span className="block font-medium text-slate-200 truncate max-w-[140px] text-[11px]">
                {currentUser.displayName}
              </span>
              <span className="block text-[10px] text-slate-400 font-mono">{currentUser.email}</span>
            </div>
            <button
              onClick={loginWithGooglePopup}
              title="Google Account Sign-In"
              className="p-1.5 text-slate-400 hover:text-white rounded bg-slate-800 hover:bg-slate-700 transition-colors cursor-pointer"
            >
              <LogIn className="w-3.5 h-3.5 text-indigo-400" />
            </button>
          </div>
        ) : (
          <button
            onClick={loginWithGooglePopup}
            className="px-2.5 py-1 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded text-xs flex items-center gap-1.5 cursor-pointer"
          >
            <LogIn className="w-3.5 h-3.5" />
            <span>Sign In</span>
          </button>
        )}
      </div>
    </header>
  );
};
