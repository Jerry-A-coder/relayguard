import React from 'react';
import {
  LayoutDashboard,
  PlusCircle,
  FolderGit2,
  GitFork,
  Compass,
  CheckSquare,
  History,
  Sparkles,
  Cpu,
  Settings,
} from 'lucide-react';
import { useApp } from '../../context/AppContext';

export type NavigationTab =
  | 'overview'
  | 'intake'
  | 'workspace'
  | 'dependency-map'
  | 'recovery-plans'
  | 'approvals'
  | 'activity'
  | 'ai-command'
  | 'integrations'
  | 'settings';

interface SidebarProps {
  activeTab: NavigationTab;
  onSelectTab: (tab: NavigationTab) => void;
}

export const Sidebar: React.FC<SidebarProps> = ({ activeTab, onSelectTab }) => {
  const { approvals, activeIncident } = useApp();

  const pendingApprovalsCount = approvals.filter(
    (a) => a.status === 'AWAITING_APPROVAL' || a.status === 'PROPOSED'
  ).length;

  interface NavItem {
    id: NavigationTab;
    label: string;
    icon: any;
    badge?: number;
    highlight?: boolean;
  }

  const navItems: NavItem[] = [
    { id: 'overview', label: 'Overview', icon: LayoutDashboard },
    { id: 'intake', label: 'Report Disruption', icon: PlusCircle },
    { id: 'workspace', label: 'Incident Workspace', icon: FolderGit2 },
    { id: 'dependency-map', label: 'Dependency Map', icon: GitFork },
    { id: 'recovery-plans', label: 'Recovery Plans', icon: Compass },
    {
      id: 'approvals',
      label: 'Approval Centre',
      icon: CheckSquare,
      badge: pendingApprovalsCount > 0 ? pendingApprovalsCount : undefined,
    },
    { id: 'activity', label: 'Activity Timeline', icon: History },
    { id: 'ai-command', label: 'AI Command Studio', icon: Sparkles, highlight: true },
    { id: 'integrations', label: 'Integrations & MCP', icon: Cpu },
    { id: 'settings', label: 'Settings', icon: Settings },
  ];

  return (
    <aside className="w-56 bg-slate-950 border-r border-slate-800 flex flex-col shrink-0 select-none">
      <div className="p-3 border-b border-slate-800">
        <span className="text-[11px] font-mono text-slate-400 uppercase tracking-wider block">Operational Suite</span>
        <span className="text-xs font-semibold text-slate-200 truncate block mt-0.5">
          {activeIncident ? activeIncident.title : 'Incident Command'}
        </span>
      </div>

      <nav className="flex-1 p-2 space-y-1 overflow-y-auto">
        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = activeTab === item.id;

          return (
            <button
              key={item.id}
              onClick={() => onSelectTab(item.id as NavigationTab)}
              className={`w-full flex items-center justify-between px-3 py-2 rounded text-xs transition-colors cursor-pointer text-left ${
                isActive
                  ? 'bg-indigo-600/90 text-white font-medium shadow-sm'
                  : item.highlight
                  ? 'text-cyan-300 hover:bg-slate-900 bg-cyan-950/20 border border-cyan-900/40'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
              }`}
            >
              <div className="flex items-center gap-2.5">
                <Icon className={`w-4 h-4 ${isActive ? 'text-white' : item.highlight ? 'text-cyan-400' : 'text-slate-400'}`} />
                <span>{item.label}</span>
              </div>
              {item.badge !== undefined && (
                <span className="px-1.5 py-0.2 rounded-full text-[10px] font-mono bg-rose-500 text-white font-bold">
                  {item.badge}
                </span>
              )}
            </button>
          );
        })}
      </nav>

      {/* Footer tagline per product identity */}
      <div className="p-3 border-t border-slate-900 bg-slate-950 text-[11px] text-slate-400">
        <p className="italic text-slate-400 text-[10px] leading-tight">
          &ldquo;When plans break, find the next best move.&rdquo;
        </p>
      </div>
    </aside>
  );
};
