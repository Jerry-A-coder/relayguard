import React, { useState, useEffect, useRef } from 'react';
import { useApp } from '../../context/AppContext';
import { Mic, MicOff, Save, Sparkles, Trash2, CheckCircle2, AlertCircle, FileText } from 'lucide-react';

export const VoiceDictationNotes: React.FC = () => {
  const { activeIncident, logActivity, currentUser } = useApp();

  const [isListening, setIsListening] = useState(false);
  const [transcript, setTranscript] = useState('');
  const [interimText, setInterimText] = useState('');
  const [isSupported, setIsSupported] = useState(true);
  const [isAiStructuring, setIsAiStructuring] = useState(false);
  const [statusMessage, setStatusMessage] = useState<string | null>(null);

  const recognitionRef = useRef<any>(null);

  useEffect(() => {
    // Check for browser SpeechRecognition API support
    const SpeechRecognition =
      (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;

    if (!SpeechRecognition) {
      setIsSupported(false);
      return;
    }

    try {
      const recognition = new SpeechRecognition();
      recognition.continuous = true;
      recognition.interimResults = true;
      recognition.lang = 'en-US';

      recognition.onresult = (event: any) => {
        let currentInterim = '';
        let finalTranscriptChunk = '';

        for (let i = event.resultIndex; i < event.results.length; ++i) {
          if (event.results[i].isFinal) {
            finalTranscriptChunk += event.results[i][0].transcript + ' ';
          } else {
            currentInterim += event.results[i][0].transcript;
          }
        }

        if (finalTranscriptChunk) {
          setTranscript((prev) => (prev ? prev + ' ' + finalTranscriptChunk.trim() : finalTranscriptChunk.trim()));
        }
        setInterimText(currentInterim);
      };

      recognition.onerror = (event: any) => {
        console.warn('SpeechRecognition error:', event.error);
        if (event.error === 'not-allowed') {
          setStatusMessage('Microphone permission was denied. Please allow microphone access in browser settings.');
        } else {
          setStatusMessage(`Dictation notice: ${event.error}`);
        }
        setIsListening(false);
      };

      recognition.onend = () => {
        setIsListening(false);
        setInterimText('');
      };

      recognitionRef.current = recognition;
    } catch (err) {
      console.warn('Failed to initialize SpeechRecognition:', err);
      setIsSupported(false);
    }

    return () => {
      if (recognitionRef.current) {
        try {
          recognitionRef.current.stop();
        } catch {
          // ignore
        }
      }
    };
  }, []);

  const toggleListening = () => {
    setStatusMessage(null);
    if (!recognitionRef.current) {
      setStatusMessage('SpeechRecognition is not supported in this browser.');
      return;
    }

    if (isListening) {
      try {
        recognitionRef.current.stop();
      } catch (err) {
        console.warn(err);
      }
      setIsListening(false);
    } else {
      try {
        recognitionRef.current.start();
        setIsListening(true);
        setStatusMessage('Listening... Speak clearly into your microphone.');
      } catch (err) {
        console.warn('Speech start error:', err);
        setIsListening(false);
      }
    }
  };

  const handleSaveToAuditLog = () => {
    if (!transcript.trim()) return;

    const fullNote = transcript.trim();
    logActivity(
      'INCIDENT_UPDATED',
      `Voice Dictation Note recorded by ${currentUser.displayName}`,
      fullNote
    );

    setStatusMessage('Dictated note successfully logged to the incident activity audit trail!');
    setTranscript('');
    setInterimText('');
    setTimeout(() => setStatusMessage(null), 4000);
  };

  const handleStructureWithAI = async () => {
    if (!transcript.trim()) return;
    setIsAiStructuring(true);
    setStatusMessage('Formatting raw speech transcript into structured SITREP...');
    try {
      const response = await fetch('/api/gemini/fast-check', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          proposedAction: { text: 'Format speech dictation into military-grade operational SITREP' },
          task: { text: transcript },
          constraints: activeIncident?.knownConstraints,
        }),
      });
      const data = await response.json();
      if (data.success && data.validation?.recommendation) {
        setTranscript(
          (prev) =>
            `${prev}\n\n[Structured SITREP Summary]:\n${data.validation.recommendation}`
        );
        setStatusMessage('AI formatting applied.');
      }
    } catch (e: any) {
      setStatusMessage(`AI formatting error: ${e.message}`);
    } finally {
      setIsAiStructuring(false);
    }
  };

  return (
    <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-lg space-y-4">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 border-b border-slate-800 pb-3">
        <div className="flex items-center gap-2.5">
          <div
            className={`w-8 h-8 rounded-lg flex items-center justify-center ${
              isListening
                ? 'bg-rose-950 text-rose-400 border border-rose-800'
                : 'bg-indigo-950 text-indigo-400 border border-indigo-800'
            }`}
          >
            <Mic className="w-4 h-4" />
          </div>
          <div>
            <h3 className="text-sm font-bold text-slate-100 flex items-center gap-2">
              <span>Voice Dictation & Field Recovery Notes</span>
              {isListening && (
                <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-rose-950 text-rose-300 border border-rose-800 font-bold">
                  RECORDING AUDIO
                </span>
              )}
            </h3>
            <p className="text-xs text-slate-400 mt-0.5">
              Dictate tactical updates, inspection findings, or phone coordination notes directly into the incident audit log.
            </p>
          </div>
        </div>

        {/* Start / Stop Button */}
        <div className="flex items-center gap-2">
          <button
            onClick={toggleListening}
            className={`px-3.5 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-2 transition-colors cursor-pointer shadow-sm ${
              isListening
                ? 'bg-rose-600 hover:bg-rose-500 text-white'
                : 'bg-indigo-600 hover:bg-indigo-500 text-white'
            }`}
          >
            {isListening ? (
              <>
                <MicOff className="w-3.5 h-3.5" />
                <span>Stop Dictation</span>
              </>
            ) : (
              <>
                <Mic className="w-3.5 h-3.5" />
                <span>Start Voice Dictation</span>
              </>
            )}
          </button>
        </div>
      </div>

      {!isSupported && (
        <div className="p-3 rounded-lg bg-amber-950/40 border border-amber-800 text-amber-300 text-xs flex items-center gap-2">
          <AlertCircle className="w-4 h-4 text-amber-400 shrink-0" />
          <span>
            SpeechRecognition API is not native to this browser environment. You can still type directly into the notes field below.
          </span>
        </div>
      )}

      {/* Transcript Text Box */}
      <div className="relative">
        <textarea
          rows={4}
          value={transcript + (interimText ? ` [${interimText}]` : '')}
          onChange={(e) => setTranscript(e.target.value)}
          placeholder={
            isListening
              ? 'Listening... Start speaking to transcribe field notes...'
              : 'Click "Start Voice Dictation" or type operational observations directly here...'
          }
          className="w-full bg-slate-950 border border-slate-700 rounded-lg p-3 text-xs text-slate-100 placeholder-slate-500 focus:outline-none focus:border-indigo-500 leading-relaxed font-mono"
        />
      </div>

      {statusMessage && (
        <div className="text-xs text-slate-300 flex items-center gap-2">
          <span className="w-1.5 h-1.5 rounded-full bg-indigo-400 inline-block" />
          <span>{statusMessage}</span>
        </div>
      )}

      {/* Actions */}
      <div className="flex flex-wrap items-center justify-between gap-3 pt-2">
        <div className="flex items-center gap-2">
          <button
            onClick={handleStructureWithAI}
            disabled={!transcript.trim() || isAiStructuring}
            className="px-3 py-1.5 rounded bg-slate-800 hover:bg-slate-700 text-cyan-300 text-xs font-medium border border-slate-700 flex items-center gap-1.5 disabled:opacity-40 transition-colors cursor-pointer"
          >
            <Sparkles className={`w-3.5 h-3.5 ${isAiStructuring ? 'animate-spin' : ''}`} />
            <span>Format with Gemini SITREP</span>
          </button>

          <button
            onClick={() => {
              setTranscript('');
              setInterimText('');
            }}
            disabled={!transcript && !interimText}
            className="p-1.5 rounded text-slate-400 hover:text-rose-400 hover:bg-slate-800 disabled:opacity-30 transition-colors cursor-pointer"
            title="Clear text"
          >
            <Trash2 className="w-4 h-4" />
          </button>
        </div>

        <button
          onClick={handleSaveToAuditLog}
          disabled={!transcript.trim()}
          className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 disabled:opacity-40 text-white rounded text-xs font-semibold flex items-center gap-2 shadow-sm transition-colors cursor-pointer"
        >
          <Save className="w-3.5 h-3.5" />
          <span>Save Note to Incident Audit Log</span>
        </button>
      </div>
    </div>
  );
};
