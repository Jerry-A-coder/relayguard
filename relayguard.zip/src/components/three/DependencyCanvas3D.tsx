import React, { useEffect, useRef, useState } from 'react';
import * as THREE from 'three';
import { RoomEnvironment } from 'three/addons/environments/RoomEnvironment.js';
import { Task, Dependency } from '../../types';

interface DependencyCanvas3DProps {
  tasks: Task[];
  dependencies: Dependency[];
  selectedTaskId: string | null;
  onSelectTask: (taskId: string) => void;
}

// Pre-allocated reusable math scratch objects (Zero GC in animation loop)
const _scratchVecA = new THREE.Vector3();
const _scratchVecB = new THREE.Vector3();
const _scratchVecC = new THREE.Vector3();

export const DependencyCanvas3D: React.FC<DependencyCanvas3DProps> = ({
  tasks,
  dependencies,
  selectedTaskId,
  onSelectTask,
}) => {
  const mountRef = useRef<HTMLDivElement>(null);
  const [isDockCollapsed, setIsDockCollapsed] = useState(false);
  const [cameraPreset, setCameraPreset] = useState<'ISO' | 'TOP' | 'FLOW' | 'INSPECT'>('ISO');
  const [pulseEnergy, setPulseEnergy] = useState(true);
  const [hoveredTask, setHoveredTask] = useState<Task | null>(null);

  // Mutable refs to decouple Three.js render loop from React state re-renders
  const sceneRef = useRef<THREE.Scene | null>(null);
  const cameraRef = useRef<THREE.PerspectiveCamera | null>(null);
  const rendererRef = useRef<THREE.WebGLRenderer | null>(null);
  const nodeGroupsRef = useRef<Map<string, THREE.Group>>(new Map());
  const conduitCurvesRef = useRef<{ curve: THREE.QuadraticBezierCurve3; pulseMesh: THREE.Mesh }[]>([]);
  const targetCameraPosRef = useRef<THREE.Vector3>(new THREE.Vector3(0, 18, 28));
  const targetLookAtRef = useRef<THREE.Vector3>(new THREE.Vector3(0, 2, 0));
  const currentLookAtRef = useRef<THREE.Vector3>(new THREE.Vector3(0, 2, 0));
  const isDraggingRef = useRef(false);
  const previousMousePositionRef = useRef({ x: 0, y: 0 });
  const raycasterRef = useRef(new THREE.Raycaster());
  const mouseRef = useRef(new THREE.Vector2());

  // Helper to get status color
  const getStatusColor = (status: string, isBlocked?: boolean) => {
    if (isBlocked || status === 'BLOCKED') return 0xef4444; // Red
    if (status === 'COMPLETED') return 0x10b981; // Emerald Green
    if (status === 'IN_PROGRESS') return 0x3b82f6; // Blue
    return 0xf59e0b; // Amber / Not Started
  };

  useEffect(() => {
    if (!mountRef.current) return;
    const container = mountRef.current;
    const width = container.clientWidth || window.innerWidth;
    const height = container.clientHeight || window.innerHeight;

    // Detect software WebGL guard
    const isSoftwareGl = (() => {
      const probeCanvas = document.createElement('canvas');
      const gl = probeCanvas.getContext('webgl2') || probeCanvas.getContext('webgl');
      if (!gl) return true;
      const ext = gl.getExtension('WEBGL_debug_renderer_info');
      const param = ext ? ext.UNMASKED_RENDERER_WEBGL : gl.RENDERER;
      const gpu = String(gl.getParameter(param));
      gl.getExtension('WEBGL_lose_context')?.loseContext();
      return /SwiftShader|llvmpipe|softpipe|Software|Basic Render/i.test(gpu);
    })();

    // 1. Scene & Horizon Fog matching background slate
    const scene = new THREE.Scene();
    scene.background = new THREE.Color(0x0a0f1d);
    scene.fog = new THREE.FogExp2(0x0a0f1d, 0.022);
    sceneRef.current = scene;

    // 2. Camera
    const camera = new THREE.PerspectiveCamera(45, width / height, 0.1, 200);
    camera.position.set(0, 18, 28);
    camera.lookAt(0, 2, 0);
    cameraRef.current = camera;

    // 3. Renderer with ACESFilmicToneMapping and SRGBColorSpace
    const renderer = new THREE.WebGLRenderer({
      antialias: !isSoftwareGl,
      powerPreference: 'high-performance',
      alpha: false,
    });
    renderer.setSize(width, height);
    renderer.setPixelRatio(isSoftwareGl ? 1 : Math.min(window.devicePixelRatio, 2));
    renderer.outputColorSpace = THREE.SRGBColorSpace;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.15;
    renderer.shadowMap.enabled = !isSoftwareGl;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    rendererRef.current = renderer;

    container.replaceChildren(renderer.domElement);

    // 4. Studio Environment Lighting via RoomEnvironment + PMREMGenerator
    const pmremGenerator = new THREE.PMREMGenerator(renderer);
    scene.environment = pmremGenerator.fromScene(new RoomEnvironment(), 0.04).texture;
    pmremGenerator.dispose();

    // Studio 3-point lighting rig
    const keyLight = new THREE.DirectionalLight(0xfff5e6, 2.8); // Warm key
    keyLight.position.set(16, 26, 18);
    keyLight.castShadow = !isSoftwareGl;
    if (keyLight.castShadow) {
      keyLight.shadow.mapSize.width = 1024;
      keyLight.shadow.mapSize.height = 1024;
      keyLight.shadow.camera.near = 0.5;
      keyLight.shadow.camera.far = 80;
      keyLight.shadow.camera.left = -25;
      keyLight.shadow.camera.right = 25;
      keyLight.shadow.camera.top = 25;
      keyLight.shadow.camera.bottom = -25;
      keyLight.shadow.bias = -0.0005;
      keyLight.shadow.normalBias = 0.02;
    }
    scene.add(keyLight);

    const fillLight = new THREE.HemisphereLight(0x38bdf8, 0x090d16, 1.2); // Cool sky vs ground
    scene.add(fillLight);

    const rimLight = new THREE.DirectionalLight(0x818cf8, 1.4); // Cool purple-blue accent rim
    rimLight.position.set(-18, 14, -18);
    scene.add(rimLight);

    // 5. Ground Foundation Floor with Procedural Grid Texture
    const floorCanvas = document.createElement('canvas');
    floorCanvas.width = 512;
    floorCanvas.height = 512;
    const ctx = floorCanvas.getContext('2d')!;
    ctx.fillStyle = '#0b1122';
    ctx.fillRect(0, 0, 512, 512);
    ctx.strokeStyle = '#1e293b';
    ctx.lineWidth = 1;
    for (let i = 0; i < 512; i += 32) {
      ctx.beginPath();
      ctx.moveTo(i, 0);
      ctx.lineTo(i, 512);
      ctx.stroke();
      ctx.beginPath();
      ctx.moveTo(0, i);
      ctx.lineTo(512, i);
      ctx.stroke();
    }
    ctx.strokeStyle = '#334155';
    ctx.lineWidth = 2;
    for (let i = 0; i < 512; i += 128) {
      ctx.strokeRect(i, 0, 128, 512);
      ctx.strokeRect(0, i, 512, 128);
    }
    const floorTexture = new THREE.CanvasTexture(floorCanvas);
    floorTexture.wrapS = THREE.RepeatWrapping;
    floorTexture.wrapT = THREE.RepeatWrapping;
    floorTexture.repeat.set(16, 16);
    floorTexture.colorSpace = THREE.SRGBColorSpace;
    floorTexture.anisotropy = renderer.capabilities.getMaxAnisotropy();

    const floorGeo = new THREE.PlaneGeometry(160, 160);
    const floorMat = new THREE.MeshStandardMaterial({
      map: floorTexture,
      roughness: 0.85,
      metalness: 0.25,
    });
    const floorMesh = new THREE.Mesh(floorGeo, floorMat);
    floorMesh.rotation.x = -Math.PI / 2;
    floorMesh.position.y = 0;
    floorMesh.receiveShadow = !isSoftwareGl;
    scene.add(floorMesh);

    // 6. Build Composite 3-12 Part Procedural Node Models for each task
    // Calculate layout positions (arranged cleanly along topological stages)
    const taskCount = tasks.length;
    const nodeGroups = new Map<string, THREE.Group>();
    const nodePositions = new Map<string, THREE.Vector3>();

    // Shared reusable procedural geometries for efficiency
    const pedestalGeo = new THREE.CylinderGeometry(1.6, 1.9, 0.4, 24);
    const hullGeo = new THREE.CylinderGeometry(1.2, 1.4, 1.6, 24);
    const coreGeo = new THREE.SphereGeometry(0.7, 24, 24);
    const gyroRingGeo = new THREE.TorusGeometry(1.4, 0.08, 12, 32);
    const domeGeo = new THREE.SphereGeometry(1.25, 24, 16, 0, Math.PI * 2, 0, Math.PI * 0.5);
    const spireGeo = new THREE.ConeGeometry(0.15, 1.2, 8);
    const beaconTipGeo = new THREE.SphereGeometry(0.2, 12, 12);
    const contactShadowGeo = new THREE.CircleGeometry(2.1, 24);

    const contactShadowMat = new THREE.MeshBasicMaterial({
      color: 0x000000,
      transparent: true,
      opacity: 0.5,
      depthWrite: false,
    });

    tasks.forEach((task, idx) => {
      const group = new THREE.Group();
      group.name = task.id;

      // Position logic: spread out in clean flow curve
      const angle = (idx / Math.max(1, taskCount - 1)) * Math.PI * 0.9 - Math.PI * 0.45;
      const radius = 12 + (idx % 2) * 3;
      const x = Math.sin(angle) * radius;
      const z = -Math.cos(angle) * (radius * 0.6) + 3;
      const y = 0; // Pivoted bottom-center flush with ground

      group.position.set(x, y, z);
      nodePositions.set(task.id, new THREE.Vector3(x, y, z));

      const statusColor = getStatusColor(task.status, task.isBlocked);

      // PART 1: Soft Contact Shadow Plane (Grounding)
      const shadowMesh = new THREE.Mesh(contactShadowGeo, contactShadowMat);
      shadowMesh.rotation.x = -Math.PI / 2;
      shadowMesh.position.y = 0.02; // Offset by 0.02 to prevent Z-fighting
      group.add(shadowMesh);

      // PART 2: Base Heavy Pedestal
      const pedestalMat = new THREE.MeshStandardMaterial({
        color: 0x1e293b,
        metalness: 0.8,
        roughness: 0.35,
      });
      const pedestalMesh = new THREE.Mesh(pedestalGeo, pedestalMat);
      pedestalMesh.position.y = 0.2;
      pedestalMesh.castShadow = !isSoftwareGl;
      pedestalMesh.receiveShadow = !isSoftwareGl;
      group.add(pedestalMesh);

      // PART 3: Primary Reactor Hull
      const hullMat = new THREE.MeshStandardMaterial({
        color: 0x0f172a,
        metalness: 0.9,
        roughness: 0.2,
      });
      const hullMesh = new THREE.Mesh(hullGeo, hullMat);
      hullMesh.position.y = 1.2;
      hullMesh.castShadow = !isSoftwareGl;
      group.add(hullMesh);

      // PART 4: Status Emissive Core (Glowing internal power source)
      const coreMat = new THREE.MeshStandardMaterial({
        color: statusColor,
        emissive: statusColor,
        emissiveIntensity: 1.8,
        roughness: 0.1,
        metalness: 0.5,
      });
      const coreMesh = new THREE.Mesh(coreGeo, coreMat);
      coreMesh.position.y = 2.1;
      group.add(coreMesh);

      // PART 5: Rotating Gyroscopic Containment Ring
      const ringMat = new THREE.MeshStandardMaterial({
        color: 0x94a3b8,
        metalness: 0.95,
        roughness: 0.15,
      });
      const ringMesh = new THREE.Mesh(gyroRingGeo, ringMat);
      ringMesh.position.y = 2.1;
      ringMesh.rotation.x = Math.PI / 4;
      ringMesh.name = 'gyroRing';
      group.add(ringMesh);

      // PART 6: Optical Shield Glass Dome
      const domeMat = new THREE.MeshPhysicalMaterial({
        color: 0xffffff,
        transparent: true,
        opacity: isSoftwareGl ? 0.3 : 0.45,
        transmission: isSoftwareGl ? 0 : 0.85,
        ior: 1.5,
        roughness: 0.05,
        metalness: 0.1,
        depthWrite: false,
      });
      const domeMesh = new THREE.Mesh(domeGeo, domeMat);
      domeMesh.position.y = 1.9;
      group.add(domeMesh);

      // PART 7: Antenna Spire with Beacon Light Tip
      const spireMat = new THREE.MeshStandardMaterial({
        color: 0x475569,
        metalness: 0.85,
        roughness: 0.3,
      });
      const spireMesh = new THREE.Mesh(spireGeo, spireMat);
      spireMesh.position.y = 3.6;
      group.add(spireMesh);

      const beaconMat = new THREE.MeshBasicMaterial({
        color: statusColor,
      });
      const beaconTip = new THREE.Mesh(beaconTipGeo, beaconMat);
      beaconTip.position.y = 4.3;
      group.add(beaconTip);

      // Attach data tag to group
      group.userData = { taskId: task.id, task };

      scene.add(group);
      nodeGroups.set(task.id, group);
    });
    nodeGroupsRef.current = nodeGroups;

    // 7. Dependency Conduits (Beziers with flowing energy pulse spheres)
    const conduitCurves: { curve: THREE.QuadraticBezierCurve3; pulseMesh: THREE.Mesh }[] = [];
    const pulseGeo = new THREE.SphereGeometry(0.35, 12, 12);

    dependencies.forEach((dep) => {
      const srcPos = nodePositions.get(dep.sourceTaskId);
      const tgtPos = nodePositions.get(dep.targetTaskId);
      if (!srcPos || !tgtPos) return;

      const p0 = new THREE.Vector3(srcPos.x, srcPos.y + 2.1, srcPos.z);
      const p2 = new THREE.Vector3(tgtPos.x, tgtPos.y + 2.1, tgtPos.z);
      const mid = new THREE.Vector3()
        .addVectors(p0, p2)
        .multiplyScalar(0.5)
        .add(new THREE.Vector3(0, 3.2, 0)); // Arch upward

      const curve = new THREE.QuadraticBezierCurve3(p0, mid, p2);
      const points = curve.getPoints(36);
      const tubeGeo = new THREE.TubeGeometry(curve, 36, 0.09, 8, false);

      const isBlockerEdge = dep.relationType === 'BLOCKS';
      const tubeColor = isBlockerEdge ? 0xef4444 : 0x06b6d4;

      const tubeMat = new THREE.MeshStandardMaterial({
        color: tubeColor,
        emissive: tubeColor,
        emissiveIntensity: 0.8,
        roughness: 0.3,
        metalness: 0.8,
        transparent: true,
        opacity: 0.85,
      });
      const tubeMesh = new THREE.Mesh(tubeGeo, tubeMat);
      scene.add(tubeMesh);

      // Energy Pulse traveling along the curve
      const pulseMat = new THREE.MeshBasicMaterial({
        color: isBlockerEdge ? 0xff6b6b : 0x67e8f9,
      });
      const pulseMesh = new THREE.Mesh(pulseGeo, pulseMat);
      pulseMesh.position.copy(p0);
      scene.add(pulseMesh);

      conduitCurves.push({ curve, pulseMesh });
    });
    conduitCurvesRef.current = conduitCurves;

    // 8. Event Listeners for Interaction (Orbit & Raycast)
    const handleMouseDown = (e: MouseEvent) => {
      isDraggingRef.current = true;
      previousMousePositionRef.current = { x: e.clientX, y: e.clientY };
    };

    const handleMouseMove = (e: MouseEvent) => {
      const rect = container.getBoundingClientRect();
      mouseRef.current.x = ((e.clientX - rect.left) / rect.width) * 2 - 1;
      mouseRef.current.y = -((e.clientY - rect.top) / rect.height) * 2 + 1;

      if (isDraggingRef.current) {
        const deltaX = e.clientX - previousMousePositionRef.current.x;
        const deltaY = e.clientY - previousMousePositionRef.current.y;

        // Orbit camera around current lookAt
        const cam = cameraRef.current;
        if (cam) {
          const offset = cam.position.clone().sub(currentLookAtRef.current);
          const spherical = new THREE.Spherical().setFromVector3(offset);
          spherical.theta -= deltaX * 0.007;
          spherical.phi = Math.max(0.15, Math.min(Math.PI / 2.1, spherical.phi - deltaY * 0.007));
          offset.setFromSpherical(spherical);
          cam.position.copy(currentLookAtRef.current).add(offset);
        }

        previousMousePositionRef.current = { x: e.clientX, y: e.clientY };
      } else {
        // Raycast hover check
        if (cameraRef.current) {
          raycasterRef.current.setFromCamera(mouseRef.current, cameraRef.current);
          const intersects = raycasterRef.current.intersectObjects(scene.children, true);
          let foundTask: Task | null = null;
          for (const hit of intersects) {
            let obj: THREE.Object3D | null = hit.object;
            while (obj && !obj.userData?.taskId) {
              obj = obj.parent;
            }
            if (obj && obj.userData?.task) {
              foundTask = obj.userData.task;
              break;
            }
          }
          setHoveredTask(foundTask);
        }
      }
    };

    const handleMouseUp = () => {
      isDraggingRef.current = false;
    };

    const handleClick = (e: MouseEvent) => {
      const rect = container.getBoundingClientRect();
      const clickMouse = new THREE.Vector2(
        ((e.clientX - rect.left) / rect.width) * 2 - 1,
        -((e.clientY - rect.top) / rect.height) * 2 + 1
      );

      if (cameraRef.current) {
        raycasterRef.current.setFromCamera(clickMouse, cameraRef.current);
        const intersects = raycasterRef.current.intersectObjects(scene.children, true);
        for (const hit of intersects) {
          let obj: THREE.Object3D | null = hit.object;
          while (obj && !obj.userData?.taskId) {
            obj = obj.parent;
          }
          if (obj && obj.userData?.taskId) {
            onSelectTask(obj.userData.taskId);
            break;
          }
        }
      }
    };

    const handleWheel = (e: WheelEvent) => {
      e.preventDefault();
      const cam = cameraRef.current;
      if (!cam) return;
      const zoomDelta = e.deltaY * 0.02;
      const dir = cam.position.clone().sub(currentLookAtRef.current).normalize();
      const dist = cam.position.distanceTo(currentLookAtRef.current);
      const newDist = Math.max(8, Math.min(65, dist + zoomDelta));
      cam.position.copy(currentLookAtRef.current).add(dir.multiplyScalar(newDist));
    };

    container.addEventListener('mousedown', handleMouseDown);
    window.addEventListener('mousemove', handleMouseMove);
    window.addEventListener('mouseup', handleMouseUp);
    container.addEventListener('click', handleClick);
    container.addEventListener('wheel', handleWheel, { passive: false });

    // 9. Resize Observer
    const resizeObserver = new ResizeObserver((entries) => {
      if (!entries[0] || !cameraRef.current || !rendererRef.current) return;
      const { width: w, height: h } = entries[0].contentRect;
      cameraRef.current.aspect = w / h;
      cameraRef.current.updateProjectionMatrix();
      rendererRef.current.setSize(w, h);
    });
    resizeObserver.observe(container);

    // 10. Animation Loop with Exponential Damping & Lossless 60fps
    let animationFrameId: number;
    let clock = new THREE.Clock();

    const animate = () => {
      animationFrameId = requestAnimationFrame(animate);
      const delta = clock.getDelta();
      const elapsed = clock.getElapsedTime();

      // Smooth camera interpolation towards target position and lookAt
      if (cameraRef.current && !isDraggingRef.current) {
        const k = 3.5;
        const dampFactor = 1 - Math.exp(-k * delta);
        cameraRef.current.position.lerp(targetCameraPosRef.current, dampFactor);
        currentLookAtRef.current.lerp(targetLookAtRef.current, dampFactor);
        cameraRef.current.lookAt(currentLookAtRef.current);
      }

      // Rotate gyroscopic rings and pulse beacon tips on nodes
      nodeGroupsRef.current.forEach((grp, taskId) => {
        const gyro = grp.getObjectByName('gyroRing');
        if (gyro) {
          gyro.rotation.z += delta * 1.2;
          gyro.rotation.y += delta * 0.8;
        }

        // Highlight selected node with subtle floating breathing effect
        if (taskId === selectedTaskId) {
          grp.position.y = Math.sin(elapsed * 3) * 0.2;
        } else {
          grp.position.y = 0;
        }
      });

      // Flow energy pulse along dependency conduits
      if (pulseEnergy) {
        conduitCurvesRef.current.forEach((item, i) => {
          const t = (elapsed * 0.45 + i * 0.2) % 1.0;
          const pos = item.curve.getPoint(t, _scratchVecA);
          item.pulseMesh.position.copy(pos);
        });
      }

      if (rendererRef.current && sceneRef.current && cameraRef.current) {
        rendererRef.current.render(sceneRef.current, cameraRef.current);
      }
    };

    animate();

    return () => {
      cancelAnimationFrame(animationFrameId);
      container.removeEventListener('mousedown', handleMouseDown);
      window.removeEventListener('mousemove', handleMouseMove);
      window.removeEventListener('mouseup', handleMouseUp);
      container.removeEventListener('click', handleClick);
      container.removeEventListener('wheel', handleWheel);
      resizeObserver.disconnect();
      renderer.dispose();
      pedestalGeo.dispose();
      hullGeo.dispose();
      coreGeo.dispose();
      gyroRingGeo.dispose();
      domeGeo.dispose();
      spireGeo.dispose();
      beaconTipGeo.dispose();
      contactShadowGeo.dispose();
      floorGeo.dispose();
      floorMat.dispose();
      floorTexture.dispose();
    };
  }, [tasks, dependencies, onSelectTask, pulseEnergy]);

  // Adjust camera preset
  const applyCameraPreset = (preset: 'ISO' | 'TOP' | 'FLOW' | 'INSPECT') => {
    setCameraPreset(preset);
    if (!cameraRef.current) return;

    if (preset === 'ISO') {
      targetCameraPosRef.current.set(0, 22, 30);
      targetLookAtRef.current.set(0, 1.5, 0);
    } else if (preset === 'TOP') {
      targetCameraPosRef.current.set(0, 42, 0.1);
      targetLookAtRef.current.set(0, 0, 0);
    } else if (preset === 'FLOW') {
      targetCameraPosRef.current.set(-24, 14, 18);
      targetLookAtRef.current.set(4, 2, -2);
    } else if (preset === 'INSPECT' && selectedTaskId) {
      const selectedNode = nodeGroupsRef.current.get(selectedTaskId);
      if (selectedNode) {
        const p = selectedNode.position;
        targetCameraPosRef.current.set(p.x + 4, p.y + 4.5, p.z + 8);
        targetLookAtRef.current.set(p.x, p.y + 2, p.z);
      }
    }
  };

  return (
    <div className="relative w-full h-full min-h-[580px] bg-slate-950 overflow-hidden select-none">
      {/* 3D WebGL Canvas Container */}
      <div ref={mountRef} className="absolute inset-0 w-full h-full cursor-grab active:cursor-grabbing" />

      {/* Top Left Spec Badge */}
      <div className="absolute top-4 left-4 z-10 bg-slate-900/90 border border-slate-700/70 text-slate-200 px-3 py-2 rounded shadow-lg text-xs flex items-center gap-3">
        <div className="flex items-center gap-2">
          <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 inline-block" />
          <span className="font-semibold tracking-wide uppercase">3D Topology Engine</span>
        </div>
        <span className="text-slate-500">|</span>
        <span className="text-slate-400">{tasks.length} Nodes</span>
        <span className="text-slate-500">|</span>
        <span className="text-slate-400">{dependencies.length} Conduits</span>
      </div>

      {/* Top Right Hover Inspection Card */}
      {hoveredTask && (
        <div className="absolute top-4 right-4 z-10 bg-slate-900/95 border border-slate-700 p-3.5 rounded shadow-xl text-xs max-w-xs text-slate-200 pointer-events-none">
          <div className="flex items-center justify-between gap-2 mb-1.5">
            <span className="font-semibold text-slate-100 truncate">{hoveredTask.title}</span>
            <span
              className={`px-1.5 py-0.5 rounded text-[10px] font-mono ${
                hoveredTask.isBlocked || hoveredTask.status === 'BLOCKED'
                  ? 'bg-rose-900/80 text-rose-200 border border-rose-700'
                  : hoveredTask.status === 'COMPLETED'
                  ? 'bg-emerald-900/80 text-emerald-200 border border-emerald-700'
                  : 'bg-amber-900/80 text-amber-200 border border-amber-700'
              }`}
            >
              {hoveredTask.status}
            </span>
          </div>
          <p className="text-slate-400 line-clamp-2 mb-2">{hoveredTask.description}</p>
          <div className="flex items-center justify-between text-[11px] text-slate-400 border-t border-slate-800 pt-1.5">
            <span>Assignee: {hoveredTask.assignee || 'Unassigned'}</span>
            <span>{hoveredTask.estimatedMinutes ? `${hoveredTask.estimatedMinutes}m` : 'Est: N/A'}</span>
          </div>
        </div>
      )}

      {/* Unified Bottom Control Dock (Adheres to Three.js Ergonomic Bottom Dock Specification) */}
      <div
        className={`absolute left-1/2 -translate-x-1/2 z-20 transition-all duration-300 ${
          isDockCollapsed ? 'bottom-2' : 'bottom-5'
        } max-w-[min(940px,94vw)] w-full px-3`}
      >
        <div className="flex flex-col items-center">
          {/* Collapse / Expand Toggle Button */}
          <button
            onClick={() => setIsDockCollapsed((prev) => !prev)}
            className="mb-1 bg-slate-900 border border-slate-700 text-slate-300 hover:text-white px-3 py-1 rounded-t text-xs font-mono flex items-center gap-1.5 shadow-md cursor-pointer transition-colors"
          >
            <span>{isDockCollapsed ? '▴ Show Viewport Controls' : '▾ Hide Controls'}</span>
          </button>

          {!isDockCollapsed && (
            <div className="w-full bg-slate-900 border border-slate-700/90 rounded-lg p-2.5 shadow-2xl flex flex-wrap items-center justify-between gap-3 text-xs text-slate-200">
              {/* Camera Presets */}
              <div className="flex items-center gap-1.5">
                <span className="text-slate-400 font-mono text-[11px] uppercase mr-1">Camera:</span>
                <button
                  onClick={() => applyCameraPreset('ISO')}
                  className={`px-2.5 py-1 rounded border transition-colors ${
                    cameraPreset === 'ISO'
                      ? 'bg-indigo-600 border-indigo-500 text-white font-medium'
                      : 'bg-slate-800 border-slate-700 text-slate-300 hover:bg-slate-700'
                  }`}
                >
                  Isometric
                </button>
                <button
                  onClick={() => applyCameraPreset('TOP')}
                  className={`px-2.5 py-1 rounded border transition-colors ${
                    cameraPreset === 'TOP'
                      ? 'bg-indigo-600 border-indigo-500 text-white font-medium'
                      : 'bg-slate-800 border-slate-700 text-slate-300 hover:bg-slate-700'
                  }`}
                >
                  Top-Down
                </button>
                <button
                  onClick={() => applyCameraPreset('FLOW')}
                  className={`px-2.5 py-1 rounded border transition-colors ${
                    cameraPreset === 'FLOW'
                      ? 'bg-indigo-600 border-indigo-500 text-white font-medium'
                      : 'bg-slate-800 border-slate-700 text-slate-300 hover:bg-slate-700'
                  }`}
                >
                  Flow Hangar
                </button>
                <button
                  onClick={() => applyCameraPreset('INSPECT')}
                  disabled={!selectedTaskId}
                  className={`px-2.5 py-1 rounded border transition-colors ${
                    cameraPreset === 'INSPECT'
                      ? 'bg-indigo-600 border-indigo-500 text-white font-medium'
                      : 'bg-slate-800 border-slate-700 text-slate-300 hover:bg-slate-700 disabled:opacity-40 disabled:hover:bg-slate-800'
                  }`}
                >
                  Focus Node
                </button>
              </div>

              {/* Toggles & Diagnostics */}
              <div className="flex items-center gap-3">
                <label className="flex items-center gap-1.5 text-slate-300 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={pulseEnergy}
                    onChange={(e) => setPulseEnergy(e.target.checked)}
                    className="rounded bg-slate-800 border-slate-700 text-indigo-500 focus:ring-0"
                  />
                  <span>Energy Pulses</span>
                </label>

                <div className="flex items-center gap-2 pl-3 border-l border-slate-800 text-[11px] text-slate-400">
                  <div className="flex items-center gap-1">
                    <span className="w-2 h-2 rounded-full bg-emerald-500" />
                    <span>Done</span>
                  </div>
                  <div className="flex items-center gap-1">
                    <span className="w-2 h-2 rounded-full bg-rose-500" />
                    <span>Blocked</span>
                  </div>
                  <div className="flex items-center gap-1">
                    <span className="w-2 h-2 rounded-full bg-amber-500" />
                    <span>Pending</span>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
