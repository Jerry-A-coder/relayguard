import React, { useMemo } from 'react';
import { useApp } from '../../context/AppContext';
import { IncidentCategory, IncidentSeverity, IncidentPriority } from '../../types';
import { AlertCircle, X, ShieldAlert, RotateCcw, Sparkles } from 'lucide-react';
import { useLocalStorageDraft } from '../../hooks/useLocalStorageDraft';

interface ReportDisruptionModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess: () => void;
}

interface DisruptionDraft {
  title: string;
  category: IncidentCategory;
  severity: IncidentSeverity;
  priority: IncidentPriority;
  description: string;
  deadline: string;
  constraints: string;
  source: string;
}

const DEFAULT_FORM: DisruptionDraft = {
  title: '',
  category: 'Delayed delivery',
  severity: 'CRITICAL',
  priority: 'Critical',
  description: '',
  deadline: '',
  constraints: '',
  source: '',
};

export const ReportDisruptionModal: React.FC<ReportDisruptionModalProps> = ({
  isOpen,
  onClose,
  onSuccess,
}) => {
  const { createIncident, currentUser } = useApp();

  const initialValues = useMemo(() => DEFAULT_FORM, []);

  // Hook saving form progress to localStorage
  const { formData, updateField, clearDraft, hasDraft } = useLocalStorageDraft<DisruptionDraft>(
    'relayguard_report_disruption_draft',
    initialValues
  );

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.title.trim() || !formData.description.trim()) return;

    createIncident({
      title: formData.title.trim(),
      description: formData.description.trim(),
      category: formData.category,
      severity: formData.severity,
      priority: formData.priority,
      status: 'ACTIVE',
      verificationStatus: 'VERIFIED',
      creatorId: currentUser.userId,
      creatorName: currentUser.displayName,
      deadline: formData.deadline || undefined,
      knownConstraints: formData.constraints || undefined,
      informationSource: formData.source || 'Direct Operator Alert',
    });

    clearDraft();
    onSuccess();
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4">
      <div className="bg-slate-900 border border-slate-700 rounded-xl p-6 max-w-lg w-full shadow-2xl relative">
        <div className="flex items-center justify-between border-b border-slate-800 pb-3 mb-3">
          <h2 className="text-sm font-bold text-slate-100 flex items-center gap-2">
            <AlertCircle className="w-4 h-4 text-rose-500" />
            <span>Report Operational Disruption</span>
          </h2>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-white p-1 cursor-pointer transition-colors"
            title="Close modal (input auto-saved)"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Draft recovery notice banner */}
        {hasDraft && (
          <div className="mb-3.5 p-2.5 rounded-lg bg-indigo-950/70 border border-indigo-800/80 text-xs text-indigo-200 flex items-center justify-between gap-2">
            <div className="flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-indigo-400" />
              <span>Restored unsaved draft from your previous session.</span>
            </div>
            <button
              type="button"
              onClick={clearDraft}
              className="text-[11px] text-slate-400 hover:text-rose-300 underline cursor-pointer"
            >
              Discard Draft
            </button>
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-3.5 text-xs text-slate-300">
          <div>
            <label className="block text-slate-400 font-medium mb-1">
              Disruption Title <span className="text-rose-400">*</span>
            </label>
            <input
              type="text"
              required
              value={formData.title}
              onChange={(e) => updateField('title', e.target.value)}
              placeholder="e.g., Supplier Logistics Freeze at Frankfurt Cargo Center"
              className="w-full bg-slate-950 border border-slate-700 rounded px-3 py-2 text-slate-100 focus:outline-none focus:border-indigo-500"
            />
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div>
              <label className="block text-slate-400 font-medium mb-1">Category</label>
              <select
                value={formData.category}
                onChange={(e) => updateField('category', e.target.value as IncidentCategory)}
                className="w-full bg-slate-950 border border-slate-700 rounded px-2.5 py-1.5 text-slate-200 focus:outline-none focus:border-indigo-500 cursor-pointer"
              >
                <option value="Delayed delivery">Delayed delivery</option>
                <option value="Missing document">Missing document</option>
                <option value="Appointment change">Appointment change</option>
                <option value="Approval delay">Approval delay</option>
                <option value="Service interruption">Service interruption</option>
                <option value="Dependency failure">Dependency failure</option>
                <option value="Other">Other</option>
              </select>
            </div>

            <div>
              <label className="block text-slate-400 font-medium mb-1">Severity</label>
              <select
                value={formData.severity}
                onChange={(e) => updateField('severity', e.target.value as IncidentSeverity)}
                className="w-full bg-slate-950 border border-slate-700 rounded px-2.5 py-1.5 text-slate-200 focus:outline-none focus:border-indigo-500 cursor-pointer font-bold"
              >
                <option value="CRITICAL" className="text-rose-400">CRITICAL</option>
                <option value="HIGH" className="text-amber-400">HIGH</option>
                <option value="MEDIUM" className="text-blue-400">MEDIUM</option>
                <option value="LOW" className="text-slate-400">LOW</option>
              </select>
            </div>

            <div>
              <label className="block text-slate-400 font-medium mb-1">Priority</label>
              <select
                value={formData.priority}
                onChange={(e) => updateField('priority', e.target.value as IncidentPriority)}
                className="w-full bg-slate-950 border border-slate-700 rounded px-2.5 py-1.5 text-slate-200 focus:outline-none focus:border-indigo-500 cursor-pointer font-bold"
              >
                <option value="Critical" className="text-rose-400">Critical</option>
                <option value="High" className="text-amber-400">High</option>
                <option value="Medium" className="text-blue-400">Medium</option>
                <option value="Low" className="text-slate-400">Low</option>
              </select>
            </div>
          </div>

          <div>
            <label className="block text-slate-400 font-medium mb-1">
              Description of Disruption <span className="text-rose-400">*</span>
            </label>
            <textarea
              rows={3}
              required
              value={formData.description}
              onChange={(e) => updateField('description', e.target.value)}
              placeholder="Detail what broke, what tasks are impacted, and what deadline is endangered..."
              className="w-full bg-slate-950 border border-slate-700 rounded px-3 py-2 text-slate-100 focus:outline-none focus:border-indigo-500"
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-slate-400 font-medium mb-1">Target Deadline</label>
              <input
                type="datetime-local"
                value={formData.deadline}
                onChange={(e) => updateField('deadline', e.target.value)}
                className="w-full bg-slate-950 border border-slate-700 rounded px-2.5 py-1.5 text-slate-200 focus:outline-none focus:border-indigo-500"
              />
            </div>
            <div>
              <label className="block text-slate-400 font-medium mb-1">Evidence Source</label>
              <input
                type="text"
                value={formData.source}
                onChange={(e) => updateField('source', e.target.value)}
                placeholder="e.g., Courier tracking, portal"
                className="w-full bg-slate-950 border border-slate-700 rounded px-2.5 py-1.5 text-slate-200 focus:outline-none focus:border-indigo-500"
              />
            </div>
          </div>

          <div>
            <label className="block text-slate-400 font-medium mb-1">Known Constraints</label>
            <input
              type="text"
              value={formData.constraints}
              onChange={(e) => updateField('constraints', e.target.value)}
              placeholder="e.g., Budget ceiling €500; assembly slot expires Friday..."
              className="w-full bg-slate-950 border border-slate-700 rounded px-2.5 py-1.5 text-slate-200 focus:outline-none focus:border-indigo-500"
            />
          </div>

          <div className="flex items-center justify-between pt-3 border-t border-slate-800">
            <span className="text-[11px] text-slate-500 font-mono">
              Auto-saved to local draft
            </span>

            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={onClose}
                className="px-3 py-1.5 text-slate-400 hover:text-slate-200 cursor-pointer"
              >
                Close
              </button>
              <button
                type="submit"
                className="px-4 py-1.5 bg-rose-600 hover:bg-rose-500 text-white rounded font-medium flex items-center gap-1.5 cursor-pointer shadow"
              >
                <ShieldAlert className="w-3.5 h-3.5" />
                <span>Register &amp; Assess Impact</span>
              </button>
            </div>
          </div>
        </form>
      </div>
    </div>
  );
};
