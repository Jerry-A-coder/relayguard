import React, { useState, useRef, useEffect } from 'react';
import { useApp } from '../../context/AppContext';
import { MessageSquare, Send, Bot, User, Sparkles, Cpu, Zap, RotateCcw, AlertCircle } from 'lucide-react';

interface ChatMessage {
  id: string;
  sender: 'user' | 'model';
  text: string;
  modelUsed?: string;
  timestamp: string;
}

export const GeminiChatbot: React.FC = () => {
  const { activeIncident, tasks, dependencies, recoveryPlans } = useApp();

  const [roleMode, setRoleMode] = useState<'COMPLEX' | 'GENERAL' | 'FAST'>('GENERAL');
  const [input, setInput] = useState('');
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: 'msg-init',
      sender: 'model',
      text: `Hello Operator. I am your RelayGuard Operational Assistant. I am actively tracking the "${activeIncident?.title || 'active crisis'}" scenario. How can I assist you with contingency formulations, dependency bottleneck checks, or approval proposals today?`,
      modelUsed: 'gemini-3.8-flash',
      timestamp: new Date().toLocaleTimeString(),
    },
  ]);
  const [isLoading, setIsLoading] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages, isLoading]);

  const handleSend = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!input.trim() || isLoading) return;

    const userMsg: ChatMessage = {
      id: `user-${Date.now()}`,
      sender: 'user',
      text: input.trim(),
      timestamp: new Date().toLocaleTimeString(),
    };

    const newHistory = [...messages, userMsg];
    setMessages(newHistory);
    setInput('');
    setIsLoading(true);

    try {
      const response = await fetch('/api/gemini/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          messages: newHistory.map((m) => ({ sender: m.sender, text: m.text })),
          modelRole: roleMode,
          incidentContext: {
            title: activeIncident?.title,
            severity: activeIncident?.severity,
            constraints: activeIncident?.knownConstraints,
            tasksSummary: tasks.map((t) => `${t.title} [${t.status}]`).join(', '),
            recoveryPlans: recoveryPlans.map((p) => `${p.title} (${p.score}%)`),
          },
        }),
      });

      const data = await response.json();
      if (data.success && data.reply) {
        setMessages((prev) => [
          ...prev,
          {
            id: `model-${Date.now()}`,
            sender: 'model',
            text: data.reply,
            modelUsed: data.modelUsed,
            timestamp: new Date().toLocaleTimeString(),
          },
        ]);
      } else {
        setMessages((prev) => [
          ...prev,
          {
            id: `model-${Date.now()}`,
            sender: 'model',
            text: `Apologies, I encountered an issue: ${data.error || 'Failed to generate response'}`,
            timestamp: new Date().toLocaleTimeString(),
          },
        ]);
      }
    } catch (err: any) {
      setMessages((prev) => [
        ...prev,
        {
          id: `model-${Date.now()}`,
          sender: 'model',
          text: `Network error connecting to Gemini endpoint: ${err.message}`,
          timestamp: new Date().toLocaleTimeString(),
        },
      ]);
    } finally {
      setIsLoading(false);
    }
  };

  const handleResetChat = () => {
    setMessages([
      {
        id: `msg-${Date.now()}`,
        sender: 'model',
        text: 'Conversation reset. I am standing by for new instructions or strategic reasoning prompts.',
        timestamp: new Date().toLocaleTimeString(),
      },
    ]);
  };

  const suggestedQuestions = [
    'What downstream tasks fail if customs release slips 2 more days?',
    'Evaluate trade-offs between Plan A (Hamburg Stock) and Plan B (Dual Sourced).',
    'Draft an expedited courier authorization request for management.',
  ];

  return (
    <div className="bg-slate-900 border border-slate-800 rounded-xl shadow-xl flex flex-col h-[600px] overflow-hidden">
      {/* Chat Header */}
      <div className="p-3.5 border-b border-slate-800 bg-slate-950/80 flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-lg bg-indigo-950 border border-indigo-800 flex items-center justify-center text-indigo-400">
            <MessageSquare className="w-4 h-4" />
          </div>
          <div>
            <h3 className="text-xs font-bold text-slate-100 flex items-center gap-2">
              <span>RelayGuard Gemini Chatbot</span>
              <span className="text-[10px] font-mono px-2 py-0.2 rounded bg-indigo-950 text-indigo-300 border border-indigo-800">
                MULTI-TURN
              </span>
            </h3>
            <span className="text-[11px] text-slate-400">
              Context grounded in active incident &amp; dependency topology
            </span>
          </div>
        </div>

        {/* Model Persona Switcher */}
        <div className="flex items-center gap-2">
          <div className="flex items-center gap-1 bg-slate-900 border border-slate-800 rounded p-1 text-xs">
            <button
              onClick={() => setRoleMode('COMPLEX')}
              className={`px-2.5 py-1 rounded text-[11px] font-medium flex items-center gap-1 transition-colors cursor-pointer ${
                roleMode === 'COMPLEX'
                  ? 'bg-purple-600 text-white font-semibold'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
              title="Chief Strategist (gemini-4-argon with High Thinking)"
            >
              <Cpu className="w-3 h-3 text-purple-300" />
              <span>Strategist (Argon)</span>
            </button>

            <button
              onClick={() => setRoleMode('GENERAL')}
              className={`px-2.5 py-1 rounded text-[11px] font-medium flex items-center gap-1 transition-colors cursor-pointer ${
                roleMode === 'GENERAL'
                  ? 'bg-indigo-600 text-white font-semibold'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
              title="Operational Coordinator (gemini-3.8-flash)"
            >
              <Sparkles className="w-3 h-3 text-indigo-300" />
              <span>Coordinator (Flash)</span>
            </button>

            <button
              onClick={() => setRoleMode('FAST')}
              className={`px-2.5 py-1 rounded text-[11px] font-medium flex items-center gap-1 transition-colors cursor-pointer ${
                roleMode === 'FAST'
                  ? 'bg-emerald-600 text-white font-semibold'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
              title="Rapid Field Triage (gemini-3.1-flash-lite)"
            >
              <Zap className="w-3 h-3 text-emerald-300" />
              <span>Fast Triage (Lite)</span>
            </button>
          </div>

          <button
            onClick={handleResetChat}
            className="p-1.5 text-slate-400 hover:text-slate-200 rounded hover:bg-slate-800 transition-colors cursor-pointer"
            title="Reset Conversation"
          >
            <RotateCcw className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* Messages Scrollable Thread */}
      <div ref={scrollRef} className="flex-1 p-4 overflow-y-auto space-y-3.5 text-xs">
        {messages.map((m) => {
          const isUser = m.sender === 'user';
          return (
            <div key={m.id} className={`flex items-start gap-2.5 ${isUser ? 'flex-row-reverse' : ''}`}>
              <div
                className={`w-7 h-7 rounded-full flex items-center justify-center shrink-0 text-xs ${
                  isUser
                    ? 'bg-indigo-600 text-white'
                    : 'bg-slate-800 text-cyan-300 border border-slate-700'
                }`}
              >
                {isUser ? <User className="w-3.5 h-3.5" /> : <Bot className="w-3.5 h-3.5" />}
              </div>

              <div
                className={`max-w-[82%] rounded-xl p-3.5 leading-relaxed shadow-sm ${
                  isUser
                    ? 'bg-indigo-600 text-white rounded-tr-none'
                    : 'bg-slate-950 border border-slate-800 text-slate-200 rounded-tl-none whitespace-pre-wrap'
                }`}
              >
                {!isUser && m.modelUsed && (
                  <div className="flex items-center justify-between text-[10px] text-slate-500 font-mono mb-1.5 pb-1 border-b border-slate-900">
                    <span>Model: {m.modelUsed}</span>
                    <span>{m.timestamp}</span>
                  </div>
                )}
                <div>{m.text}</div>
                {isUser && (
                  <div className="text-[10px] text-indigo-200 text-right mt-1 font-mono">{m.timestamp}</div>
                )}
              </div>
            </div>
          );
        })}

        {isLoading && (
          <div className="flex items-start gap-2.5">
            <div className="w-7 h-7 rounded-full bg-slate-800 text-cyan-300 border border-slate-700 flex items-center justify-center shrink-0">
              <Bot className="w-3.5 h-3.5 animate-pulse" />
            </div>
            <div className="bg-slate-950 border border-slate-800 rounded-xl rounded-tl-none p-3.5 text-xs text-slate-400 flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-indigo-500 animate-ping" />
              <span>
                {roleMode === 'COMPLEX'
                  ? 'Gemini 4 Argon reasoning with High Thinking...'
                  : 'Synthesizing operational response...'}
              </span>
            </div>
          </div>
        )}
      </div>

      {/* Suggested Quick Prompts */}
      <div className="px-4 py-2 border-t border-slate-800/80 bg-slate-950/50 flex flex-wrap items-center gap-1.5 text-[11px]">
        <span className="text-slate-500 text-[10px] uppercase font-mono mr-1">Suggested:</span>
        {suggestedQuestions.map((q, idx) => (
          <button
            key={idx}
            onClick={() => {
              setInput(q);
            }}
            className="px-2 py-0.5 rounded bg-slate-800/70 hover:bg-slate-800 text-slate-300 hover:text-white border border-slate-700/60 transition-colors cursor-pointer truncate max-w-xs"
          >
            {q}
          </button>
        ))}
      </div>

      {/* Input Box */}
      <form onSubmit={handleSend} className="p-3 border-t border-slate-800 bg-slate-950 flex items-center gap-2">
        <input
          type="text"
          value={input}
          onChange={(e) => setInput(e.target.value)}
          placeholder={
            roleMode === 'COMPLEX'
              ? 'Ask for complex strategic contingency reasoning (Argon High Thinking)...'
              : 'Ask a question or request action formulation...'
          }
          className="flex-1 bg-slate-900 border border-slate-700 rounded-lg px-3 py-2 text-xs text-slate-100 placeholder-slate-500 focus:outline-none focus:border-indigo-500"
        />
        <button
          type="submit"
          disabled={!input.trim() || isLoading}
          className="px-4 py-2 bg-indigo-600 hover:bg-indigo-500 disabled:opacity-40 text-white rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer shrink-0"
        >
          <Send className="w-3.5 h-3.5" />
          <span>Send</span>
        </button>
      </form>
    </div>
  );
};
