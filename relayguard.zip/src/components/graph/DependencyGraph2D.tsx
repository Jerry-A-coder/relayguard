import React, { useState } from 'react';
import { Task, Dependency, RelationType } from '../../types';
import { AlertTriangle, CheckCircle2, Clock, Ban, ArrowRight, Plus, Trash2 } from 'lucide-react';

interface DependencyGraph2DProps {
  tasks: Task[];
  dependencies: Dependency[];
  selectedTaskId: string | null;
  onSelectTask: (taskId: string) => void;
  onCreateDependency: (sourceId: string, targetId: string, type: RelationType) => { success: boolean; error?: string };
  onDeleteDependency: (depId: string) => void;
}

export const DependencyGraph2D: React.FC<DependencyGraph2DProps> = ({
  tasks,
  dependencies,
  selectedTaskId,
  onSelectTask,
  onCreateDependency,
  onDeleteDependency,
}) => {
  const [showAddModal, setShowAddModal] = useState(false);
  const [sourceId, setSourceId] = useState('');
  const [targetId, setTargetId] = useState('');
  const [relationType, setRelationType] = useState<RelationType>('BLOCKS');
  const [linkError, setLinkError] = useState<string | null>(null);

  const handleCreateLink = (e: React.FormEvent) => {
    e.preventDefault();
    setLinkError(null);
    if (!sourceId || !targetId) {
      setLinkError('Please select both source and target tasks.');
      return;
    }
    const result = onCreateDependency(sourceId, targetId, relationType);
    if (result.success) {
      setShowAddModal(false);
      setSourceId('');
      setTargetId('');
    } else {
      setLinkError(result.error || 'Failed to establish relationship.');
    }
  };

  const getTask = (id: string) => tasks.find((t) => t.id === id);

  return (
    <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-lg">
      <div className="flex items-center justify-between mb-4 border-b border-slate-800 pb-3">
        <div>
          <h3 className="text-sm font-semibold text-slate-100 flex items-center gap-2">
            <span>2D Topological Map & Conduits</span>
            <span className="text-xs font-mono px-2 py-0.5 rounded bg-slate-800 text-slate-400">
              {tasks.length} Nodes &bull; {dependencies.length} Edges
            </span>
          </h3>
          <p className="text-xs text-slate-400 mt-0.5">
            Directed dependencies define operational execution order and trigger cascading blockages.
          </p>
        </div>
        <button
          onClick={() => setShowAddModal(true)}
          className="px-3 py-1.5 bg-indigo-600 hover:bg-indigo-500 text-white rounded text-xs font-medium flex items-center gap-1.5 transition-colors cursor-pointer"
        >
          <Plus className="w-3.5 h-3.5" />
          <span>Connect Dependency</span>
        </button>
      </div>

      {/* Nodes grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3 mb-6">
        {tasks.map((task, idx) => {
          const isSelected = task.id === selectedTaskId;
          const incomingDeps = dependencies.filter((d) => d.targetTaskId === task.id);
          const outgoingDeps = dependencies.filter((d) => d.sourceTaskId === task.id);

          return (
            <div
              key={task.id}
              onClick={() => onSelectTask(task.id)}
              className={`p-3.5 rounded-lg border transition-all cursor-pointer ${
                isSelected
                  ? 'border-indigo-500 bg-slate-800/90 shadow-md ring-1 ring-indigo-500'
                  : 'border-slate-800 bg-slate-950/60 hover:border-slate-700 hover:bg-slate-800/40'
              }`}
            >
              <div className="flex items-center justify-between gap-2 mb-1.5">
                <span className="text-xs font-mono text-slate-400">Step 0{idx + 1}</span>
                <span
                  className={`text-[10px] font-mono px-2 py-0.5 rounded border ${
                    task.isBlocked || task.status === 'BLOCKED'
                      ? 'bg-rose-950/80 text-rose-300 border-rose-800'
                      : task.status === 'COMPLETED'
                      ? 'bg-emerald-950/80 text-emerald-300 border-emerald-800'
                      : 'bg-amber-950/80 text-amber-300 border-amber-800'
                  }`}
                >
                  {task.status}
                </span>
              </div>

              <h4 className="text-xs font-semibold text-slate-100 line-clamp-1 mb-1">{task.title}</h4>
              <p className="text-[11px] text-slate-400 line-clamp-2 mb-2.5">{task.description}</p>

              <div className="flex items-center justify-between text-[11px] text-slate-400 pt-2 border-t border-slate-800/80">
                <span className="truncate max-w-[130px]">{task.assignee || 'Unassigned'}</span>
                <div className="flex items-center gap-2">
                  <span title="Prerequisites" className="text-slate-400 font-mono">
                    In: {incomingDeps.length}
                  </span>
                  <span title="Dependents" className="text-slate-400 font-mono">
                    Out: {outgoingDeps.length}
                  </span>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Explicit Dependency Edge Table */}
      <div>
        <h4 className="text-xs font-semibold uppercase tracking-wider text-slate-400 mb-2">
          Active Directed Relationships (Edges)
        </h4>
        <div className="border border-slate-800 rounded-lg overflow-hidden">
          <table className="w-full text-left text-xs text-slate-300">
            <thead className="bg-slate-950 text-slate-400 font-mono text-[11px] border-b border-slate-800">
              <tr>
                <th className="py-2 px-3">Prerequisite / Blocker</th>
                <th className="py-2 px-3">Relationship</th>
                <th className="py-2 px-3">Dependent Target</th>
                <th className="py-2 px-3">Status Impact</th>
                <th className="py-2 px-3 text-right">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/80">
              {dependencies.map((dep) => {
                const src = getTask(dep.sourceTaskId);
                const tgt = getTask(dep.targetTaskId);
                const isBlockedBySource = src && src.status !== 'COMPLETED';

                return (
                  <tr key={dep.id} className="hover:bg-slate-800/30">
                    <td className="py-2.5 px-3">
                      <span className="font-medium text-slate-100">{src?.title || dep.sourceTaskId}</span>
                      <span className="block text-[10px] text-slate-500 font-mono">{src?.status}</span>
                    </td>
                    <td className="py-2.5 px-3">
                      <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-[10px] font-mono bg-cyan-950 text-cyan-300 border border-cyan-800">
                        <span>{dep.relationType}</span>
                        <ArrowRight className="w-2.5 h-2.5" />
                      </span>
                    </td>
                    <td className="py-2.5 px-3">
                      <span className="font-medium text-slate-100">{tgt?.title || dep.targetTaskId}</span>
                      <span className="block text-[10px] text-slate-500 font-mono">{tgt?.status}</span>
                    </td>
                    <td className="py-2.5 px-3">
                      {isBlockedBySource ? (
                        <span className="text-[11px] text-rose-400 flex items-center gap-1">
                          <Ban className="w-3 h-3" />
                          <span>Prevents execution</span>
                        </span>
                      ) : (
                        <span className="text-[11px] text-emerald-400 flex items-center gap-1">
                          <CheckCircle2 className="w-3 h-3" />
                          <span>Prerequisite satisfied</span>
                        </span>
                      )}
                    </td>
                    <td className="py-2.5 px-3 text-right">
                      <button
                        onClick={() => onDeleteDependency(dep.id)}
                        className="text-slate-400 hover:text-rose-400 p-1 transition-colors cursor-pointer"
                        title="Delete relationship"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* Modal to Connect Dependency with Cycle Guard */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4">
          <div className="bg-slate-900 border border-slate-700 rounded-xl p-5 max-w-md w-full shadow-2xl">
            <h3 className="text-sm font-semibold text-slate-100 mb-1">Establish Directed Dependency</h3>
            <p className="text-xs text-slate-400 mb-4">
              Dependencies are validated by the deterministic engine to prevent cyclic deadlocks.
            </p>

            {linkError && (
              <div className="mb-4 p-2.5 rounded bg-rose-950/80 border border-rose-800 text-rose-300 text-xs flex items-start gap-2">
                <AlertTriangle className="w-4 h-4 shrink-0 mt-0.5 text-rose-400" />
                <span>{linkError}</span>
              </div>
            )}

            <form onSubmit={handleCreateLink} className="space-y-3.5">
              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">Source (Prerequisite / Blocker)</label>
                <select
                  value={sourceId}
                  onChange={(e) => setSourceId(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-700 rounded px-3 py-2 text-xs text-slate-200 focus:outline-none focus:border-indigo-500"
                >
                  <option value="">Select source task...</option>
                  {tasks.map((t) => (
                    <option key={t.id} value={t.id}>
                      {t.title} ({t.status})
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">Relationship Type</label>
                <select
                  value={relationType}
                  onChange={(e) => setRelationType(e.target.value as RelationType)}
                  className="w-full bg-slate-950 border border-slate-700 rounded px-3 py-2 text-xs text-slate-200 focus:outline-none focus:border-indigo-500"
                >
                  <option value="BLOCKS">BLOCKS (Must finish before target begins)</option>
                  <option value="PREREQUISITE">PREREQUISITE (Provides required output)</option>
                  <option value="REPLACES">REPLACES (Alternative substitute path)</option>
                  <option value="AFFECTED_BY">AFFECTED_BY (Indirectly impacted)</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">Target (Dependent Task)</label>
                <select
                  value={targetId}
                  onChange={(e) => setTargetId(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-700 rounded px-3 py-2 text-xs text-slate-200 focus:outline-none focus:border-indigo-500"
                >
                  <option value="">Select target task...</option>
                  {tasks.map((t) => (
                    <option key={t.id} value={t.id}>
                      {t.title} ({t.status})
                    </option>
                  ))}
                </select>
              </div>

              <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="px-3 py-1.5 rounded text-xs text-slate-400 hover:text-slate-200 cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 bg-indigo-600 hover:bg-indigo-500 text-white rounded text-xs font-medium cursor-pointer"
                >
                  Confirm & Link
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
