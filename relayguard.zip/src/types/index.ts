export type WorkspaceRole = 'OWNER' | 'ADMIN' | 'MEMBER' | 'VIEWER';

export interface UserProfile {
  userId: string;
  displayName: string;
  email: string;
  photoURL?: string;
  role: WorkspaceRole;
}

export type IncidentCategory =
  | 'Missing document'
  | 'Delayed delivery'
  | 'Appointment change'
  | 'Approval delay'
  | 'Service interruption'
  | 'Dependency failure'
  | 'Regulatory hold'
  | 'Other';

export type IncidentSeverity = 'CRITICAL' | 'HIGH' | 'MEDIUM' | 'LOW';
export type IncidentPriority = 'Low' | 'Medium' | 'High' | 'Critical';
export type IncidentStatus = 'ACTIVE' | 'CONTAINED' | 'RESOLVING' | 'RESOLVED' | 'ARCHIVED';
export type VerificationStatus = 'VERIFIED' | 'USER_REPORTED' | 'UNVERIFIED' | 'CONJECTURE';

export interface Incident {
  id: string;
  workspaceId: string;
  title: string;
  description: string;
  category: IncidentCategory;
  severity: IncidentSeverity;
  priority?: IncidentPriority;
  status: IncidentStatus;
  verificationStatus: VerificationStatus;
  creatorId: string;
  creatorName?: string;
  deadline?: string;
  knownConstraints?: string;
  informationSource?: string;
  createdAt: string;
  updatedAt: string;
}

export type TaskStatus = 'NOT_STARTED' | 'IN_PROGRESS' | 'BLOCKED' | 'COMPLETED' | 'CANCELLED';
export type TaskRiskLevel = 'NONE' | 'MODERATE' | 'HIGH' | 'CRITICAL';

export interface Task {
  id: string;
  workspaceId: string;
  incidentId: string;
  title: string;
  description: string;
  status: TaskStatus;
  deadline?: string;
  assignee?: string;
  estimatedMinutes?: number;
  isBlocked?: boolean;
  riskLevel?: TaskRiskLevel;
  createdAt: string;
  updatedAt: string;
}

export type RelationType = 'BLOCKS' | 'PREREQUISITE' | 'REPLACES' | 'AFFECTED_BY' | 'REQUIRES_APPROVAL';

export interface Dependency {
  id: string;
  workspaceId: string;
  incidentId: string;
  sourceTaskId: string; // Prerequisite or blocker
  targetTaskId: string; // Dependent task
  relationType: RelationType;
  isConfirmed: boolean;
  createdAt: string;
}

export interface RecoveryActionItem {
  id: string;
  order: number;
  title: string;
  description: string;
  responsibleRole: string;
  estimatedMinutes: number;
  requiresApproval: boolean;
  actionType?: 'EMAIL_DISPATCH' | 'CALENDAR_RESCHEDULE' | 'SUPPLIER_EXPEDITE' | 'EXCEPTION_REQUEST' | 'BROADCAST_ALERT' | 'MANUAL_TASK';
  targetRecipient?: string;
  payload?: Record<string, any>;
  isCompleted?: boolean;
}

export interface RecoveryPlan {
  id: string;
  workspaceId: string;
  incidentId: string;
  title: string;
  strategy: string; // e.g., 'Accelerated Parallel Path'
  score: number; // 0-100
  isSelected: boolean;
  estimatedDuration: string;
  risks: string;
  tradeoffs: string;
  actions: RecoveryActionItem[];
  createdAt: string;
}

export type ApprovalStatus = 'PROPOSED' | 'AWAITING_APPROVAL' | 'APPROVED' | 'REJECTED' | 'CHANGES_REQUESTED' | 'EXECUTING' | 'SUCCEEDED' | 'FAILED';

export interface Approval {
  id: string;
  workspaceId: string;
  incidentId: string;
  planId?: string;
  title: string;
  description: string;
  actionType: 'EMAIL_DISPATCH' | 'CALENDAR_RESCHEDULE' | 'SUPPLIER_EXPEDITE' | 'EXCEPTION_REQUEST' | 'BROADCAST_ALERT' | 'MANUAL_TASK';
  targetRecipient?: string;
  payload?: Record<string, any>;
  status: ApprovalStatus;
  requestedBy: string;
  decidedBy?: string;
  decidedAt?: string;
  executionResult?: string;
  isSimulated?: boolean;
  idempotencyKey?: string;
  createdAt: string;
}

export interface ActivityLog {
  id: string;
  workspaceId: string;
  incidentId?: string;
  actorName: string;
  actorId?: string;
  eventType:
    | 'INCIDENT_CREATED'
    | 'INCIDENT_UPDATED'
    | 'DEPENDENCY_ADDED'
    | 'IMPACT_CALCULATED'
    | 'PLAN_GENERATED'
    | 'PLAN_SELECTED'
    | 'APPROVAL_REQUESTED'
    | 'APPROVAL_GRANTED'
    | 'APPROVAL_REJECTED'
    | 'ACTION_EXECUTED'
    | 'ACTION_FAILED'
    | 'AI_REASONING_RUN';
  summary: string;
  details?: string;
  createdAt: string;
}

export interface Workspace {
  id: string;
  name: string;
  ownerId: string;
  memberRoles: Record<string, WorkspaceRole>;
  createdAt: string;
}
