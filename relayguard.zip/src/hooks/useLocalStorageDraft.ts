import { useState, useEffect, useCallback } from 'react';

export function useLocalStorageDraft<T extends Record<string, any>>(
  storageKey: string,
  defaultValues: T
) {
  const [formData, setFormData] = useState<T>(() => {
    try {
      const saved = localStorage.getItem(storageKey);
      if (saved) {
        const parsed = JSON.parse(saved);
        return { ...defaultValues, ...parsed };
      }
    } catch (e) {
      console.warn(`Failed to parse draft for ${storageKey}:`, e);
    }
    return defaultValues;
  });

  const [hasDraft, setHasDraft] = useState<boolean>(() => {
    try {
      const saved = localStorage.getItem(storageKey);
      if (saved) {
        const parsed = JSON.parse(saved);
        // Check if at least one field has non-empty user content
        return Object.keys(parsed).some((k) => {
          const val = parsed[k];
          return val !== undefined && val !== null && val !== '' && val !== defaultValues[k];
        });
      }
    } catch {
      // ignore
    }
    return false;
  });

  // Persist to localStorage whenever formData changes
  useEffect(() => {
    try {
      // Check if anything meaningful is entered
      const hasContent = Object.keys(formData).some((k) => {
        const val = formData[k];
        return val !== undefined && val !== null && val !== '' && val !== defaultValues[k];
      });

      if (hasContent) {
        localStorage.setItem(storageKey, JSON.stringify(formData));
        setHasDraft(true);
      }
    } catch (e) {
      console.warn(`Failed to save draft for ${storageKey}:`, e);
    }
  }, [formData, storageKey, defaultValues]);

  const updateField = useCallback(<K extends keyof T>(field: K, value: T[K]) => {
    setFormData((prev) => ({ ...prev, [field]: value }));
  }, []);

  const setEntireForm = useCallback((newValues: Partial<T>) => {
    setFormData((prev) => ({ ...prev, ...newValues }));
  }, []);

  const clearDraft = useCallback(() => {
    try {
      localStorage.removeItem(storageKey);
    } catch {
      // ignore
    }
    setFormData(defaultValues);
    setHasDraft(false);
  }, [storageKey, defaultValues]);

  return {
    formData,
    updateField,
    setEntireForm,
    clearDraft,
    hasDraft,
  };
}
