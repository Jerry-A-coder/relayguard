# RelayGuard — Intelligent Disruption Recovery & Coordination System

RelayGuard is a full-stack incident contingency coordination engine designed to convert unexpected operational disruptions into structured, explainable, and trackable recovery workflows.

---

## 1. System Architecture

```
React + TypeScript Frontend (Port 3000)
    │
    ▼ (Centralized API Client / WebSockets)
FastAPI Backend (Port 8000)
    │
    ├── Authentication & Authorization (JWT + RBAC: Owner, Admin, Member, Viewer)
    ├── Deterministic Dependency DAG Engine (Cycle Detection, Kahn's Algo, Critical Path, Cascade Analysis)
    ├── Rule-Based Prioritization Engine (Deadline Slack, Downstream Dependents, Incident Severity)
    ├── Multi-Alternative Recovery Planner (Plan A: Scope Preservation, Plan B: Fast-Track, Plan C: Grace Window)
    ├── Approval State Machine & Gating (Admin/Owner Signoff Enforcement)
    ├── Idempotent Action Execution Service (Simulated Adapters: Email, CalDAV, Logistics, Variances)
    ├── Dynamic Replanning Engine (Automatic downstream unblocking upon task completion)
    └── Append-Only Audit Logging Service
    │
    ▼ (SQLAlchemy ORM + Alembic Migrations)
PostgreSQL / SQLite Database
```

---

## 2. Technology Stack

* **Frontend**: React 19, TypeScript, Vite, Tailwind CSS, Lucide React, Centralized Typed API Client.
* **Backend**: Python 3.11+, FastAPI, Pydantic v2, SQLAlchemy 2.0, Alembic, WebSockets, Pytest.
* **Database**: PostgreSQL (production & Docker) / SQLite (zero-config local test suite).
* **AI & Planning**: Deterministic mathematical DAG dependency engine, multi-objective recovery planner, and optional Gemini/Bedrock resilience analysis adapters.

---

## 3. Quick Start with Docker Compose

To launch the complete PostgreSQL database, FastAPI backend, and React frontend in isolated containers:

```bash
docker compose up --build
```

Services exposed:
* **Frontend Web App**: `http://localhost:3000`
* **FastAPI Backend & Interactive Swagger Docs**: `http://localhost:8000/api/v1/docs`
* **PostgreSQL Database**: `localhost:5432` (Database: `relayguard`, User: `postgres`, Password: `relayguard_secure_password_2026`)

---

## 4. Local Development Setup (Manual)

### Backend Setup (FastAPI + Python)

1. Navigate to the backend directory:
   ```bash
   cd backend
   ```

2. Create and activate a virtual environment:
   ```bash
   python3 -m venv venv
   source venv/bin/activate
   ```

3. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```

4. Run the database seed scenario:
   ```bash
   python3 seed.py
   ```

5. Start the FastAPI server:
   ```bash
   uvicorn app.main:app --host 0.0.0.0 --port 8000 --reload
   ```

### Frontend Setup (React + Node)

1. From the repository root:
   ```bash
   npm install
   ```

2. Start the development server:
   ```bash
   npm run dev
   ```
   Open `http://localhost:3000` in your browser.

---

## 5. Running Automated Backend Tests

The automated Pytest test suite thoroughly validates all 25 test points across authentication, incident management, DAG cycle detection, cycle rejection, Kahn topological sort, downstream cascades, critical path computation, multi-alternative plan generation, approval gating, RBAC checks, idempotent action execution, and dynamic unblocking:

```bash
PYTHONPATH=backend pytest -v backend/tests
```

### Test Coverage Highlights:
1. `test_register_user`: User registration, organization creation, and JWT issuance.
2. `test_login_success`: Authentication with valid credentials.
3. `test_login_invalid_credentials`: 401 Unauthorized rejection on bad password.
4. `test_get_current_user_me`: Token validation and profile inspection.
5. `test_engine_cycle_detection`: DFS cycle identification on direct and indirect loops.
6. `test_engine_topological_sort`: Kahn's algorithm ordering without deadlock.
7. `test_engine_downstream_impact`: Cascade blast-radius calculation.
8. `test_engine_critical_path`: DAG longest-path critical path identification.
9. `test_engine_blocked_tasks`: Identification of tasks waiting on unresolved prerequisites.
10. `test_api_cycle_rejection`: API level HTTP 400 rejection preventing circular dependencies from being inserted.
11. `test_create_and_list_incident`: Incident creation, status transitions, and listing.
12. `test_create_task_and_update_status`: Task lifecycle updates.
13. `test_generate_and_select_recovery_plan`: Synthesis of Plans A, B, and C with auto-generated approvals.
14. `test_approval_decision_rbac_and_execution_gating`: Gating execution until approved, Member 403 Forbidden rejection, Admin approval, and duplicate idempotency key rejection.
15. `test_dynamic_replanning_unblocks_dependent_task`: Automatic status shift from `BLOCKED` to `NOT_STARTED` when upstream prerequisite completes.
16. `test_audit_log_captures_events`: Immutable chronological audit event recording.

---

## 6. Seed Scenario: Student Capstone Telemetry Disruption

Run the seed command to load the realistic Capstone disruption case study:

```bash
python3 backend/seed.py
```

### Seeded Entities:
* **Organization**: Stanford School of Engineering - Senior Capstone
* **Users**:
  * **Owner**: `marcus.vance@stanford.edu` / `RelayGuard2026!` (Faculty Advisor)
  * **Admin**: `sarah.lin@stanford.edu` / `RelayGuard2026!` (Head TA)
  * **Member**: `alex.rivera@stanford.edu` / `RelayGuard2026!` (Student Lead)
* **Incident**: "Autonomous Drone Capstone: Flight Sensor Telemetry Burnout" (Critical Priority)
* **DAG Tasks & Dependencies**:
  * Task A (Sensor Procurement) -> Task B (Soldering & Harness) -> Task C (Firmware Calibration) -> Task D (Safety Test) -> Task E (Final Submission Video)
  * Task C -> Task F (Academic Code Audit) -> Task E
* **Generated Recovery Strategies**:
  * **Plan A**: Scope Preservation (Accelerated Parallel Path) — 92% Confidence
  * **Plan B**: Fast-Track Bypass & Supplier Redirection — 85% Confidence
  * **Plan C**: Grace Window & Controlled Scope Deferral — 78% Confidence
* **Approvals & Governance**: Pre-configured authorization request for Emergency Overtime / Expedite voucher awaiting Admin/Owner decision.

---

## 7. Real vs. Simulated Integrations Disclosure

* **Real Integrations**:
  * PostgreSQL / SQLite ORM persistence with SQLAlchemy and Alembic.
  * JWT authentication with HMAC-SHA256 and salt hashing.
  * Deterministic DAG graph algorithms (topological sort, critical path, cycle prevention).
  * Rule-based prioritization and risk classification.
  * Real-time WebSocket event streaming and REST APIs.
* **Demonstration / Simulation Adapters**:
  * `EMAIL_DISPATCH`: Simulated SMTP relay logging dispatched subject, recipient, and payload.
  * `CALENDAR_RESCHEDULE`: Simulated CalDAV shift calculating conflict-free slots.
  * `SUPPLIER_EXPEDITE`: Simulated tier-1 courier ticket generation.
  * `EXCEPTION_REQUEST`: Simulated governance registry reference generation.
