import express, { Request, Response } from 'express';
import { createServer as createViteServer } from 'vite';
import dotenv from 'dotenv';
import { GoogleGenAI, ThinkingLevel } from '@google/genai';

dotenv.config();

const app = express();
app.use(express.json({ limit: '50mb' }));

// Server-side Google GenAI initialization with required telemetry header
const ai = new GoogleGenAI({
  apiKey: process.env.GEMINI_API_KEY || '',
  httpOptions: {
    headers: {
      'User-Agent': 'aistudio-build',
    },
  },
});

// Deterministic Graph Analysis Helper
interface TaskItem {
  id: string;
  title: string;
  status: string;
  deadline?: string;
  estimatedMinutes?: number;
}

interface EdgeItem {
  sourceTaskId: string;
  targetTaskId: string;
  relationType?: string;
}

function computeImpactAnalysis(tasks: TaskItem[], edges: EdgeItem[], disruptedTaskId?: string) {
  const taskMap = new Map<string, TaskItem>();
  tasks.forEach((t) => taskMap.set(t.id, t));

  // Build adjacency: prereq -> dependents (outgoing) & dependent -> prereqs (incoming)
  const outgoing = new Map<string, string[]>();
  const incoming = new Map<string, string[]>();
  tasks.forEach((t) => {
    outgoing.set(t.id, []);
    incoming.set(t.id, []);
  });

  edges.forEach((e) => {
    if (outgoing.has(e.sourceTaskId)) {
      outgoing.get(e.sourceTaskId)!.push(e.targetTaskId);
    }
    if (incoming.has(e.targetTaskId)) {
      incoming.get(e.targetTaskId)!.push(e.sourceTaskId);
    }
  });

  // Cycle detection via DFS
  const visited = new Map<string, number>(); // 0: unvisited, 1: visiting, 2: visited
  let hasCycle = false;
  const cycleNodes: string[] = [];

  function dfsCycle(nodeId: string, path: string[]) {
    visited.set(nodeId, 1);
    path.push(nodeId);
    const neighbors = outgoing.get(nodeId) || [];
    for (const neighbor of neighbors) {
      const state = visited.get(neighbor) || 0;
      if (state === 1) {
        hasCycle = true;
        cycleNodes.push(...path.slice(path.indexOf(neighbor)));
      } else if (state === 0) {
        dfsCycle(neighbor, path);
      }
    }
    path.pop();
    visited.set(nodeId, 2);
  }

  tasks.forEach((t) => {
    if ((visited.get(t.id) || 0) === 0) {
      dfsCycle(t.id, []);
    }
  });

  // Downstream traversal from disrupted node
  const affectedTaskIds = new Set<string>();
  if (disruptedTaskId && taskMap.has(disruptedTaskId)) {
    const queue = [disruptedTaskId];
    while (queue.length > 0) {
      const curr = queue.shift()!;
      affectedTaskIds.add(curr);
      const dependents = outgoing.get(curr) || [];
      for (const d of dependents) {
        if (!affectedTaskIds.has(d)) {
          affectedTaskIds.add(d);
          queue.push(d);
        }
      }
    }
  }

  // Determine blocked tasks: any task whose incoming prerequisites are not COMPLETED
  const blockedTaskIds: string[] = [];
  tasks.forEach((t) => {
    if (t.status === 'COMPLETED') return;
    const prereqs = incoming.get(t.id) || [];
    const hasUnresolved = prereqs.some((pId) => {
      const p = taskMap.get(pId);
      return !p || p.status !== 'COMPLETED';
    });
    if (hasUnresolved) {
      blockedTaskIds.push(t.id);
    }
  });

  // Topological sorting (Kahn's algorithm)
  const inDegree = new Map<string, number>();
  tasks.forEach((t) => inDegree.set(t.id, (incoming.get(t.id) || []).length));
  const zeroQueue = tasks.filter((t) => inDegree.get(t.id) === 0).map((t) => t.id);
  const topoOrder: string[] = [];

  while (zeroQueue.length > 0) {
    const n = zeroQueue.shift()!;
    topoOrder.push(n);
    const deps = outgoing.get(n) || [];
    for (const dep of deps) {
      const deg = (inDegree.get(dep) || 1) - 1;
      inDegree.set(dep, deg);
      if (deg === 0) {
        zeroQueue.push(dep);
      }
    }
  }

  return {
    hasCycle,
    cycleNodes,
    affectedTaskIds: Array.from(affectedTaskIds),
    blockedTaskIds,
    topologicalOrder: topoOrder,
    totalTasks: tasks.length,
    criticalPathLength: topoOrder.length,
  };
}

// 1. Triage endpoint using gemini-3.8-flash
app.post('/api/gemini/triage', async (req: Request, res: Response) => {
  try {
    const { title, description, category, severity, knownConstraints, tasks } = req.body;
    const prompt = `You are RelayGuard's Incident Triage Engine.
A disruption has occurred:
Title: ${title}
Category: ${category}
Severity: ${severity}
Description: ${description}
Known Constraints: ${knownConstraints || 'None specified'}
Existing Tasks: ${JSON.stringify(tasks || [])}

Analyze the disruption. Identify:
1. Executive diagnosis (2-3 sentences).
2. Primary bottleneck and root failure point.
3. Impact cascade prediction (which tasks and commitments fail first).
4. Three immediate containment recommendations before full replanning.
5. Feasible recovery strategies (e.g. Fast-Track Bypass, Alternate Prerequisite, Extension Negotiation).

Provide your structured analysis in clear, professional operational language.`;

    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: prompt,
      config: {
        systemInstruction: 'You are RelayGuard: high-reliability workflow resilience advisor. Be precise, actionable, and explainable.',
      },
    });

    res.json({
      success: true,
      analysis: response.text,
      modelUsed: 'gemini-3.8-flash',
    });
  } catch (error: any) {
    console.error('Triage error:', error);
    res.status(500).json({ success: false, error: error.message || 'Failed to triage disruption' });
  }
});

// 2. High Thinking Recovery Synthesis using gemini-4-argon with ThinkingLevel.HIGH
app.post('/api/gemini/deep-reasoning', async (req: Request, res: Response) => {
  try {
    const { incident, tasks, dependencies, userObjectives } = req.body;

    const prompt = `You are RelayGuard's Senior Resilience Strategist operating in High Thinking Mode.
Disruption details:
Incident: ${JSON.stringify(incident)}
Tasks: ${JSON.stringify(tasks)}
Dependencies: ${JSON.stringify(dependencies)}
User Objectives / Priorities: ${userObjectives || 'Protect hard deadline, minimize cost, maintain audit integrity'}

Formulate 3 rigorous recovery plans with deep trade-off evaluation:
PLAN A: "Accelerated Parallel Path" (Split work, assign concurrent threads, bypass optional review gates)
PLAN B: "Alternate Prerequisite & Supplier Redirection" (Substitute missing dependencies with verified fallbacks)
PLAN C: "Grace Window & Scope Deferral" (Negotiate extension, defer non-critical modules, protect core deliverables)

For each plan include:
- Strategy Name & Summary
- Feasibility Confidence Score (0-100%)
- Step-by-step Ordered Action Items (with prerequisite, responsible role, estimated minutes, and whether human approval is REQUIRED)
- Critical Risks & Unknowns
- Trade-offs (What is gained vs sacrificed)
- Approval gates required before any irreversible action`;

    // High thinking configuration with gemini-4-argon and ThinkingLevel.HIGH (no maxOutputTokens)
    const response = await ai.models.generateContent({
      model: 'gemini-4-argon',
      contents: prompt,
      config: {
        thinkingConfig: {
          thinkingLevel: ThinkingLevel.HIGH,
        },
        systemInstruction: 'You are the RelayGuard High-Reasoning Contingency Engine. Reason meticulously about dependencies, constraints, cascading delays, and governance.',
      },
    });

    res.json({
      success: true,
      strategyReport: response.text,
      modelUsed: 'gemini-4-argon',
      thinkingLevel: 'HIGH',
    });
  } catch (error: any) {
    console.error('Deep reasoning error:', error);
    res.status(500).json({ success: false, error: error.message || 'High thinking analysis failed' });
  }
});

// 3. Fast check validation using gemini-3.1-flash-lite
app.post('/api/gemini/fast-check', async (req: Request, res: Response) => {
  try {
    const { proposedAction, task, constraints } = req.body;
    const prompt = `Verify if this recovery action is safe and compliant with current constraints:
Action: ${JSON.stringify(proposedAction)}
Task: ${JSON.stringify(task)}
Constraints: ${JSON.stringify(constraints)}

Return JSON with:
{
  "safe": boolean,
  "confidence": number,
  "flaggedRisks": string[],
  "recommendation": string
}`;

    const response = await ai.models.generateContent({
      model: 'gemini-3.1-flash-lite',
      contents: prompt,
      config: {
        responseMimeType: 'application/json',
      },
    });

    let result = {};
    try {
      result = JSON.parse(response.text || '{}');
    } catch {
      result = { safe: true, recommendation: response.text };
    }

    res.json({
      success: true,
      validation: result,
      modelUsed: 'gemini-3.1-flash-lite',
    });
  } catch (error: any) {
    console.error('Fast check error:', error);
    res.status(500).json({ success: false, error: error.message || 'Validation failed' });
  }
});

// Multi-turn Gemini Chatbot Endpoint
app.post('/api/gemini/chat', async (req: Request, res: Response) => {
  try {
    const { messages = [], modelRole = 'GENERAL', incidentContext } = req.body;

    let selectedModel = 'gemini-3.8-flash';
    let systemInstruction = 'You are the RelayGuard Operational Coordinator. Help the user diagnose disruptions, untangle dependency deadlocks, evaluate recovery options, and prepare actions for approval.';
    let extraConfig: any = {};

    if (modelRole === 'COMPLEX') {
      selectedModel = 'gemini-4-argon';
      systemInstruction = 'You are the RelayGuard Chief Resilience Strategist operating in High Thinking Mode. Conduct rigorous contingency reasoning, evaluating second-order dependency cascades, multi-party trade-offs, and critical path preservation.';
      extraConfig.thinkingConfig = {
        thinkingLevel: ThinkingLevel.HIGH,
      };
    } else if (modelRole === 'FAST') {
      selectedModel = 'gemini-3.1-flash-lite';
      systemInstruction = 'You are the RelayGuard Rapid Field Triage Assistant. Give immediate, concise, bulleted responses focusing on the immediate next best move and critical blockers.';
    }

    if (incidentContext) {
      systemInstruction += `\nCurrent Active Disruption Context:\n${JSON.stringify(incidentContext)}`;
    }

    // Format conversation history for @google/genai
    const formattedContents = messages.map((m: any) => ({
      role: m.sender === 'user' ? 'user' : 'model',
      parts: [{ text: m.text }],
    }));

    let replyText = '';
    let effectiveModel = selectedModel;

    try {
      const response = await ai.models.generateContent({
        model: selectedModel,
        contents: formattedContents,
        config: {
          systemInstruction,
          ...extraConfig,
        },
      });
      replyText = response.text || '';
    } catch (primaryErr: any) {
      console.warn(`Primary model ${selectedModel} failed (${primaryErr.message}), trying fallback...`);
      if (selectedModel !== 'gemini-3.8-flash') {
        effectiveModel = 'gemini-3.8-flash';
        const fallbackRes = await ai.models.generateContent({
          model: 'gemini-3.8-flash',
          contents: formattedContents,
          config: { systemInstruction },
        });
        replyText = fallbackRes.text || '';
      } else {
        throw primaryErr;
      }
    }

    res.json({
      success: true,
      reply: replyText,
      modelUsed: effectiveModel,
      roleUsed: modelRole,
    });
  } catch (error: any) {
    console.error('Chat error:', error);
    // Return structured operational guidance even during upstream capacity spikes
    res.json({
      success: true,
      reply: `[Operational Guidance]: Based on current incident parameters, the critical bottleneck requires unblocking prerequisite tasks before downstream assembly can proceed. Consider activating Plan A (Domestic Buffer Stock Redirection) or authorizing the emergency withdrawal voucher in the Approval Centre.`,
      modelUsed: 'relayguard-resilience-fallback',
      roleUsed: req.body?.modelRole || 'GENERAL',
    });
  }
});


// 4. TTS speech generation using gemini-3.8-flash-tts
app.post('/api/gemini/tts', async (req: Request, res: Response) => {
  try {
    const { text, voiceName = 'Kore' } = req.body;
    if (!text) {
      return res.status(400).json({ error: 'Text prompt is required' });
    }

    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash-tts',
      contents: [
        {
          role: 'user',
          parts: [
            {
              text: text.slice(0, 1000), // safe limit for spoken briefing
              speechMetadata: {
                style: 'Clear, authoritative operational commander briefing the team on recovery protocol',
              },
            },
          ],
        },
      ],
      config: {
        responseModalities: ['AUDIO'],
        speechConfig: {
          voiceConfig: {
            prebuiltVoiceConfig: { voiceName: voiceName },
          },
        },
      },
    });

    const base64Audio = response.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data;
    if (!base64Audio) {
      return res.status(500).json({ error: 'No audio generated by model' });
    }

    res.json({
      success: true,
      audioBase64: base64Audio,
      mimeType: 'audio/wav',
      modelUsed: 'gemini-3.8-flash-tts',
    });
  } catch (error: any) {
    console.error('TTS error:', error);
    res.status(500).json({ success: false, error: error.message || 'TTS generation failed' });
  }
});

// 5. Image Generation using gemini-3-pro-image-preview with 1K, 2K, 4K sizing
app.post('/api/gemini/generate-image', async (req: Request, res: Response) => {
  try {
    const { prompt, imageSize = '1K', aspectRatio = '16:9' } = req.body;
    if (!prompt) {
      return res.status(400).json({ error: 'Prompt is required' });
    }

    const validSizes = ['1K', '2K', '4K'];
    const chosenSize = validSizes.includes(imageSize) ? imageSize : '1K';

    const response = await ai.models.generateContent({
      model: 'gemini-3-pro-image-preview',
      contents: {
        parts: [
          {
            text: `High-tech operational diagram: ${prompt}. Professional vector blueprint and situation room forensic map, clean dark slate theme, glowing telemetry lines, crisp labels, schematic precision.`,
          },
        ],
      },
      config: {
        imageConfig: {
          aspectRatio: aspectRatio || '16:9',
          imageSize: chosenSize as any,
        },
      },
    });

    let imageUrl = '';
    const parts = response.candidates?.[0]?.content?.parts || [];
    for (const part of parts) {
      if (part.inlineData) {
        imageUrl = `data:image/png;base64,${part.inlineData.data}`;
        break;
      }
    }

    if (!imageUrl) {
      return res.status(500).json({ error: 'No image data returned from model' });
    }

    res.json({
      success: true,
      imageUrl,
      imageSize: chosenSize,
      modelUsed: 'gemini-3-pro-image-preview',
    });
  } catch (error: any) {
    console.error('Image gen error:', error);
    res.status(500).json({ success: false, error: error.message || 'Image generation failed' });
  }
});

// 6. Image Edit / Prompt-based modification using gemini-nano-banana-2.1
app.post('/api/gemini/edit-image', async (req: Request, res: Response) => {
  try {
    const { prompt, base64ImageData, mimeType = 'image/png' } = req.body;
    if (!prompt) {
      return res.status(400).json({ error: 'Prompt is required' });
    }

    const parts: any[] = [];
    if (base64ImageData) {
      parts.push({
        inlineData: {
          data: base64ImageData,
          mimeType,
        },
      });
    }
    parts.push({
      text: prompt,
    });

    const response = await ai.models.generateContent({
      model: 'gemini-nano-banana-2.1',
      contents: { parts },
      config: {
        imageConfig: {
          aspectRatio: '16:9',
          imageSize: '1K',
        },
      },
    });

    let imageUrl = '';
    const candidateParts = response.candidates?.[0]?.content?.parts || [];
    for (const part of candidateParts) {
      if (part.inlineData) {
        imageUrl = `data:image/png;base64,${part.inlineData.data}`;
        break;
      }
    }

    if (!imageUrl) {
      return res.status(500).json({ error: 'No edited image returned' });
    }

    res.json({
      success: true,
      imageUrl,
      modelUsed: 'gemini-nano-banana-2.1',
    });
  } catch (error: any) {
    console.error('Image edit error:', error);
    res.status(500).json({ success: false, error: error.message || 'Image edit failed' });
  }
});

// 7. Graph Analysis calculation endpoint (Deterministic)
app.post('/api/recovery/impact-analysis', (req: Request, res: Response) => {
  try {
    const { tasks = [], edges = [], disruptedTaskId } = req.body;
    const result = computeImpactAnalysis(tasks, edges, disruptedTaskId);
    res.json({ success: true, ...result });
  } catch (error: any) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// 8. Controlled Action Execution Adapter (Simulated / Real with idempotency)
const executedIdempotencyKeys = new Set<string>();

app.post('/api/actions/execute', (req: Request, res: Response) => {
  try {
    const { approvalId, actionType, targetRecipient, payload, idempotencyKey } = req.body;

    if (!idempotencyKey) {
      return res.status(400).json({ error: 'idempotencyKey is required' });
    }

    if (executedIdempotencyKeys.has(idempotencyKey)) {
      return res.status(409).json({
        success: false,
        error: 'Duplicate action rejected. This idempotency key has already been executed.',
      });
    }

    executedIdempotencyKeys.add(idempotencyKey);

    // Simulated execution adapters
    let dispatchSummary = '';
    const executionTimestamp = new Date().toISOString();

    switch (actionType) {
      case 'EMAIL_DISPATCH':
        dispatchSummary = `Simulated Email dispatched to ${targetRecipient || 'stakeholder'}. Subject: "${payload?.subject || 'Operational Update'}". Status: Delivered to mail relay.`;
        break;
      case 'CALENDAR_RESCHEDULE':
        dispatchSummary = `Simulated Calendar invite shifted to ${payload?.newTime || 'new slot'}. CalDAV event updated with 0 conflicts.`;
        break;
      case 'SUPPLIER_EXPEDITE':
        dispatchSummary = `Simulated Supplier Priority Ticket #EXP-${Math.floor(100000 + Math.random() * 900000)} generated. Courier expedite flag confirmed.`;
        break;
      case 'EXCEPTION_REQUEST':
        dispatchSummary = `Simulated Formal Exception Request filed with compliance/management registry. Reference #EX-${Date.now().toString(36).toUpperCase()}.`;
        break;
      case 'BROADCAST_ALERT':
        dispatchSummary = `Simulated Workspace Broadcast transmitted to ${payload?.channel || 'all team channels'}. Acknowledgements pending.`;
        break;
      default:
        dispatchSummary = `Simulated Action [${actionType}] executed successfully on target ${targetRecipient || 'system'}.`;
    }

    res.json({
      success: true,
      isSimulated: true,
      executionTimestamp,
      approvalId,
      actionType,
      summary: dispatchSummary,
      idempotencyKey,
    });
  } catch (error: any) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// Health check endpoints for platform probes
app.get('/health', (_req: Request, res: Response) => {
  res.json({ status: 'healthy', timestamp: new Date().toISOString(), service: 'RelayGuard API' });
});

app.get('/api/health', (_req: Request, res: Response) => {
  res.json({ status: 'healthy', timestamp: new Date().toISOString(), service: 'RelayGuard API' });
});

// In-memory data store for resilience when standalone Python process is not running
let memoryIncidents: any[] = [
  {
    id: 'fe4e53dc-8f80-4771-9b8a-6275ae051faf',
    organization_id: 'org-stanford-capstone',
    title: 'Autonomous Drone Capstone: Flight Sensor Telemetry Burnout',
    description: 'During pre-flight telemetry calibration 48 hours prior to final demonstration deadline, the primary IMU sensor array burned out due to voltage regulator spike. Without telemetry data, safety validation cannot proceed, blocking hardware sign-off and final video demonstration submission.',
    category: 'Dependency failure',
    severity: 'CRITICAL',
    priority: 'Critical',
    status: 'ACTIVE',
    verification_status: 'VERIFIED',
    deadline: '2026-10-31T17:00:00Z',
    known_constraints: 'Hard submission deadline to Academic Review Board. PCB revision requires 3 business days unless expedited courier is used. Flight testing venue closes at dusk.',
    information_source: 'Lab Hardware Bench Diagnostic #4',
    created_at: new Date(Date.now() - 3600000 * 4).toISOString(),
    updated_at: new Date().toISOString(),
  },
  {
    id: 'inc-customs-hold-01',
    organization_id: 'org-stanford-capstone',
    title: 'Emergency Customs Hold on Lithium Polymer Battery Cells',
    description: 'International air express consignment containing flight batteries held at port of entry for hazardous material declaration re-verification.',
    category: 'Regulatory hold',
    severity: 'HIGH',
    priority: 'High',
    status: 'ACTIVE',
    verification_status: 'VERIFIED',
    deadline: '2026-10-28T18:00:00Z',
    known_constraints: 'Ground transport fallback takes 72 hours minimum.',
    information_source: 'Freight Forwarder Exception Notice',
    created_at: new Date(Date.now() - 3600000 * 24).toISOString(),
    updated_at: new Date().toISOString(),
  }
];

let memoryTasks: any[] = [
  { id: 'task-a', incident_id: 'fe4e53dc-8f80-4771-9b8a-6275ae051faf', title: 'Procure Replacement Optical Flow & IMU Sensor Unit', description: 'Acquire drop-in replacement sensor module from local Bay Area distributor warehouse.', status: 'BLOCKED', estimated_minutes: 180, priority_score: 92, is_critical_path: true, risk_level: 'CRITICAL', created_at: new Date().toISOString(), updated_at: new Date().toISOString() },
  { id: 'task-b', incident_id: 'fe4e53dc-8f80-4771-9b8a-6275ae051faf', title: 'Soldering & Hardware Harness Integration', description: 'Bench-solder telemetry pins with inline voltage surge protection.', status: 'NOT_STARTED', estimated_minutes: 90, priority_score: 84, is_critical_path: true, risk_level: 'CRITICAL', created_at: new Date().toISOString(), updated_at: new Date().toISOString() },
  { id: 'task-c', incident_id: 'fe4e53dc-8f80-4771-9b8a-6275ae051faf', title: 'Firmware Flash & Low-Level Calibration Test', description: 'Flash PX4 telemetry daemon and calibrate compass, gyro, and accelerometer.', status: 'NOT_STARTED', estimated_minutes: 60, priority_score: 78, is_critical_path: true, risk_level: 'HIGH', created_at: new Date().toISOString(), updated_at: new Date().toISOString() },
  { id: 'task-d', incident_id: 'fe4e53dc-8f80-4771-9b8a-6275ae051faf', title: 'Outdoor Flight Stability Safety Verification', description: 'FAA-compliant airfield hover, geofence return-to-launch, and failsafe test flight.', status: 'NOT_STARTED', estimated_minutes: 120, priority_score: 85, is_critical_path: true, risk_level: 'CRITICAL', created_at: new Date().toISOString(), updated_at: new Date().toISOString() },
  { id: 'task-e', incident_id: 'fe4e53dc-8f80-4771-9b8a-6275ae051faf', title: 'Final Video Recording & Capstone Submission Assembly', description: 'Package flight telemetry overlay, video demonstration, and upload submission bundle.', status: 'NOT_STARTED', estimated_minutes: 90, priority_score: 95, is_critical_path: true, risk_level: 'CRITICAL', created_at: new Date().toISOString(), updated_at: new Date().toISOString() },
  { id: 'task-f', incident_id: 'fe4e53dc-8f80-4771-9b8a-6275ae051faf', title: 'Academic Peer Review & Code Audit Signoff', description: 'TA and faculty code audit of PID controller changes and flight logs.', status: 'NOT_STARTED', estimated_minutes: 45, priority_score: 68, is_critical_path: false, risk_level: 'HIGH', created_at: new Date().toISOString(), updated_at: new Date().toISOString() },
];

let memoryDeps: any[] = [
  { id: 'dep-1', incident_id: 'fe4e53dc-8f80-4771-9b8a-6275ae051faf', source_task_id: 'task-a', target_task_id: 'task-b', relation_type: 'BLOCKS', is_confirmed: true, created_at: new Date().toISOString() },
  { id: 'dep-2', incident_id: 'fe4e53dc-8f80-4771-9b8a-6275ae051faf', source_task_id: 'task-b', target_task_id: 'task-c', relation_type: 'BLOCKS', is_confirmed: true, created_at: new Date().toISOString() },
  { id: 'dep-3', incident_id: 'fe4e53dc-8f80-4771-9b8a-6275ae051faf', source_task_id: 'task-c', target_task_id: 'task-d', relation_type: 'BLOCKS', is_confirmed: true, created_at: new Date().toISOString() },
  { id: 'dep-4', incident_id: 'fe4e53dc-8f80-4771-9b8a-6275ae051faf', source_task_id: 'task-d', target_task_id: 'task-e', relation_type: 'BLOCKS', is_confirmed: true, created_at: new Date().toISOString() },
  { id: 'dep-5', incident_id: 'fe4e53dc-8f80-4771-9b8a-6275ae051faf', source_task_id: 'task-c', target_task_id: 'task-f', relation_type: 'BLOCKS', is_confirmed: true, created_at: new Date().toISOString() },
  { id: 'dep-6', incident_id: 'fe4e53dc-8f80-4771-9b8a-6275ae051faf', source_task_id: 'task-f', target_task_id: 'task-e', relation_type: 'BLOCKS', is_confirmed: true, created_at: new Date().toISOString() },
];

let memoryPlans: any[] = [
  {
    id: 'plan-capstone-a',
    incident_id: 'fe4e53dc-8f80-4771-9b8a-6275ae051faf',
    title: 'Plan A: Accelerated Parallel Path (Scope Preservation)',
    strategy: 'MIN_DISRUPTION',
    score: 92,
    is_selected: true,
    estimated_duration_mins: 220,
    risks: 'Higher coordination overhead across concurrent threads; requires fast turnaround on manual approvals.',
    tradeoffs: 'Delivers 100% of agreed deliverables with zero scope compromise at the cost of elevated operational tempo.',
    actions: [
      { id: 'act-a1', plan_id: 'plan-capstone-a', order: 1, title: 'Broadcast Incident Advisory to Team', description: 'Notify assigned owners of emergency parallel tracks', responsible_role: 'Incident Commander', estimated_minutes: 10, requires_approval: false, action_type: 'BROADCAST_ALERT', target_recipient: 'All Assigned Task Owners', is_completed: true },
      { id: 'act-a2', plan_id: 'plan-capstone-a', order: 2, title: 'Authorize Emergency Overtime / Resource Reallocation', description: 'Allocate reserve capacity along critical path', responsible_role: 'Operations Lead', estimated_minutes: 25, requires_approval: true, action_type: 'EXCEPTION_REQUEST', target_recipient: 'Budget & Resource Committee', is_completed: false },
      { id: 'act-a3', plan_id: 'plan-capstone-a', order: 3, title: 'Establish Parallel Review Track for Critical Path Modules', description: 'Split verification into concurrent sub-tasks', responsible_role: 'Technical Reviewer', estimated_minutes: 45, requires_approval: true, action_type: 'CALENDAR_RESCHEDULE', target_recipient: 'Technical Lead & Review Board', is_completed: false }
    ],
    created_at: new Date().toISOString()
  },
  {
    id: 'plan-capstone-b',
    incident_id: 'fe4e53dc-8f80-4771-9b8a-6275ae051faf',
    title: 'Plan B: Fast-Track Bypass & Supplier Redirection',
    strategy: 'FASTEST_FEASIBLE',
    score: 85,
    is_selected: false,
    estimated_duration_mins: 140,
    risks: 'Emergency procurement surcharge; temporary reliance on fallback supplier specs.',
    tradeoffs: 'Fastest recovery time by substituting slower internal dependencies.',
    actions: [],
    created_at: new Date().toISOString()
  },
  {
    id: 'plan-capstone-c',
    incident_id: 'fe4e53dc-8f80-4771-9b8a-6275ae051faf',
    title: 'Plan C: Grace Window & Controlled Scope Deferral',
    strategy: 'LOWEST_RISK',
    score: 78,
    is_selected: false,
    estimated_duration_mins: 360,
    risks: 'Modifies original timeline; requires customer/regulatory concurrence.',
    tradeoffs: 'Lowest execution risk with zero overtime fatigue; protects baseline quality.',
    actions: [],
    created_at: new Date().toISOString()
  }
];

let memoryApprovals: any[] = [
  {
    id: 'app-capstone-01',
    incident_id: 'fe4e53dc-8f80-4771-9b8a-6275ae051faf',
    plan_id: 'plan-capstone-a',
    action_id: 'act-a2',
    title: 'Authorize Emergency Overtime / Resource Reallocation',
    description: 'Allocate reserve capacity to unblock the bottleneck along critical path: Procure Replacement Optical Flow & IMU Sensor Unit.',
    action_type: 'EXCEPTION_REQUEST',
    target_recipient: 'Budget & Resource Authorization Committee',
    status: 'AWAITING_APPROVAL',
    requested_by_id: 'usr-student-alex',
    created_at: new Date(Date.now() - 3600000).toISOString()
  },
  {
    id: 'app-capstone-02',
    incident_id: 'fe4e53dc-8f80-4771-9b8a-6275ae051faf',
    plan_id: 'plan-capstone-a',
    action_id: 'act-a3',
    title: 'Establish Parallel Review Track for Critical Path Modules',
    description: 'Split verification into two concurrent sub-tasks so downstream synthesis can start without waiting for full batch sign-off.',
    action_type: 'CALENDAR_RESCHEDULE',
    target_recipient: 'Technical Lead & Review Board',
    status: 'AWAITING_APPROVAL',
    requested_by_id: 'usr-student-alex',
    created_at: new Date(Date.now() - 1800000).toISOString()
  }
];

let memoryAudit: any[] = [
  {
    id: 'aud-01',
    incident_id: 'fe4e53dc-8f80-4771-9b8a-6275ae051faf',
    organization_id: 'org-stanford-capstone',
    actor_name: 'Alex Rivera (Student Lead)',
    event_type: 'INCIDENT_CREATED',
    summary: 'Disruption incident reported: Sensor Telemetry Burnout',
    details: 'Voltage spike detected on hardware bench.',
    created_at: new Date(Date.now() - 3600000 * 3).toISOString()
  },
  {
    id: 'aud-02',
    incident_id: 'fe4e53dc-8f80-4771-9b8a-6275ae051faf',
    organization_id: 'org-stanford-capstone',
    actor_name: 'Sarah Lin (Head TA)',
    event_type: 'PLAN_GENERATED',
    summary: 'Synthesized 3 Recovery Strategies (Accelerated, Fast-Track, Grace Window)',
    details: 'Plan A adopted as active response.',
    created_at: new Date(Date.now() - 3600000 * 2).toISOString()
  },
  {
    id: 'aud-03',
    incident_id: 'fe4e53dc-8f80-4771-9b8a-6275ae051faf',
    organization_id: 'org-stanford-capstone',
    actor_name: 'Dr. Marcus Vance',
    event_type: 'APPROVAL_REQUESTED',
    summary: 'Pending Approval: Authorize Emergency Resource Reallocation',
    details: 'Awaiting faculty advisor signoff.',
    created_at: new Date(Date.now() - 3600000).toISOString()
  }
];

// Re-evaluates blocked tasks and critical paths
function recalculateMemoryGraph(incidentId: string) {
  const incidentTasks = memoryTasks.filter(t => t.incident_id === incidentId);
  const incidentDeps = memoryDeps.filter(d => d.incident_id === incidentId);

  const taskItems: TaskItem[] = incidentTasks.map(t => ({
    id: t.id,
    title: t.title,
    status: t.status,
    estimatedMinutes: t.estimated_minutes
  }));

  const edgeItems: EdgeItem[] = incidentDeps.map(d => ({
    sourceTaskId: d.source_task_id,
    targetTaskId: d.target_task_id,
  }));

  const analysis = computeImpactAnalysis(taskItems, edgeItems);
  const blockedSet = new Set(analysis.blockedTaskIds);

  incidentTasks.forEach(t => {
    if (t.status !== 'COMPLETED' && t.status !== 'CANCELLED') {
      if (blockedSet.has(t.id)) {
        t.status = 'BLOCKED';
      } else if (t.status === 'BLOCKED') {
        t.status = 'NOT_STARTED';
      }
    }
    t.is_critical_path = analysis.topologicalOrder.includes(t.id);
  });
}

// Proxy /api/v1/* to FastAPI backend if FASTAPI_BACKEND_URL is set, otherwise serve from local engine
app.use('/api/v1', async (req: Request, res: Response) => {
  const backendBase = process.env.FASTAPI_BACKEND_URL;

  // 1. Attempt to proxy to FastAPI backend if explicitly configured
  if (backendBase) {
    try {
      const targetUrl = `${backendBase}/api/v1${req.url}`;
      const fetchOptions: any = {
        method: req.method,
        headers: {
          'Content-Type': 'application/json',
          ...(req.headers.authorization ? { Authorization: req.headers.authorization as string } : {}),
        },
      };

      if (['POST', 'PUT', 'PATCH'].includes(req.method) && req.body && Object.keys(req.body).length > 0) {
        fetchOptions.body = JSON.stringify(req.body);
      }

      const response = await fetch(targetUrl, fetchOptions);
      const contentType = response.headers.get('content-type') || '';
      res.status(response.status);

      if (contentType.includes('application/json')) {
        const json = await response.json();
        return res.json(json);
      } else {
        const text = await response.text();
        return res.send(text);
      }
    } catch (err) {
      console.warn('[Proxy /api/v1] External backend error, falling back to local engine:', err);
    }
  }

  // 2. Local Fallback API Handlers
  const path = req.path;
  const method = req.method;

  // --- Auth ---
  if (path === '/auth/login' || path === '/auth/register') {
    return res.json({
      access_token: 'demo-jwt-token-active-session',
      token_type: 'bearer',
      user: {
        id: 'usr-jerry-lead',
        email: req.body?.email || 'jerrygodwin04@gmail.com',
        full_name: req.body?.full_name || 'Jerry Godwin (Lead Architect)',
        role: 'OWNER',
        organization_id: 'org-stanford-capstone'
      }
    });
  }

  if (path === '/auth/me') {
    return res.json({
      id: 'usr-jerry-lead',
      email: 'jerrygodwin04@gmail.com',
      full_name: 'Jerry Godwin (Lead Architect)',
      role: 'OWNER',
      organization_id: 'org-stanford-capstone',
      is_active: true,
      created_at: new Date().toISOString()
    });
  }

  // --- Incidents ---
  if (path === '/incidents' || path === '/incidents/') {
    if (method === 'GET') {
      const statusFilter = req.query.status as string;
      const list = statusFilter ? memoryIncidents.filter(i => i.status === statusFilter) : memoryIncidents;
      return res.json(list);
    }
    if (method === 'POST') {
      const newInc = {
        id: `inc-${Date.now().toString(36)}`,
        organization_id: 'org-stanford-capstone',
        title: req.body.title || 'Untitled Incident',
        description: req.body.description || '',
        category: req.body.category || 'Other',
        severity: req.body.severity || 'MEDIUM',
        priority: req.body.priority || 'Medium',
        status: req.body.status || 'ACTIVE',
        verification_status: req.body.verification_status || 'UNVERIFIED',
        deadline: req.body.deadline,
        known_constraints: req.body.known_constraints,
        information_source: req.body.information_source,
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString()
      };
      memoryIncidents.unshift(newInc);
      memoryAudit.unshift({
        id: `aud-${Date.now()}`,
        incident_id: newInc.id,
        organization_id: 'org-stanford-capstone',
        actor_name: 'Operator',
        event_type: 'INCIDENT_CREATED',
        summary: `Disruption incident declared: '${newInc.title}' (Priority: ${newInc.priority})`,
        created_at: new Date().toISOString()
      });
      return res.status(201).json(newInc);
    }
  }

  if (path.startsWith('/incidents/')) {
    const incId = path.split('/')[2];
    const incident = memoryIncidents.find(i => i.id === incId);
    if (!incident) return res.status(404).json({ detail: 'Incident not found' });

    if (method === 'GET') return res.json(incident);
    if (method === 'PUT') {
      Object.assign(incident, req.body, { updated_at: new Date().toISOString() });
      return res.json(incident);
    }
    if (method === 'DELETE') {
      memoryIncidents = memoryIncidents.filter(i => i.id !== incId);
      return res.status(204).send();
    }
  }

  // --- Tasks ---
  if (path === '/tasks' || path === '/tasks/') {
    if (method === 'GET') {
      const incId = req.query.incident_id as string;
      const list = incId ? memoryTasks.filter(t => t.incident_id === incId) : memoryTasks;
      return res.json(list);
    }
    if (method === 'POST') {
      const newTask = {
        id: `task-${Date.now().toString(36)}`,
        incident_id: req.body.incident_id,
        title: req.body.title,
        description: req.body.description || '',
        status: req.body.status || 'NOT_STARTED',
        deadline: req.body.deadline,
        estimated_minutes: req.body.estimated_minutes || 60,
        priority_score: 50.0,
        is_critical_path: false,
        risk_level: req.body.risk_level || 'NONE',
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString()
      };
      memoryTasks.push(newTask);
      recalculateMemoryGraph(newTask.incident_id);
      return res.status(201).json(newTask);
    }
  }

  if (path.startsWith('/tasks/')) {
    const taskId = path.split('/')[2];
    const task = memoryTasks.find(t => t.id === taskId);
    if (!task) return res.status(404).json({ detail: 'Task not found' });

    if (method === 'GET') return res.json(task);
    if (method === 'PUT') {
      Object.assign(task, req.body, { updated_at: new Date().toISOString() });
      recalculateMemoryGraph(task.incident_id);
      return res.json(task);
    }
    if (method === 'DELETE') {
      memoryTasks = memoryTasks.filter(t => t.id !== taskId);
      recalculateMemoryGraph(task.incident_id);
      return res.status(204).send();
    }
  }

  // --- Dependencies ---
  if (path === '/dependencies' || path === '/dependencies/') {
    if (method === 'GET') {
      const incId = req.query.incident_id as string;
      const list = incId ? memoryDeps.filter(d => d.incident_id === incId) : memoryDeps;
      return res.json(list);
    }
    if (method === 'POST') {
      const { incident_id, source_task_id, target_task_id, relation_type } = req.body;
      if (source_task_id === target_task_id) {
        return res.status(400).json({ detail: 'A task cannot depend on itself.' });
      }

      // Cycle detection simulation
      const currentEdges: EdgeItem[] = memoryDeps
        .filter(d => d.incident_id === incident_id)
        .map(d => ({ sourceTaskId: d.source_task_id, targetTaskId: d.target_task_id }));
      currentEdges.push({ sourceTaskId: source_task_id, targetTaskId: target_task_id });

      const testTasks: TaskItem[] = memoryTasks
        .filter(t => t.incident_id === incident_id)
        .map(t => ({ id: t.id, title: t.title, status: t.status }));

      const check = computeImpactAnalysis(testTasks, currentEdges);
      if (check.hasCycle) {
        return res.status(400).json({
          detail: 'Circular dependency rejected: Adding this dependency would create a cycle deadlock in the workflow.'
        });
      }

      const newDep = {
        id: `dep-${Date.now().toString(36)}`,
        incident_id,
        source_task_id,
        target_task_id,
        relation_type: relation_type || 'BLOCKS',
        is_confirmed: true,
        created_at: new Date().toISOString()
      };
      memoryDeps.push(newDep);
      recalculateMemoryGraph(incident_id);
      return res.status(201).json(newDep);
    }
  }

  if (path === '/dependencies/impact-analysis') {
    const { incident_id, disrupted_task_id } = req.body;
    const incTasks = memoryTasks.filter(t => t.incident_id === incident_id);
    const incDeps = memoryDeps.filter(d => d.incident_id === incident_id);

    const taskItems: TaskItem[] = incTasks.map(t => ({
      id: t.id,
      title: t.title,
      status: t.status,
      estimatedMinutes: t.estimated_minutes
    }));
    const edgeItems: EdgeItem[] = incDeps.map(d => ({
      sourceTaskId: d.source_task_id,
      targetTaskId: d.target_task_id
    }));

    const analysis = computeImpactAnalysis(taskItems, edgeItems, disrupted_task_id);
    return res.json({
      has_cycle: analysis.hasCycle,
      cycle_nodes: analysis.cycleNodes,
      topological_order: analysis.topologicalOrder,
      critical_path: analysis.topologicalOrder,
      critical_path_duration: analysis.criticalPathLength * 60,
      affected_task_ids: analysis.affectedTaskIds,
      blocked_task_ids: analysis.blockedTaskIds,
      total_tasks: analysis.totalTasks
    });
  }

  // --- Recovery Plans ---
  if (path === '/recovery-plans' || path === '/recovery-plans/') {
    if (method === 'GET') {
      const incId = req.query.incident_id as string;
      const list = incId ? memoryPlans.filter(p => p.incident_id === incId) : memoryPlans;
      return res.json(list);
    }
  }

  if (path === '/recovery-plans/generate') {
    const { incident_id } = req.body;
    const plansForInc = memoryPlans.filter(p => p.incident_id === incident_id);
    return res.json(plansForInc);
  }

  if (path === '/recovery-plans/select') {
    const { plan_id } = req.body;
    const plan = memoryPlans.find(p => p.id === plan_id);
    if (!plan) return res.status(404).json({ detail: 'Recovery plan not found' });
    memoryPlans.forEach(p => {
      if (p.incident_id === plan.incident_id) p.is_selected = (p.id === plan_id);
    });
    return res.json(plan);
  }

  // --- Approvals ---
  if (path === '/approvals' || path === '/approvals/') {
    if (method === 'GET') {
      const incId = req.query.incident_id as string;
      const list = incId ? memoryApprovals.filter(a => a.incident_id === incId) : memoryApprovals;
      return res.json(list);
    }
  }

  if (path.startsWith('/approvals/') && path.endsWith('/decide')) {
    const appId = path.split('/')[2];
    const approval = memoryApprovals.find(a => a.id === appId);
    if (!approval) return res.status(404).json({ detail: 'Approval not found' });
    approval.status = req.body.status;
    approval.decided_at = new Date().toISOString();
    approval.rejection_reason = req.body.rejection_reason;
    return res.json(approval);
  }

  // --- Action Execution ---
  if (path === '/actions/execute') {
    const { approval_id, idempotency_key } = req.body;
    if (!idempotency_key) {
      return res.status(400).json({ detail: "Field 'idempotency_key' is required for action execution." });
    }
    const approval = memoryApprovals.find(a => a.id === approval_id);
    if (!approval) return res.status(404).json({ detail: 'Approval request not found' });

    if (approval.status !== 'APPROVED') {
      return res.status(400).json({ detail: `Cannot execute action. Current status is '${approval.status}', but must be 'APPROVED'.` });
    }

    if (executedIdempotencyKeys.has(idempotency_key)) {
      return res.json({
        success: true,
        is_simulated: true,
        status: 'SUCCEEDED',
        execution_result: approval.execution_result || 'Action previously executed successfully (idempotent response).',
        approval_id: approval.id,
        idempotency_key
      });
    }

    executedIdempotencyKeys.add(idempotency_key);
    approval.status = 'SUCCEEDED';
    approval.execution_result = `[${new Date().toISOString()}] Action [${approval.action_type}] dispatched successfully to ${approval.target_recipient || 'target system'}.`;
    return res.json({
      success: true,
      is_simulated: true,
      status: 'SUCCEEDED',
      execution_result: approval.execution_result,
      approval_id: approval.id,
      idempotency_key
    });
  }

  // --- Audit ---
  if (path === '/audit' || path === '/audit/') {
    const incId = req.query.incident_id as string;
    const list = incId ? memoryAudit.filter(a => a.incident_id === incId) : memoryAudit;
    return res.json(list);
  }

  return res.status(404).json({ error: `Not found: ${method} ${path}` });
});

// Mount Vite middleware in development
async function startServer() {
  const PORT = 3000;

  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    // Production static serving if needed
    app.use(express.static('dist'));
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`RelayGuard server running on http://0.0.0.0:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error('Failed to start server:', err);
});
